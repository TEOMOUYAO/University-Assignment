/**********|**********|**********|
Program: TC03_A2_TEO_MOU_YAO
Course: Objected-Oriented Programming and Data Structures
Year: 2018/19 Trimester 2
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC03
Tutorial Section: TT06
Email: 1171101313@student.mmy.edu.my
Phone: 018-9730678
**********|**********|**********/


#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <cstring>
#include <string>
#include <fstream>
using namespace std;


class searching
{
private:
  string cont= "yes";
  string stopw;
  string line;
  char search[100];
  char StopWords[3000];

public:
  void file();

};


  void searching:: file()
  {
    ifstream file;
    file.open("StopWords.txt");
    stopw="o";

    cout<<"******************"<<endl;
    cout<<"Words to search: "<<endl;
    cin>>search;
    cout<<"******************"<<endl;

    while (file.good()) {
        file>>StopWords;
        int abc = strcmp(StopWords, search);
        if (file.good() && abc == 0) {
              stopw = "stop";

        }

    }//while
    file.close();

if(stopw== "stop")
{
  cout<<"This is StopWords.txt"<<endl;
}
else
{


//----------------------"1.txt"-------------------------------------------------//
  ifstream myfile1;
  myfile1.open("1.txt");


  for(int nolines1 =1; !myfile1.eof(); nolines1++)
  {
    getline(myfile1, line);
    if( line.find(search, 0) != string::npos){
    cout<<endl;
    cout<<"File: "<< "1.txt" << endl;
    cout<<"Line: " << nolines1<<endl;
    cout<<line;
    }
  }

  //cout<<endl;
  myfile1.close();



//----------------------"2.txt"-------------------------------------------------//
  ifstream myfile2;
  myfile2.open("2.txt");


  for(int nolines2 =1; !myfile2.eof(); nolines2++)
  {
    getline(myfile2, line);
    if( line.find(search, 0) != string::npos){
      cout<<endl;
      cout<<"File: "<< "2.txt" << endl;
      cout<<"Line: " << nolines2<<endl;
      cout<<line;
    }
  }
  //cout<<endl;


  myfile2.close();


//----------------------"3.txt"-------------------------------------------------//
  ifstream myfile3;
  myfile3.open("3.txt");


  for(int nolines3 =1; !myfile3.eof(); nolines3++)
  {
  getline(myfile3, line);
  if( line.find(search, 0) != string::npos){
  cout<<endl;
  cout<<"File: "<< "3.txt" << endl;
  cout<<"Line: " << nolines3<<endl;
  cout<<line;
  }
  }
//  cout<<endl;
  myfile3.close();


//----------------------"4.txt"-------------------------------------------------//

  ifstream myfile4;
  myfile4.open("4.txt");


  for(int nolines4 =1; !myfile4.eof(); nolines4++)
  {
    getline(myfile4, line);
    if( line.find(search, 0) != string::npos){
    cout<<endl;
    cout<<"File: "<< "4.txt" << endl;
    cout<<"Line: " << nolines4<<endl;
    cout<<line;
    }
  }
//  cout<<endl;
  myfile4.close();



//----------------------"5.txt"-------------------------------------------------//
    ifstream myfile5;
    myfile5.open("5.txt");


    for(int nolines5 =1; !myfile5.eof(); nolines5++)
    {
      getline(myfile5, line);
      if( line.find(search, 0) != string::npos){
          cout<<endl;
          cout<<"File: "<< "5.txt" << endl;
          cout<<"Line: " << nolines5<<endl;
          cout<<line;
          }
        }
    //cout<<endl;
    myfile5.close();



//----------------------"6.txt"-------------------------------------------------//
      ifstream myfile6;
      myfile6.open("6.txt");


      for(int nolines6 =1; !myfile6.eof(); nolines6++)
      {
        getline(myfile6, line);
        if( line.find(search, 0) != string::npos){
        cout<<endl;
        cout<<"File: "<< "6.txt" << endl;
        cout<<"Line: " << nolines6<<endl;
        cout<<line;
        }
      }
    //  cout<<endl;
      myfile6.close();


//----------------------"7.txt"-------------------------------------------------//
      ifstream myfile7;
      myfile7.open("7.txt");


      for(int nolines7 =1; !myfile7.eof(); nolines7++)
      {
        getline(myfile7, line);
        if( line.find(search, 0) != string::npos){
        cout<<endl;
        cout<<"File: "<< "7.txt" << endl;
        cout<<"Line: " << nolines7<<endl;
        cout<<line;
        }
      }
      //cout<<endl;
      myfile7.close();

//----------------------"8.txt"-------------------------------------------------//
      ifstream myfile8;
      myfile8.open("8.txt");


      for(int nolines8 =1; !myfile8.eof(); nolines8++)
      {
        getline(myfile8, line);
        if( line.find(search, 0) != string::npos){
        cout<<endl;
        cout<<"File: "<< "8.txt" << endl;
        cout<<"Line: " << nolines8<<endl;
        cout<<line;
        }
      }
    //  cout<<endl;
      myfile8.close();


//----------------------"9.txt"-------------------------------------------------//
      ifstream myfile9;
      myfile9.open("9.txt");


      for(int nolines9 =1; !myfile9.eof(); nolines9++)
      {
        getline(myfile9, line);
        if( line.find(search, 0) != string::npos){
        cout<<endl;
        cout<<"File: "<< "9.txt" << endl;
        cout<<"Line: " << nolines9<<endl;
        cout<<line;
        }
      }
    //  cout<<endl;
      myfile9.close();


//----------------------"10.txt"-------------------------------------------------//
      ifstream myfile10;
      myfile10.open("10.txt");


      for(int nolines10 =1; !myfile10.eof(); nolines10++)
      {
        getline(myfile10, line);
        if( line.find(search, 0) != string::npos){
        cout<<endl;
        cout<<"File: "<< "10.txt" << endl;
        cout<<"Line: " << nolines10<<endl;
        cout<<line;
        }
      }
      //cout<<endl;
      myfile10.close();

  }//else
  }//voidfile


int main()
{
  string cont= "yes";


  searching mysearch;

  while(cont == "yes")
  {

  mysearch.file();

  cout<<endl<<endl;
  cout<<"Do you want to continue (yes/no): ";
  cin>>cont;
  cout<<endl;

  }//while



  return 0;
}//main
