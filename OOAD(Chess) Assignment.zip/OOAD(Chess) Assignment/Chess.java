import javax.swing.ImageIcon;

/* *********|**********|**********|
Program: Chief.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//abstract class of the chess and act as model
public abstract class Chess
{
    protected String name;                                      //chess name
    protected String color;                                      //chess color
    protected String position;                                   //chess position
    protected ImageIcon image_chess;                               //chess image
    protected Boolean rotate;                                      //true then roate else false not to be rotate
    public String get_name(){return name;}                          //get chess name
    public Chess(String position)                                   //constructer of Chess
    {this.position=position;
    rotate=false;}
    public abstract String[]  Movement();                           //abstract class to find the movement of the chess
    public String get_position(){return position;}                  //get position
    public void change_position(String position){this.position=position;}//change position
    public ImageIcon get_image(){return image_chess;}                   //get image of the chess
    public Boolean Check_Rotate(){return rotate;}                       //check is rotate or not
    public void Rotate(){rotate=(rotate==false)?true:false;}            //change rotate
    public String get_color(){return color;}                            //get color of the chess
}
