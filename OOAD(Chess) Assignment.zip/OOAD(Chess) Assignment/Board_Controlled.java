import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JOptionPane;

/* *********|**********|**********|
Program: Chief.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//this class act as Controlled controll the GUI_board and update the Chess Rule
public class Board_Controlled implements ChangeListener
{
    private Chess_Rule rule;
    private GUI_Board board;
    private Color White=new Color(255,255,255);
    private Color LightBlue=new Color(168, 254, 255);
    private Color Blue=new Color(29, 81, 238);
    private Color Red=new Color(207, 44, 0 );
    
    public Board_Controlled(Chess_Rule rule, GUI_Board board, JButton button1)
    {
        this.rule=rule;
        this.board=board;
        initialView();
        //when the board resize it will replace the chess again
        board.getRootPane().addComponentListener(new ComponentAdapter() 
        {
            public void componentResized(ComponentEvent e) {
                placedChess();
            }
        });
        button1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                newGame();
            }
        });
    }
    
    //rearrange the position of the chess and visible the gui board and place the chess on it
    public void newGame()
    {
        rule.New_Game();
        board.setVisible(true);
        placedChess();
        
    }
    
    //visible the gui boaard and place the chess on it
    public void Game()
    {
        board.setVisible(true);
        placedChess();
        
    }
    
    //add changelistner to the button of the gui board
    private void initialView()
    {
        for(JButton x:board.getBoardPosition())
        {
            x.addChangeListener(this);
        }
    }
    
    //place the chess to the button(board position) of the GUI Board
    public void placedChess()
    {
        JButton[] board_position=board.getBoardPosition();
        if(rule.get_color_turn().compareTo("Green")==0)
            for(int y=7,i=0;y>0;y--)
            {
                for(char x='A'; x<='G'; x++)
                {
                    board_position[i].setName(Character.toString(x)+String.valueOf(y));
                    board_position[i].setBackground(White);
                    board_position[i].setIcon(null);
                    i++;
                }
            }
        else
            for(int y=1,i=0;y<=7;y++)
            {
                for(char x='G'; x>='A'; x--)
                {
                    board_position[i].setName(Character.toString(x)+String.valueOf(y));
                    board_position[i].setBackground(White);
                    board_position[i].setIcon(null);
                    i++;
                }
            }
        for(Chess x: rule.chess)
        {
            if(x==null)
                continue;
            if(x.get_position()==null)
                continue;
            int num=position_to_num(x.get_position());
            Boolean rotateOrNot=(rule.get_color_turn().compareTo("Green")==0)?(x.Check_Rotate()):(!x.Check_Rotate());
            if((x.get_name().compareTo("Advancer")==0 || x.get_name().compareTo("Trident")==0 )&& rotateOrNot)
            {
                board_position[num].setIcon(new RotatedIcon(resizeIcon(x.get_image(),board_position[num].getWidth(),board_position[num].getHeight()),
                                                                RotatedIcon.Rotate.UPSIDE_DOWN));
            }
            else
                board_position[num].setIcon(resizeIcon(x.get_image(),board_position[num].getWidth(), board_position[num].getHeight()));
        }
    }
    
    //to resize the icon and return it
    private Icon resizeIcon(ImageIcon icon, int resizedWidth, int resizedHeight) 
    {
        Image img = icon.getImage();  
        Image resizedImage = img.getScaledInstance(resizedWidth, resizedHeight,  java.awt.Image.SCALE_SMOOTH);  
        return new ImageIcon(resizedImage);
    }
    
    //controll the button of the GUI Board
    @Override
    public void stateChanged(ChangeEvent e)
    {
        JButton[] board_position=board.getBoardPosition();
        JButton temp = (JButton)e.getSource();
        String color_turn=rule.get_color_turn();
        if(temp.getModel().isPressed())
        {
            if(temp.getBackground().getRGB()==White.getRGB())
            {
                for(JButton x:board_position)
                            x.setBackground(White);
                if(temp.getIcon()!=null)
                {
                        
                        if(color_turn.compareTo("Green")==0 && (rule.chess[rule.Check_Chess_Position(temp.getName())].get_color().compareTo("Red")==0))
                                return;
                        if(color_turn.compareTo("Red")==0 && (rule.chess[rule.Check_Chess_Position(temp.getName())].get_color().compareTo("Green")==0) )
                             return;
                        String[] movement= rule.Predict_Movement_Chess(temp.getName());
                        for(String x:movement)
                        {
                            if(x==null)
                                continue;
                            for(int i=0; i<x.length(); i+=2)
                            {
                                    board_position[position_to_num(x.substring(i,i+2))].setBackground(LightBlue);
                                    if(board_position[position_to_num(x.substring(i,i+2))].getIcon() != null)
                                    {
                                        if(color_turn.compareTo("Green")==0){
                                            if(rule.Check_Chess_Position(x.substring(i,i+2))<14)
                                                board_position[position_to_num(x.substring(i,i+2))].setBackground(White);
                                            else
                                                board_position[position_to_num(x.substring(i,i+2))].setBackground(Red);
                                            }
                                        else{
                                            if(rule.Check_Chess_Position(x.substring(i,i+2))>=14)
                                                board_position[position_to_num(x.substring(i,i+2))].setBackground(White);
                                            else
                                                board_position[position_to_num(x.substring(i,i+2))].setBackground(Red);
                                            }
                                    }
                            }
                                
                        }
                        board_position[position_to_num(temp.getName())].setBackground(Blue);
                 }
            }
            else if(temp.getBackground().getRGB()==LightBlue.getRGB() || temp.getBackground().getRGB()==Red.getRGB())
            {
                int prePosition,curPosition;
                if(color_turn.compareTo("Green")==0)
                {
                    prePosition=position_to_num(rule.chess[rule.get_seleted_chess()].get_position());
                    curPosition=rule.get_seleted_chess();
                    if(temp.getBackground().getRGB()==Red.getRGB()){
                        rule.chess[rule.Check_Chess_Position(temp.getName())].change_position(null);}
                    rule.chess[curPosition].change_position(temp.getName());
                    if(temp.getName().charAt(1)=='7'){
                        if(!rule.chess[curPosition].Check_Rotate())
                            rule.chess[curPosition].Rotate();}
                    else if(temp.getName().charAt(1)=='1'){
                        if(rule.chess[curPosition].Check_Rotate())
                            rule.chess[curPosition].Rotate();}
                    
                }
                else
                {
                    prePosition=position_to_num(rule.chess[rule.get_seleted_chess()].get_position());
                    curPosition=rule.get_seleted_chess();
                    if(temp.getBackground().getRGB()==Red.getRGB()){
                        rule.chess[rule.Check_Chess_Position(temp.getName())].change_position(null);}
                    board_position[prePosition].setIcon(null);
                    rule.chess[curPosition].change_position(temp.getName());
                    if(temp.getName().charAt(1)=='7'){
                        if(!rule.chess[curPosition].Check_Rotate())
                            rule.chess[curPosition].Rotate();}
                    else if(temp.getName().charAt(1)=='1'){
                        if(rule.chess[curPosition].Check_Rotate())
                            rule.chess[curPosition].Rotate();}
                }
                rule.change_color_turn();
                placedChess();
                if(rule.Win()!=null){
                    JOptionPane.showMessageDialog(new JFrame(),"The Winner is Player " + rule.Win() + ".");
                    board.setVisible(false);}
            }
            else
                for(JButton x:board_position)
                      x.setBackground(White);
        }
    }
    
    //change the position into the which button number and return it
    private int position_to_num(String position)
    {
        if(rule.get_color_turn().compareTo("Green")==0)
        {
            for(int y=7,i=0; y>=1; y--)
                for(char x='A'; x<='G'; x++)
                {
                    if(position.compareTo(Character.toString(x)+String.valueOf(y))==0){
                        return i;}
                    i++;
                }
        }
        else
        {
            for(int y=7,i=48; y>=1; y--)
                for(char x='A'; x<='G'; x++)
                {
                    if(position.compareTo(Character.toString(x)+String.valueOf(y))==0){
                        return i;}
                    i--;
                }
        }
        return -99;
    }
}
