import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

/* *********|**********|**********|
Program: SaveLoad.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//This class is act as the controll of the LoadGUI,rule and GUIBoard. It can save and load file.
public class SaveLoad implements ChangeListener
{
    private Load_GUI loadGUI;
    private Chess_Rule rule;
    private GUI_Board board;
    private Board_Controlled boardControlled;
    int num;
    
    //construter of SaveLoad
    public SaveLoad(Chess_Rule rule, Load_GUI loadGUI,GUI_Board board,Board_Controlled boardControlled,JButton b2)
    {
        num=0;
        this.loadGUI=loadGUI;
        this.rule=rule;
        this.board=board;
        this.boardControlled=boardControlled;
        b2.addActionListener(new Load());
        JMenuItem save=board.getSaveItemMenu();
        save.addActionListener(new Save());
        JMenuItem load=board.getLoadItemMenu();
        load.addActionListener(new Load());
        loadGUI.setVisible(false);
    }
    
    //Read the file and change the position of the chess, color turn and place the chess to the gui board and make it visible
    public void loadFile(String fileName)
    {
            try {
            File file=new File(fileName);
            Scanner scan = new Scanner(file);
            int num=0;
            String line;
            while(scan.hasNextLine())
            {   line=scan.nextLine();
                if(num<28)
                {
                    String[] word=line.split(" ",3);
                    if(word[0].compareTo("null")==0)
                        rule.chess[num].change_position(null);
                    else
                        rule.chess[num].change_position(word[0]);
                    Boolean bool;
                    bool=(word[1].compareTo("true")==0)?true:false;
                    if( (rule.chess[num].Check_Rotate() && !bool) || (!(rule.chess[num].Check_Rotate()) && bool))
                        rule.chess[num].Rotate();
                    num++;
                    continue;
                }
                
                String[] word=line.split(" ",2);
                rule.change_color_turn(word[0]);
                if(word[0].compareTo("Green")==0)
                    rule.change_num_turn(Integer.valueOf(word[1]), Integer.valueOf(word[1]));
                else
                    rule.change_num_turn(Integer.valueOf(word[1]), (Integer.valueOf(word[1]) -1 ));
            }
                boardControlled.Game();
                loadGUI.setVisible(false);
           }  
            catch (IOException e){
            e.printStackTrace();
        }
    }
    
    //write all of the chess position, rotate, and the current player clor turn
    public void saveFile(String fileName)
    {
        fileName=(fileName==null)?"Save/save"+loadGUI.getBtn().size()+".txt":"Save/"+fileName;
        if(fileName.substring(fileName.length()-4, fileName.length()).compareTo(".txt") != 0)
            fileName=fileName+".txt";
        File file=new File(fileName);
        try{
            if(file.exists())
                file.delete();
            file.createNewFile();
        }catch (IOException e){e.printStackTrace();}
        try{
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
                for(Chess x:rule.chess){
                String position=(x.get_position()==null)?"null":x.get_position();
                writer.write(position);
                writer.write(" ");
                writer.write(Boolean.toString(x.Check_Rotate()));
                writer.newLine();
            }
            writer.write(rule.get_color_turn()+" ");
            writer.write(String.valueOf(rule.get_num_green_turn()));
            writer.newLine();
            writer.close();
        }catch (IOException e){e.printStackTrace();}
        
    }
    
    
    //Call the Load GUI and make it visible
    public void initial()
    {
        loadGUI.startLoad();
        for(JButton x: loadGUI.getBtn())
        {
            loadGUI.getLoadPanel().add(x);
            loadGUI.getLoadPanel().setSize(100,50);loadGUI.setVisible(true);
            x.addChangeListener(this);
        }
        num=loadGUI.getBtn().size();
        loadGUI.setVisible(true);
    }
    
    //to get which file to be load
    @Override
    public void stateChanged(ChangeEvent e)
    {
        JButton temp = (JButton)e.getSource();
        if(temp.getModel().isPressed())
        {
            loadFile(temp.getName());
        }
    }
    
    //Save the file and the user and name as he/she like
    private class Save implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            loadGUI.startLoad();
            JFrame frame = new JFrame("Save");
            String fileName = JOptionPane.showInputDialog(frame, "Save as (.txt):","save"+loadGUI.getBtn().size());
            if(fileName!=null)
                saveFile(fileName);
        }
    }
    
    //Call the Load_GUI
    private class Load implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            initial();
        }
    }
}
