import javax.swing.*;
import java.awt.*;
/* *********|**********|**********|
Program: GUI_Board.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101313@student.edu.my
Phone: 018-9730678
**********|**********|********* */

//This class is act as View and create the gui of the board  and is applied Singleton
public class GUI_Board extends JFrame
{
    private static GUI_Board board=new GUI_Board();
    private JButton[] board_position = new JButton[49];
    private JMenuItem save = new JMenuItem("Save Game");
    private JMenuItem load = new JMenuItem("Load Game");
    
    //singleton will be applied. GUI_Board will create by own and return itself to the other
    public static GUI_Board getBoard(){return board;}
    
    
    //get the button of the GUIBoard
    public JButton[] getBoardPosition()
    {return board_position;}
    
    //get the menuitem of save
    public JMenuItem getSaveItemMenu()
    {return save;}
    
    //get the menuitem of load
    public JMenuItem getLoadItemMenu()
    {return load;}
    
    
    
    public GUI_Board()
    {
        super("Chess");
        setDefaultCloseOperation(HIDE_ON_CLOSE);//the Close button is set to make it visible to false
        setLayout(new BorderLayout(0,2)); 
        setMinimumSize(new Dimension(300, 350));//the minimun of the board gui size is set to 300,350
        JMenuBar mb = new JMenuBar();
        JMenu menu1 = new JMenu("Game");
        menu1.add(save);
        menu1.add(load);
        mb.add(menu1);
        setJMenuBar(mb);
        
        JPanel pcenter=new JPanel(new GridLayout(7,0));
        Color White=new Color(255,255,255);
        for(JButton x:board_position)
        {
            
        }
        for(int y=7,i=0;y>0;y--)
        {
            for(char x='A'; x<='G'; x++)
            {
                board_position[i]=new JButton();
                board_position[i].setName(Character.toString(x)+String.valueOf(y));
                board_position[i].setBackground(White);
                board_position[i].setIcon(null);
                
                pcenter.add(board_position[i]);
                i++;
            }
        }
        
        
        add(pcenter,BorderLayout.CENTER);
        setSize(600,600);
    }
    
}
