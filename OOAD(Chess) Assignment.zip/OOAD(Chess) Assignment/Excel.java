import javax.swing.ImageIcon;

/* *********|**********|**********|
Program: Excel.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//this class act as model
public class Excel extends Chess
{
    //constructer of the Excel
    public Excel(String position,IColorChess colorChess)
    {
        super(position);
        this.color=colorChess.getChessColor();
        name="Excel";
            if(colorChess.getChessColor().compareTo("Green")==0)
                image_chess=new ImageIcon("excel.gif");
            else
                image_chess=new ImageIcon("excelRed.gif");
    }
    
    //it will get the movement of the chess by passing the String like A2A3
    //this movement position is not care any oof the other chess is block or not
    @Override
    public String[] Movement()
    {
        char axisX=position.charAt(0);
        int axisY=Character.getNumericValue(position.charAt(1));
        String[] next_position = new String[4];
        for(int x=1,y=1; (axisX+x)<='G' && (axisY+y)<=7; x++,y++)
            if(next_position[0]==null)
            next_position[0]=(Character.toString((char)(axisX+x))+String.valueOf(axisY+y));
            else
            next_position[0]+=(Character.toString((char)(axisX+x))+String.valueOf(axisY+y));
        
        for(int x=1,y=1; (axisX-x)>='A' && (axisY+y)<=7; x++,y++)
            if(next_position[1]==null)
            next_position[1]=(Character.toString((char)(axisX-x))+String.valueOf(axisY+y));
            else
            next_position[1]+=(Character.toString((char)(axisX-x))+String.valueOf(axisY+y));
        
        for(int x=1,y=1; (axisX+x)<='G' && (axisY-y)>=1; x++,y++)
            if(next_position[2]==null)
            next_position[2]=(Character.toString((char)(axisX+x))+String.valueOf(axisY-y));
            else
            next_position[2]+=(Character.toString((char)(axisX+x))+String.valueOf(axisY-y));
        
        for(int x=1,y=1; (axisX-x)>='A' && (axisY-y)>=1; x++,y++)
            if(next_position[3]==null)
            next_position[3]=(Character.toString((char)(axisX-x))+String.valueOf(axisY-y));
            else
            next_position[3]+=(Character.toString((char)(axisX-x))+String.valueOf(axisY-y));
        
        return next_position;
    }
}
