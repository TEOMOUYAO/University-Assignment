import javax.swing.ImageIcon;

/* *********|**********|**********|
Program: Chief.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//this class act as model
public class Advancer extends Chess
{
    //constructer of the advancer 
    public Advancer(String position,IColorChess colorChess)
    {
        super(position);
        this.color=colorChess.getChessColor();
        name="Advancer";
            if(colorChess.getChessColor().compareTo("Green")==0)
                image_chess=new ImageIcon("Advancer.gif");
            else
                image_chess=new ImageIcon("AdvancerRed.gif");
    }
    
    //it will get the movement of the chess by passing the String like A2A3
    //this movement position is not care any oof the other chess is block or not
    @Override
    public String[] Movement()
    {
        char axisX=position.charAt(0);
        int axisY=Character.getNumericValue(position.charAt(1));
        String[] next_position = new String[1];
        if(rotate)
        {
            for(int y=axisY;(axisY-1)>=(y-2);axisY--)
            {
                if(axisY-1>=1)
                    if(next_position[0]==null)
                        next_position[0]=(axisX+String.valueOf(axisY-1));
                    else
                        next_position[0]+=(axisX+String.valueOf(axisY-1));
            }
        }
        else
        {
            for(int y=axisY;(axisY+1)<=(y+2);axisY++)
            {
                if(axisY+1<=7)
                    if(next_position[0]==null)
                        next_position[0]=(axisX+String.valueOf(axisY+1));
                    else
                        next_position[0]+=(axisX+String.valueOf(axisY+1));
            }
        };
        return next_position;
    }
}
