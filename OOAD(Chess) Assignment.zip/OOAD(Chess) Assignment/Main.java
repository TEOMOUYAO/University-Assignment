import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.BorderLayout;


/* *********|**********|**********|
Program: Main.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101313@student.edu.my
Phone: 018-9730678
**********|**********|********* */


//this class is use as the main . It will create the Main Menu
public class Main extends JFrame
{
    static GUI_Board gui_board;
    Board_Controlled board_controlled;
    static Chess_Rule rule;
    static Load_GUI loadGUI;
    SaveLoad saveLoadControlled;
    
    public Main()
    {
       //Create a frame name Chess Time
       super("Chess Time");
       super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       //Create button,panel and add the action listener
       JButton button1 = new JButton("Start Game"); //this button 1 action listener will be add in the BoardControlled class
       JButton button2 = new JButton("Load Game");  //this button 2 actionlistener will be add in the SaveLoad class 
       JButton button3 = new JButton("Exit");
       button3.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){System.exit(0);}      //this button 3 will end this application
        });
       JLayeredPane panel4 = new JLayeredPane();
       
       //initialize the model, view and controlled
       gui_board=GUI_Board.getBoard();
       rule=Chess_Rule.getChessRule();
       board_controlled=new Board_Controlled(rule,gui_board,button1);
       loadGUI=Load_GUI.getLoadGUI();
       saveLoadControlled= new SaveLoad(rule,loadGUI,gui_board,board_controlled,button2);
       
       //add panel and button into the frame
       add(panel4);
       super.setFocusable(true);
       super.setSize(400,400);
       button1.setLocation(super.getWidth()/2-100, super.getHeight()/12*2);
       button1.setBackground(Color.WHITE);
       button1.setSize(200, 50);
       button2.setLocation(super.getWidth()/2-100, super.getHeight()/12*5);
       button2.setBackground(Color.WHITE);
       button2.setSize(200, 50);
       button3.setLocation(super.getWidth()/2-100, super.getHeight()/12*8);
       button3.setBackground(Color.WHITE);
       button3.setSize(200, 50);
       panel4.add(button1,1,-1);
       panel4.add(button2,2,-1);
       panel4.add(button3,3,-1);
       
       //setLayout(new GridBagLayout());

       super.setVisible(true);      //main menu set to visible
       super.setResizable(false); //only the main menu cannot resized
    }

    //run program
    public static void main(String[] args)
    { 
        Main m=new Main();
    }
}
