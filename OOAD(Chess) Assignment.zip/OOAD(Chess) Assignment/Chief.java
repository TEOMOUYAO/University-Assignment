import javax.swing.ImageIcon;

/* *********|**********|**********|
Program: Chief.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//this class act as model
public class Chief extends Chess
{
    //Constructer of the Chief
    public Chief(String position,IColorChess colorChess)
    {
        super(position);
        this.color=colorChess.getChessColor();
        name="Chief";
        if(colorChess.getChessColor().compareTo("Green")==0)
            image_chess=new ImageIcon("Chief.gif");
        else
            image_chess=new ImageIcon("ChiefRed.gif");
    }
    
    //it will get the movement of the chess by passing the String like A2A3
    //this movement position is not care any oof the other chess is block or not
    @Override
    public String[] Movement()
    {
        char axisX=position.charAt(0);
        int axisY=Character.getNumericValue(position.charAt(1));
        String[] next_position = new String[1];
        for(int i=-1; i<=1; i++)
        {
            if(axisY+1<=7)
            {
                if(axisX+i>='A' && axisX+i<='G')
                    if(next_position[0]==null)
                    next_position[0]=(Character.toString((char)(axisX+i))+String.valueOf(axisY+1));
                    else
                    next_position[0]+=(Character.toString((char)(axisX+i))+String.valueOf(axisY+1));
            }
            if(axisY-1>=1)
            {
                if(axisX+i>='A' && axisX+i<='G')
                    if(next_position[0]==null)
                    next_position[0]=(Character.toString((char)(axisX+i))+String.valueOf(axisY-1));
                    else
                    next_position[0]+=(Character.toString((char)(axisX+i))+String.valueOf(axisY-1));
            }
        }
        if(axisX-1>='A')
            if(next_position[0]==null)
                next_position[0]=(Character.toString((char)(axisX-1))+String.valueOf(axisY));
            else
                next_position[0]+=(Character.toString((char)(axisX-1))+String.valueOf(axisY));
        if(axisX+1<='G')
            if(next_position[0]==null)
                next_position[0]=(Character.toString((char)(axisX+1))+String.valueOf(axisY));
            else
                next_position[0]+=(Character.toString((char)(axisX+1))+String.valueOf(axisY));
        return next_position;
    }
}
