/* *********|**********|**********|
Program: IColorChess.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101313@student.edu.my
Phone: 018-9730678
**********|**********|********* */

//interface classes and will be the bridge structure
public interface IColorChess
{
    public String getChessColor();//get color
}
