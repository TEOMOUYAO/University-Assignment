import javax.swing.ImageIcon;

/* *********|**********|**********|
Program: Tercel.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//this class act as model
public class Tercel extends Chess
{
    //constructer of the Tercel
    public Tercel(String position,IColorChess colorChess)
    {
        super(position);
        this.color=colorChess.getChessColor();
        name="Tercel";
            if(colorChess.getChessColor().compareTo("Green")==0)
            image_chess=new ImageIcon("tercel.gif");
            else
            image_chess=new ImageIcon("tercelRed.gif");
    }
    
    //it will get the movement of the chess by passing the String like A2A3
    //this movement position is not care any oof the other chess is block or not
    @Override
    public String[] Movement()
    {
        char axisX=position.charAt(0);
        int axisY=Character.getNumericValue(position.charAt(1));
        String[] next_position = new String[4];
        for(int y=1;(axisY+y)<=7;y++)
            if(next_position[0]==null)
            next_position[0]=(Character.toString(axisX)+String.valueOf(axisY+y));
            else
            next_position[0]+=(Character.toString(axisX)+String.valueOf(axisY+y));
        
        for(int y=1;(axisY-y)>=1;y++)
            if(next_position[1]==null)
            next_position[1]=(Character.toString(axisX)+String.valueOf(axisY-y));
            else
            next_position[1]+=(Character.toString(axisX)+String.valueOf(axisY-y));
        
        for(int x=1;(axisX+x)<='G';x++)
            if(next_position[2]==null)
            next_position[2]=(Character.toString((char)(axisX+x))+String.valueOf(axisY));
            else
            next_position[2]+=(Character.toString((char)(axisX+x))+String.valueOf(axisY));
        
        for(int x=1;(axisX-x)>='A';x++)
            if(next_position[3]==null)
            next_position[3]=(Character.toString((char)(axisX-x))+String.valueOf(axisY));
            else
            next_position[3]+=(Character.toString((char)(axisX-x))+String.valueOf(axisY));
        
        return next_position;
    }
}
