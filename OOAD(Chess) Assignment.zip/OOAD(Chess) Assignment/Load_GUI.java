import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.nio.file.Path; 
import java.nio.file.Paths; 

/* *********|**********|**********|
Program: Load_GUI.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101313@student.edu.my
Phone: 018-9730678
**********|**********|********* */

//This class is the view of the Load and is applied Singleton
public class Load_GUI extends JFrame
{
    private static Load_GUI loadGUI=new Load_GUI();
    private ArrayList<JButton> loadBtn = new ArrayList<JButton>();;
    private JPanel p=new JPanel(new GridLayout(0,1,0,10));
    
    //singleton will be applied. Load_GUI will create by own and return itself to the other
    public static Load_GUI getLoadGUI()
    {return loadGUI;}
    
    public Load_GUI()
    {
        super("Load");
        super.setDefaultCloseOperation(HIDE_ON_CLOSE);//the Close button is set to make it visible to false
        JScrollPane scrollPane = new JScrollPane(p,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        setPreferredSize(new Dimension(300, 200));
        setMinimumSize(new Dimension(300, 200));//the minimun size of frame is set to 300,200
        pack();
    }
    
    //this file is to add the button of the load into the arraylist
    public void startLoad()
    {
        File folder = new File("./Save");
        List<String> result = new ArrayList<>();
        search(".*\\.txt", folder, result);
        for(String x:result)
        {
            if(loadBtn.size()!=0)
            {
                Boolean check=false;
                for(JButton y:loadBtn)
                    if(x.compareTo(y.getName())==0)
                        check=true;
                if(check)
                    continue;
            }
            Path path = Paths.get(x);
            Path fileName = path.getFileName(); 
            loadBtn.add(new JButton(fileName.toString().substring(0,fileName.toString().length()-4)));
            loadBtn.get(loadBtn.size()-1).setName(x);
        }
    }
    
    //this function is to search the current folder contain all of the pattern file
    public static void search(String pattern, File folder, List<String> result) {
        for (File f : folder.listFiles()) {

            if (f.isDirectory()) {
                search(pattern, f, result);
            }

            if (f.isFile()) {
                if (f.getName().matches(pattern)) {
                    result.add(f.getAbsolutePath());
                }
            }

        }
    }
    
    //get the button of the load
    public ArrayList<JButton> getBtn()
    {
        return loadBtn;
    }
    
    //get the panel
    public JPanel getLoadPanel()
    {
        return p;
    }
}
