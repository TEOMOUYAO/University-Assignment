/* *********|**********|**********|
Program: GUI_Board.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101313@student.edu.my
Phone: 018-9730678
**********|**********|********* */


//this class act as model
//this class is use to apply the rule to the chess like chess movement cannot jump over other chess
//exhange excel to tercel and tercel to excel after 3 turn
// is applied Singleton
public class Chess_Rule
{
    private static Chess_Rule rule=new Chess_Rule();
    public Chess[] chess;
    private int seleted_chess,num_red_turn,num_green_turn;
    private String color_turn;
    
    //singleton will be applied. Chess_Rule will create by own and return itself to the other
    public static Chess_Rule getChessRule(){return rule;}
    
    //constructer of the Chess_Rule
    public Chess_Rule()
    {
        num_red_turn=0; num_green_turn=0;
        chess=new Chess[28];
        color_turn="Green";
        
        chess[0]=new Tercel("A1",new GreenChess());
        chess[1]=new Tercel("G1",new GreenChess());
        chess[2]=new Excel("B1",new GreenChess());
        chess[3]=new Excel("F1",new GreenChess());
        chess[4]=new Trident("C1",new GreenChess());
        chess[5]=new Trident("E1",new GreenChess());
        chess[6]=new Chief("D1",new GreenChess());
        char temp='A';
        for(int i=0; i<7; i++)
        {
            chess[7+i]=new Advancer(temp+String.valueOf(2), new GreenChess());
            chess[21+i]=new Advancer(temp+String.valueOf(6), new RedChess());
            chess[21+i].Rotate();
            temp++;
        }
        
        chess[14]=new Tercel("A7",new RedChess());
        chess[15]=new Tercel("G7",new RedChess());
        chess[16]=new Excel("B7",new RedChess());
        chess[17]=new Excel("F7",new RedChess());
        chess[18]=new Trident("C7",new RedChess());chess[18].Rotate();
        chess[19]=new Trident("E7",new RedChess());chess[19].Rotate();
        chess[20]=new Chief("D7",new RedChess());
        color_turn="Green";
    }
    
    //rearrange the position of the chess and which color first
    public void New_Game()
    {
        num_red_turn=0; num_green_turn=0;
        color_turn="Green";
        
        chess[0].change_position("A1");
        chess[1].change_position("G1");
        chess[2].change_position("B1");
        chess[3].change_position("F1");
        chess[4].change_position("C1");if(chess[4].Check_Rotate())chess[7+1].Rotate();
        chess[5].change_position("E1");if(chess[5].Check_Rotate())chess[7+1].Rotate();
        chess[6].change_position("D1");
        char temp='A';
        for(int i=0; i<7; i++)
        {
            chess[7+i].change_position(temp+String.valueOf(2));
            if(chess[7+i].Check_Rotate())chess[7+1].Rotate();
            chess[21+i].change_position(temp+String.valueOf(6));
            if(!(chess[21+i].Check_Rotate()) )chess[21+i].Rotate();
            temp++;
        }
        
        chess[14].change_position("A7");
        chess[15].change_position("G7");
        chess[16].change_position("B7");
        chess[17].change_position("F7");
        chess[18].change_position("C7");if(!(chess[18].Check_Rotate()) )chess[18].Rotate();
        chess[19].change_position("E7");if(!(chess[19].Check_Rotate()) )chess[19].Rotate();
        chess[20].change_position("D7");
    }
    
    //it will get the num of which chess is staying in current position if get -99 then it mean not chess is current position
    public int Check_Chess_Position(String position)
    {
        int i=0;
        for(Chess x: chess)
        {
            if(x.get_position()==null){i++;
                continue;}
            if(x.get_position().compareTo(position)==0)
                return i;
            i++;
        }
        i=-99;
        return i;
    }
    
    //get the movement position of the chess if the position have any other chess then the movement position will end at ther
    //like A1A2A3A4A5A6A7 it have a chess at A3 then the movement position will become A1A2A3
    public String[] Predict_Movement_Chess(String position)
    {
        String[] movement;
        String name;
        seleted_chess=Check_Chess_Position(position);
        movement=chess[seleted_chess].Movement();
        name=chess[seleted_chess].get_name();

        for(int x=0; x<movement.length; x++)
        {
            if(movement[x]==null)
                continue;
            else if(name.compareTo("Chief")!=0)
            {
                String temp_position;
                for(int i=0;i<movement[x].length();i+=2)
                {
                    temp_position=movement[x].substring(i,i+2);
                    if(Check_Chess_Position(temp_position)!=-99){
                        movement[x]=movement[x].substring(0,i+2);continue;}
                }
            }
        }
        return movement;
    }
    
    //change player color turn
    public void change_color_turn()
    {
        if(color_turn.compareTo("Green")==0)
            num_green_turn++;
        else
            num_red_turn++;
        if(num_green_turn==3 || num_red_turn==3)
            Exchange_Excel_Tercel();
        color_turn=(color_turn.compareTo("Green")==0)?"Red":"Green";
    }
    
    //change color turn
    public void change_color_turn(String color)
    {
        if(color.compareTo("Green")==0)
            color_turn="Green";
        else if(color.compareTo("Red")==0)
            color_turn="Red";
    }
    
    //get color turn
    public String get_color_turn(){return color_turn;}
    
    //change color number turn
    public void change_num_turn(int green,int red)
    {
        num_green_turn=green;
        num_red_turn=red;
    }
    
    //change excel to tercel and tercel to excel
    public void Exchange_Excel_Tercel()
    {
        if(color_turn.compareTo("Green")==0)
        {
            for(int i=0; i<2; i++)
            {
                String temp_position=chess[i].get_position();
                chess[i].change_position(chess[i+2].get_position());
                chess[i+2].change_position(temp_position);
            }
            num_green_turn=0;
        }
        else
        {
            for(int i=14; i<16; i++)
            {
                String temp_position=chess[i].get_position();
                chess[i].change_position(chess[i+2].get_position());
                chess[i+2].change_position(temp_position);
            }
            num_red_turn=0;
        }
    }
    
    //get which player color win the game if null not one win yet
    public String Win()
    {
        if(chess[20].get_position()==null)
            return "Green";
        else if(chess[6].get_position()==null)
            return "Red";
        return null;
    }
    
    //get which chess is selected
    public int get_seleted_chess()
    {return seleted_chess;}
    
    //get number of turn green
    public int get_num_green_turn()
    {return num_green_turn;}
    
    //get number of turn red
    public int get_num_red_turn()
    {return num_red_turn;}
}
