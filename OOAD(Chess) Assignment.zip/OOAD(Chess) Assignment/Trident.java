import javax.swing.ImageIcon;

/* *********|**********|**********|
Program: Trident.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//this class act as model
public class Trident extends Chess
{
    //constructer of Trident
    public Trident(String position,IColorChess colorChess)
    {
        super(position);
        this.color=colorChess.getChessColor();
        name="Trident";
        if(colorChess.getChessColor().compareTo("Green")==0)
            image_chess=new ImageIcon("Trident.gif");
        else
            image_chess=new ImageIcon("TridentRed.gif");
    }
    
    //it will get the movement of the chess by passing the String like A2A3
    //this movement position is not care any oof the other chess is block or not
    @Override
    public String[] Movement()
    {
        char axisX=position.charAt(0);
        int axisY=Character.getNumericValue(position.charAt(1));
        String[] next_position = new String[3];
        
        for(int x=1;(axisX+x)<='G';x++)
            if(next_position[1]==null)
                next_position[1]=(Character.toString((char)(axisX+x))+String.valueOf(axisY));
            else
                next_position[1]+=(Character.toString((char)(axisX+x))+String.valueOf(axisY));
        for(int x=1;(axisX-x)>='A';x++)
            if(next_position[2]==null)
                next_position[2]=(Character.toString((char)(axisX-x))+String.valueOf(axisY));
            else
                next_position[2]+=(Character.toString((char)(axisX-x))+String.valueOf(axisY));
        if(rotate)
        {
            if(next_position[0]==null)
            next_position[0]=(axisX+String.valueOf(axisY-1));
            else
            next_position[0]+=(axisX+String.valueOf(axisY-1));
        }
        else
        {
            if(next_position[0]==null)
            next_position[0]=(axisX+String.valueOf(axisY+1));
            else
            next_position[0]+=(axisX+String.valueOf(axisY+1));
        }
        return next_position;
    }
}
