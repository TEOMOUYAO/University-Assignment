/* *********|**********|**********|
Program: GreenChess.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Teo Mou Yao
ID: 1171101313
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101313@student.edu.my
Phone: 018-9730678
**********|**********|********* */

//it will create a color "Green"
public class GreenChess implements IColorChess
{
    private String ChessColor;

    public GreenChess()
    {
        this.ChessColor="Green";
    }
    
    @Override
    public String getChessColor()
    {
        return this.ChessColor;
    }
}
