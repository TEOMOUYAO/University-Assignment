import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import javax.swing.Icon;

/* *********|**********|**********|
Program: RotatedIcon.java
Course: OOAD
Year: 2019/20 Trimester 1
Name: Low Sheng Rong
ID: 1171102238
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171102238@student.edu.my
Phone: 010-3117070
**********|**********|********* */

//thiss class is to get the image that is rotate
public class RotatedIcon implements Icon
{
	public enum Rotate
    	{
    		UP,
    		UPSIDE_DOWN,
    	}

	private Icon icon;

	private Rotate rotate;

	public RotatedIcon(Icon icon)
	{
		this(icon, Rotate.UP);
	}
	
	public RotatedIcon(Icon icon, Rotate rotate)
	{
		this.icon = icon;
		this.rotate = rotate;
	}
	
    	public Icon getIcon()
    	{
    		return icon;
    	}
    	
    	public Rotate getRotate()
    	{
    		return rotate;
    	}

	@Override
	public int getIconWidth()
	{
		if (rotate == Rotate.UPSIDE_DOWN)
			return icon.getIconWidth();
		else
			return icon.getIconHeight();
	}
	
	@Override
	public int getIconHeight()
	{
		if (rotate == Rotate.UPSIDE_DOWN)
			return icon.getIconHeight();
		else
			return icon.getIconWidth();
	}
	
    	@Override
    	public void paintIcon(Component c, Graphics g, int x, int y)
    	{
    		Graphics2D g2 = (Graphics2D)g.create();
    
    		int cWidth = icon.getIconWidth() / 2;
    		int cHeight = icon.getIconHeight() / 2;
    		int xAdjustment = (icon.getIconWidth() % 2) == 0 ? 0 : -1;
    		int yAdjustment = (icon.getIconHeight() % 2) == 0 ? 0 : -1;
    
    		if (rotate == Rotate.UP)
    		{
    			g2.translate(x + cHeight, y + cWidth);
    			g2.rotate( Math.toRadians( -90 ) );
    			icon.paintIcon(c, g2,  xAdjustment - cWidth, -cHeight);
    		}
    		else if (rotate == Rotate.UPSIDE_DOWN)
    		{
    			g2.translate(x + cWidth, y + cHeight);
    			g2.rotate( Math.toRadians( 180 ) );
    			icon.paintIcon(c, g2, xAdjustment - cWidth, yAdjustment - cHeight);
    		}
    
    		g2.dispose();
    	}
}