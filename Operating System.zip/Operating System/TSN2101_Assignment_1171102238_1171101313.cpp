#include <iostream>
#include <tuple>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <sstream>
using namespace std;

bool compareArrival(const pair<int,tuple<int,int,int>>& p1,const pair<int,tuple<int,int,int>>& p2)
{
  if(get<1>(p1.second) < get<1>(p2.second))
    return (get<1>(p1.second) < get<1>(p2.second));
  else if(get<1>(p1.second) == get<1>(p2.second))
    return (get<2>(p1.second) < get<2>(p2.second));
}

bool checkRange(int x,int lowest,int highest)
{
  if(x>=lowest && x<=highest)
    return true;
  else
    return false;
}

class Process
{
private:
     vector<tuple<int,int,int>> process;
public:
    void add(int,int,int);
    void erase(int);
    void overview();
    void Three_level_Queue_Scheduling();
    void SRTN();
    void RR();
    void FCFS();
    int size(){return process.size();}
};

void Process::add(int burst=0, int arrival=0, int priority=1)
{
  process.emplace_back(make_tuple(burst,arrival,priority));
}

void Process::erase(int p)
{
  if(p<=process.size())
    process.erase(process.begin()+p);
  else
    cout<<"Process "<<p<<" does not exist"<<endl;
}

void Process::Three_level_Queue_Scheduling()
{
  if(process.size()<3)
  {cout<<"No enough process"<<endl<<endl;return;}
  else if(process.size()>10)
  {cout<<"Too many process"<<endl<<endl;return;}

  overview();
  vector<pair<int,tuple<int,int,int>>> copy_process;
  int finish_time=0;
  for(int x=0; x<process.size(); x++)
  {
    copy_process.emplace_back(make_pair(x,process[x]));
    finish_time+=get<0>(process[x]);
  }
  sort(copy_process.begin(), copy_process.end(), compareArrival);

  queue<pair<int,tuple<int,int,int>>> q1,q2,q3;
  pair<int, tuple<int,int,int>> temp;
  int time=get<1>(copy_process[0].second), NumberOfArrival=0, Quantam, left_time_2=0,left_time_3=0, find;
  int last1{-99},last2{-99},last3{-99};
  bool available1=true,available=true,available2=false;
  string r1{""},r2{""},r3{""};
  stringstream ss;
  cout<<"Quantam: ";
  cin>>Quantam;
  cout<<endl<<endl<<"Three level Queue SchedulingGantt Chart( "<<Quantam<< " Quantam ): "<<endl;
  cout<<time<<" ";
  for(;time<finish_time;)
  {
      while( time>=(get<1>(copy_process[NumberOfArrival].second)) )
      {
        if(NumberOfArrival>copy_process.size())
          break;
        switch (get<2>(copy_process[NumberOfArrival].second))
        {
          case 1:
          case 2:
          if(available2 && time==get<1>(copy_process[NumberOfArrival].second) && get<1>(copy_process[NumberOfArrival].second)> get<1>(temp.second))
          {
            q1.push(temp);
            available2=0;
          }
          q1.push(copy_process[NumberOfArrival]);
          break;
          case 3:
          case 4:
          q2.push(copy_process[NumberOfArrival]);break;
          case 5:
          case 6:
          q3.push(copy_process[NumberOfArrival]);break;
        }
        NumberOfArrival++;
      }
    if(available2)
    {
      q1.push(temp);
      available2=0;
    }

    if(!q1.empty())
    {
      ss.str("");
      ss.clear();
      ss<<time;
      if(time!=(last1))
        r1+=string(" ")+ss.str();
      cout<<"P"<<q1.front().first<<" ";
      if(get<0>(q1.front().second)>Quantam)
      {
        available2=true;
        time+=Quantam;
        temp=q1.front();
        get<0>(temp.second)-=Quantam;

        cout<<time<<" ";
        last1=time;
        ss.str("");
        ss.clear();
        ss<<string(" P")<<q1.front().first<<string(" ")<<time;
        r1+=ss.str();

        q1.pop();
      }
      else
      {
        time+=get<0>(q1.front().second);
        cout<<time<<" ";
        last1=time;

        ss.str("");
        ss.clear();
        ss<<string(" P")<<q1.front().first<<string(" ")<<time;
        r1+=ss.str();

        q1.pop();
      }

    }
    else if(!q2.empty())
    {
      ss.str("");
      ss.clear();
      ss<<time;
      left_time_2=get<0>(q2.front().second);
      for(int x=0; x<copy_process.size(); x++)
      {
        int tempTime=time+left_time_2;
        if(time < get<1>(copy_process[x].second) && tempTime >= get<1>(copy_process[x].second) && checkRange(get<2>(copy_process[x].second),1,2) )
        {
          available1=false;
          find=x;
          break;
        }
        else
          available1=true;
      }

      if(available1)
      {
        if(time!=(last2))
          r2+=string(" ")+ss.str();
        time+=get<0>(q2.front().second);
        cout<<"P"<<q2.front().first<<" "<<time<<" ";

        ss.str("");
        ss.clear();
        ss<<string(" P")<<q2.front().first<<string(" ")<<time;
        r2+=ss.str();
        last2=time;

        q2.pop();
      }
      else
      {
        if(time!=(last2))
          r2+=string(" ")+ss.str();
        get<0>(q2.front().second) -= (get<1>(copy_process[find].second) - time);
        time=get<1>(copy_process[find].second);
        cout<<"P"<<q2.front().first<<" "<<time<<" ";

        ss.str("");
        ss.clear();
        ss<<string(" P")<<q2.front().first<<string(" ")<<time;
        r2+=ss.str();
        last2=time;

      }

    }
    else if(!q3.empty())
    {
      ss.str("");
      ss.clear();
      ss<<time;
      left_time_3=get<0>(q3.front().second);
      for(int x=0; x<copy_process.size(); x++)
      {
        int tempTime=time+left_time_3;
        if(time < get<1>(copy_process[x].second) && tempTime >= get<1>(copy_process[x].second) && checkRange(get<2>(copy_process[x].second),1,4))
        {
          available=false;
          find=x;
          break;
        }
        else
          available=true;
      }

      if(available)
      {
        if(time!=(last3))
          r3+=string(" ")+ss.str();
        time+=get<0>(q3.front().second);
        cout<<"P"<<q3.front().first<<" "<<time<<" ";

        ss.str("");
        ss.clear();
        ss<<string(" P")<<q3.front().first<<string(" ")<<time;
        r3+=ss.str();

        q3.pop();
        last3=time;
      }
      else
      {
        if(time!=(last3))
          r3+=string(" ")+ss.str();
        get<0>(q3.front().second) -= (get<1>(copy_process[find].second) - time);
        time=get<1>(copy_process[find].second);
        cout<<"P"<<q3.front().first<<" "<<time<<" ";

        ss.str("");
        ss.clear();
        ss<<string(" P")<<q3.front().first<<string(" ")<<time;
        r3+=ss.str();
        last3=time;

      }
    }

  }
  cout<<endl<<endl;
  cout<<"Queue 1: "<<r1<<endl;
  cout<<"Queue 2: "<<r2<<endl;
  cout<<"Queue 3: "<<r3<<endl;
}

void Process :: SRTN()
{
  if(process.size()<3)
  {cout<<"No enough process"<<endl<<endl;return;}
  else if(process.size()>10)
  {cout<<"Too many process"<<endl<<endl;return;}


  overview();
  vector<pair<int,tuple<int,int,int>>> copy_process;
  int finish_time=0,NumberOfArrival=0,find=0,oldfind=0;
  bool change=0;
  for(int x=0; x<process.size(); x++)
  {
    copy_process.emplace_back(make_pair(x,process[x]));
    finish_time+=get<0>(process[x]);
  }
  sort(copy_process.begin(), copy_process.end(), compareArrival);
  int time = get<1>(copy_process[0].second);
  finish_time+=time;
  cout<<"SRTN Gantt Chart: "<<endl;
  for(int process_time=0; time<=finish_time; time++,process_time++, change=0)
  {

    while(get<1>(copy_process[NumberOfArrival].second)==time)
    {
      NumberOfArrival++;
      if(NumberOfArrival>1)
      {

        for(int x=0;x<NumberOfArrival;x++)
        {
          if(get<0>(copy_process[x].second)<=0)
            continue;
          if( get<0>(copy_process[find].second)<=0 || get<0>(copy_process[x].second)<(get<0>(copy_process[find].second)-process_time) )
          {
              find=x;
          }
          else if(get<0>(copy_process[x].second)==(get<0>(copy_process[find].second)-process_time))
          {
            if(get<2>(copy_process[x].second)<get<2>(copy_process[find].second))
            {
              find=x;
            }
          }
        }
        if(find!=oldfind)
          change=1;
      }
      else
      {
        change=1;
        process_time=0;
      }
    }


    if(get<0>(copy_process[find].second) == process_time && !change)
    {
      get<0>(copy_process[find].second)=0;
      for(int x=0;x<NumberOfArrival;x++)
      {
        if(get<0>(copy_process[x].second)<=0)
          continue;
        if(get<0>(copy_process[find].second)<=0||get<0>(copy_process[x].second)<get<0>(copy_process[find].second))
        {
            find=x;
        }
        else if(get<0>(copy_process[x].second)==get<0>(copy_process[find].second))
        {
          if(get<2>(copy_process[x].second)<get<2>(copy_process[find].second))
          {
            find=x;
          }
        }
        if(find!=oldfind)
          change=1;
      }
    }

    if(change)
    {
      get<0>(copy_process[oldfind].second)-=process_time;
      process_time=0;
      cout<<time<<" "<<"P"<<copy_process[find].first<<" ";
      oldfind=find;
    }

  }
  cout<<finish_time;
  cout<<endl<<endl;
}

void Process :: RR()
{
  if(process.size()<3)
  {cout<<"No enough process"<<endl<<endl;return;}
  else if(process.size()>10)
  {cout<<"Too many process"<<endl<<endl;return;}
  overview();
  vector<pair<int,tuple<int,int,int>>> copy_process;
  int finish_time=0, time, Quantam;
  for(int x=0; x<process.size(); x++)
  {
    copy_process.emplace_back(make_pair(x,process[x]));
    finish_time+=get<0>(process[x]);
  }
  sort(copy_process.begin(), copy_process.end(), compareArrival);
  time=get<1>(copy_process[0].second);
  finish_time+=time;
  queue<pair<int,tuple<int,int,int>>> q1,q2,q3,q4,q5,q6;
  pair<int, tuple<int,int,int>> temp;

  cout<<"Quantam: ";
  cin>>Quantam;
  cout<<endl<<endl<<"Round Robin Scheduling with Priority( "<<Quantam<< " Quantam ): "<<endl;
  bool isProcess=false;
  int numQueueProcess;

  for(int NumberOfArrival=0,processTime=0 ;time<=finish_time; time++,processTime++)
  {
    while(NumberOfArrival<copy_process.size() && time==(get<1>(copy_process[NumberOfArrival].second)) )
    {
      switch (get<2>(copy_process[NumberOfArrival].second))
      {
        case 1:q1.push(copy_process[NumberOfArrival]);break;
        case 2:q2.push(copy_process[NumberOfArrival]);break;
        case 3:q3.push(copy_process[NumberOfArrival]);break;
        case 4:q4.push(copy_process[NumberOfArrival]);break;
        case 5:q5.push(copy_process[NumberOfArrival]);break;
        case 6:q6.push(copy_process[NumberOfArrival]);break;
      }
      NumberOfArrival++;
    }
    if(isProcess)
    {
      if(get<0>(temp.second)!=processTime && processTime!=Quantam)
        continue;
      else if(processTime==Quantam){
        get<0>(temp.second)-=Quantam;
        cout<<"P"<<temp.first<<" ";
      }
      else{
        get<0>(temp.second)=0;
        cout<<"P"<<temp.first<<" ";
      }
      switch (numQueueProcess)
      {
        case 1:q1.pop();  if(get<0>(temp.second)!=0){q1.push(temp);}  break;
        case 2:q2.pop();  if(get<0>(temp.second)!=0){q2.push(temp);}  break;
        case 3:q3.pop();  if(get<0>(temp.second)!=0){q3.push(temp);}  break;
        case 4:q4.pop();  if(get<0>(temp.second)!=0){q4.push(temp);}  break;
        case 5:q5.pop();  if(get<0>(temp.second)!=0){q5.push(temp);}  break;
        case 6:q6.pop();  if(get<0>(temp.second)!=0){q6.push(temp);}  break;
      }
      isProcess=false;
    }

    if(!isProcess)
    {
        if(!q1.empty())
        {
          temp=q1.front();
          isProcess=true;
          numQueueProcess=1;
          processTime=0;
          cout<<time<<" ";
        }
        else if(!q2.empty())
        {
          temp=q2.front();
          isProcess=true;
          numQueueProcess=2;
          processTime=0;
          cout<<time<<" ";
        }
        else if(!q3.empty())
        {
          temp=q3.front();
          isProcess=true;
          numQueueProcess=3;
          processTime=0;
          cout<<time<<" ";
        }
        else if(!q4.empty())
        {
          temp=q4.front();
          isProcess=true;
          numQueueProcess=4;
          processTime=0;
          cout<<time<<" ";
        }
        else if(!q5.empty())
        {
          temp=q5.front();
          isProcess=true;
          numQueueProcess=5;
          processTime=0;
          cout<<time<<" ";
        }
        else if(!q6.empty())
        {
          temp=q6.front();
          isProcess=true;
          numQueueProcess=6;
          processTime=0;
          cout<<time<<" ";
        }
      }
  }
  cout<<finish_time<<endl<<endl;
}

void Process :: FCFS()
{
  if(process.size()<3)
  {cout<<"No enough process"<<endl<<endl;return;}
  else if(process.size()>10)
  {cout<<"Too many process"<<endl<<endl;return;}
  overview();
  vector<pair<int,tuple<int,int,int>>> copy_process;
  int finish_time=0, time,pastProcess=-99;
  for(int x=0; x<process.size(); x++)
  {
    copy_process.emplace_back(make_pair(x,process[x]));
    finish_time+=get<0>(process[x]);
  }
  sort(copy_process.begin(), copy_process.end(), compareArrival);

  auto comparePriority = [](const pair<int,tuple<int,int,int>>& p1,const pair<int,tuple<int,int,int>>& p2){
    if(get<2>(p1.second)==get<2>(p2.second))
      return get<1>(p1.second) > get<1>(p2.second);
    return get<2>(p1.second) > get<2>(p2.second);
  };
  priority_queue<pair<int,tuple<int,int,int>>, vector<pair<int,tuple<int,int,int>>>, decltype(comparePriority)> q1(comparePriority);
  pair<int, tuple<int,int,int>> temp;

  cout<<"FCFS (First Come First Served)-based pre-emptive Priority Gantt Chart: "<<endl;
  time=get<1>(copy_process[0].second);
  finish_time+=time;
  for(int NumberOfArrival=0,processTime=0 ;time<=finish_time; time++,processTime++)
  {
    for(auto &x:copy_process)
    {
      if(x.first==pastProcess)
      {
        if( (get<0>(x.second)-processTime) == 0)
          q1.pop();
      }
    }
    while(NumberOfArrival<copy_process.size() && time==(get<1>(copy_process[NumberOfArrival].second)) )
    {
      q1.push(copy_process[NumberOfArrival]);
      NumberOfArrival++;
    }
    if(q1.empty())
      continue;
    if(pastProcess != q1.top().first)
    {
        for(auto &x:copy_process)
          if(x.first==pastProcess)
            get<0>(x.second)-=processTime;
        processTime=0;
        pastProcess=q1.top().first;
        cout<<time<<" P"<<q1.top().first<<" ";
    }

  }
  cout<<finish_time<<endl<<endl;
}

void Process :: overview()
{
  cout<<"****************************** Process *******************************"<<endl;
  cout<<"Process     Burst Time     Arrival Time     Priority"<<endl;
  for(int x=0; x<process.size(); x++)
  {
    cout<<"P"<<x<<"          "<< get<0>(process[x]) <<"              "<< get<1>(process[x])<<"                "<< get<2>(process[x])<<endl;
  }
  cout<<"**********************************************************************"<<endl<<endl;
}


int main()
{
    Process p;
    int num,burst,arrival,priority,process;
    bool exit=false;
    for(;;)
    {
      cout<<"**********************************************************************"<<endl;
      cout<<"********************* Operating Systems Assignment *******************"<<endl;
      cout<<"**********************************************************************"<<endl;
      cout<<"**  1. Add Process                                                  **"<<endl;
      cout<<"**  2. Delete All Process                                           **"<<endl;
      cout<<"**  3. See All Process                                              **"<<endl;
      cout<<"**  4. FCFS (First Come First Served)-based pre-emptive Priority    **"<<endl;
      cout<<"**  5. Round Robin Scheduling with Priority                         **"<<endl;
      cout<<"**  6. Three-level Queue Scheduling                                 **"<<endl;
      cout<<"**  7. Shortest Remaining Time Next (SRTN) Scheduling with Priority **"<<endl;
      cout<<"**  8. Exit                                                         **"<<endl;
      cout<<"**********************************************************************"<<endl<<endl;
      do{
      cout<<"insert the num(1-8) to run the program: ";
      cin>>num;
    }while(!checkRange(num,1,8));
      switch(num)
      {
        case 1:
        for(;;){
        cout<<"Number of Process to be added: ";
        cin>>process;
        if(checkRange(process,0,10))
          break;
        }
        for(int i=0; i<process; i++)
        {
            cout<<"Process "<< p.size()<<endl;
            do{
            cout <<"Burst Time: ";
            cin>>burst;
          }while(!(burst>=0));
            do{
            cout<<"Arrival Time: ";
            cin>>arrival;
          }while(!(arrival>=0));
            do{
            cout<< "Priority(1-6): ";
            cin>>priority;
          }while(!checkRange(priority,1,6));
            p.add(burst,arrival,priority);
            cout<<endl;
        }
        break;
        case 2: for(int i=0; i<p.size();){
                    p.erase(0);}
                break;
        case 3: p.overview();break;
        case 4: p.FCFS();break;
        case 5: p.RR();break;
        case 6: p.Three_level_Queue_Scheduling();break;
        case 7: p.SRTN();break;
        case 8: exit=true;break;
        default: break;
      }
      if(exit)break;
    }
}
