/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#ifndef MYSHAPE_H
#define MYSHAPE_H

#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>

class MyShape
{
 protected:
	sf::RectangleShape* rect;
	sf::CircleShape* circle;
	sf::Shape* shape;
	b2Body* body_;
	b2BodyDef bodyDef_;
	b2PolygonShape bodyRectshape;
	b2CircleShape bodyCirshape;
	b2FixtureDef bodyFixtureDef_;
	bool isDestroyed;
	bool isBodyDestroyed;


 public:
	MyShape();
	MyShape(b2World& world,int radius,sf::Vector2f position,
			bool isDynamic = true);
	MyShape(b2World& world,sf::Vector2f size,sf::Vector2f position,
		    bool isSensor = false,bool isDynamic = true);
	
	void setFillColor(sf::Color col);
	void setOutlineThickness(float thickness);
	void setOutlineColor(sf::Color col);
	void setUserData(void* data);
	void setPosition(sf::Vector2f position);
	b2Vec2 getPosition();
	void update(float offsetY);
	void updatePosition(float speed);
	float getOffsetY();
	bool isThisMyBody(b2Body*);
	void destroyBody(b2World&);
	bool getDestroy();
	bool getBodyDestroyed();
	void setDestroy();
	sf::Shape* getShape();
	

};
#endif
