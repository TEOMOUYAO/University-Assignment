/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#ifndef CHARACTER_H
#define CHARACTER_H
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>
#include "MyShape.h"

class Character : public MyShape
{
 private:
	float health;
	bool isAllowLeftMove;
	bool isAllowRightMove;
	bool isAllowJump;
 public:
	Character(b2World& world, sf::Vector2f size,sf::Vector2f position,
	float rotation = 0,bool isDynamic = true):MyShape(world,size,position,rotation,isDynamic){	
	health=3;
	isAllowLeftMove=true;
	isAllowRightMove=true;
	isAllowJump=true;}
	void takeDamage(float damage);
	float getHealth();
	void setFixedRotation(bool b);
	void setAllowLeftMove(bool b);
	void setAllowRightMove(bool b);
	void setAllowJump(bool b);
	bool getAllowJump();
	void move(char direction);
};
#endif
