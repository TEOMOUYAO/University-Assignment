/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
#include "EscapeTheLava.h"
#include <iostream>
using namespace std;


sf::Texture EscapeTheLava::loadTexture(const string& imageFilename)
{
  sf::Texture myTexture;
  if (!myTexture.loadFromFile(imageFilename))
  {
    cout << "Can not load image from " << imageFilename << endl;
    exit(1);
  }
  return myTexture;
}

sf::Font EscapeTheLava::loadFont(const std::string& fontFilename)
{
   sf::Font myFont;
   if (!myFont.loadFromFile(fontFilename))
   {
      std::cout << "Can not load font from " << fontFilename << std::endl;
      exit(1);
   }
   return myFont;
}

sf::SoundBuffer EscapeTheLava::loadSoundBuffer(const string& waveFilename)
{
  sf::SoundBuffer mySoundBuffer;
  if (!mySoundBuffer.loadFromFile(waveFilename))
  {
    cout << "Can not load sound from " << waveFilename << endl;  
    exit(1);
  }
  return mySoundBuffer;
}
  
sf::Sound EscapeTheLava::createSound(const sf::SoundBuffer& mySoundBuffer)
{
  sf::Sound mySound(mySoundBuffer);
  return mySound;
}


EscapeTheLava::EscapeTheLava(){
	font.loadFromFile("resources/fonts/04b03.ttf");
	scoringSystem = make_shared<ScoringSystem>();
	window.create(sf::VideoMode(windowSizeX, windowSizeY), "Escape The Lava");
	window.setVerticalSyncEnabled(true);
	window.setActive();
}


void EscapeTheLava::viewInstruction(){ // Kerk Chee Sheng

			sf:: Texture instructionTexture = loadTexture("resources/instruction.png");
			sf::RectangleShape gameInstruction(sf::Vector2f(windowSizeX,windowSizeY));
			gameInstruction.setOrigin(windowSizeX/2,windowSizeY/2);
			gameInstruction.setPosition(windowSizeX/2, windowSizeY/2);
			// gameInstruction.setFillColor(sf::Color::Yellow);
			gameInstruction.setTexture(&instructionTexture);	
			sf::Text anyKeyText;
			anyKeyText.setFont(font);
			anyKeyText.setCharacterSize(25);
			// anyKeyText.setStyle(sf::Text::Bold);
			anyKeyText.setPosition(windowSizeX-355,windowSizeY-50);
			anyKeyText.setFillColor(sf::Color::Red);
			// anyKeyText.setOutlineColor(sf::Color::Black);
			// anyKeyText.setOutlineThickness(-5);
			anyKeyText.setString("Press Enter to Start Game..");

			window.clear(sf::Color::White);
			window.draw(gameInstruction);
			window.draw(anyKeyText);
			window.display();
}

void EscapeTheLava::setup(){
	iniText();
	iniSound();
	run();
}


void EscapeTheLava::iniSound(){ // Kerk Chee Sheng
	
	//Sound 
	bgmBuffer.loadFromFile("resources/music/bgm.wav");
	bgmSound.setBuffer(bgmBuffer);
	bgmSound.play();
	bgmSound.setLoop(true);
	bgmSound.setVolume(100);

	
	lavaBuffer.loadFromFile("resources/music/lava.wav");
	lavaSound.setBuffer(lavaBuffer);
	lavaSound.play();
	lavaSound.setLoop(true);
	lavaSound.setVolume(25);

	earthquakeBuffer.loadFromFile("resources/music/earthquake.wav");
	earthquakeSound.setBuffer(earthquakeBuffer);
	earthquakeSound.setVolume(50);
			
	jumpBuffer.loadFromFile("resources/music/jump(cute).wav");
	jumpSound.setBuffer(jumpBuffer);
	jumpSound.setVolume(25);
	
	winBuffer.loadFromFile("resources/music/win.wav");
	winSound.setBuffer(winBuffer);
	winSound.setVolume(100);
	
	loseBuffer.loadFromFile("resources/music/lose.wav");
	loseSound.setBuffer(loseBuffer);
	loseSound.setVolume(100);
}

void EscapeTheLava::iniText(){ // Kerk Chee Sheng

	scoreText.setString("Score");
	scoreText.setFont(font);  
	scoreText.setCharacterSize(33);
	scoreText.setPosition(10, 15);
	scoreText.setFillColor(sf::Color::White);
	
	scoreNumText.setFont(font);  
	scoreNumText.setCharacterSize(36);
	scoreNumText.setPosition(25, 50);
	scoreNumText.setFillColor(sf::Color::White);
	
	timerText.setFont(font);  
	timerText.setCharacterSize(36);
	timerText.setPosition(815, 45);
	timerText.setFillColor(sf::Color::White);
	timerText.setString("Time");

	timerNumText.setFont(font);  
	timerNumText.setCharacterSize(33);
	timerNumText.setPosition(835, 80);
	timerNumText.setFillColor(sf::Color::White);

	lavaText.setFont(font);  
	lavaText.setCharacterSize(30);
	lavaText.setPosition(0, windowSizeY/2);
	
	stoneNumText.setFont(font);  
	stoneNumText.setCharacterSize(33);
	stoneNumText.setPosition(840,windowSizeY/2-20);
	stoneNumText.setFillColor(sf::Color::White);
	
	scoreBoardText.setFont(font);  
	scoreBoardText.setCharacterSize(20);
	scoreBoardText.setPosition(windowSizeX/2-80, windowSizeY/2-45);
	

}



void EscapeTheLava::run(){
	b2Vec2 gravity(0.f, 16.2f);
	b2World world(gravity);
	world.SetAllowSleeping(true);
	
	
	//SidePanel - Kerk Chee Sheng
	sf::Vector2f verticalMyShapeSize(windowMyShapeSize,5450);
	sf::Vector2f leftMyShapePos(windowMyShapeSize/2,-1775);
	sf::Vector2f rightMyShapePos(windowSizeX-windowMyShapeSize/2,-1775);
	
	MyShape leftMyShape(world, verticalMyShapeSize, leftMyShapePos, false, false);
	MyShape rightMyShape(world, verticalMyShapeSize, rightMyShapePos, false, false);
	leftMyShape.setUserData(&leftPanelID);
	rightMyShape.setUserData(&rightPanelID);
	
	//Lava - Kerk Chee Sheng
	float speed=1;
	sf::Vector2f bottomMyShapeSize(700,300);
	sf::Vector2f bottomMyShapePos(windowSizeX/2,1000);
	MyShape bottomMyShape(world, bottomMyShapeSize, bottomMyShapePos, false, false);
	bottomMyShape.setUserData(&lavaID);
	bottomMyShapePos.y-=35;
	sf::Texture* lavaFrame= new sf::Texture[6];
	lavaFrame[0]= loadTexture("resources/lava_frame0.png");
	lavaFrame[1]= loadTexture("resources/lava_frame1.png");
	lavaFrame[2]= loadTexture("resources/lava_frame2.png");
	lavaFrame[3]= loadTexture("resources/lava_frame3.png");
	lavaFrame[4]= loadTexture("resources/lava_frame4.png");
	lavaFrame[5]= loadTexture("resources/lava_frame5.png");
	
	
	//Plats - Kerk Chee Sheng & Teo Mou Yao
	int numPlats=66;
	int indexPlatList=0;
	sf::Vector2f smallPlatSize(100,20);
	sf::Vector2f bigPlatSize(200,20);

	vector<MyObject>platList;
	vector<shared_ptr<MyShape>> platShape;
	
	
	//plats Size and Position values - Teo Mou Yao 
	sf::Vector2f platSize[numPlats]={bigPlatSize,smallPlatSize,smallPlatSize,bigPlatSize,smallPlatSize,
									smallPlatSize,bigPlatSize,smallPlatSize,bigPlatSize,bigPlatSize,
									bigPlatSize,smallPlatSize,smallPlatSize,smallPlatSize,smallPlatSize,
									smallPlatSize,bigPlatSize,smallPlatSize,bigPlatSize,smallPlatSize,
									smallPlatSize,bigPlatSize,bigPlatSize,smallPlatSize,bigPlatSize,
									smallPlatSize,bigPlatSize,bigPlatSize,smallPlatSize,smallPlatSize,
									bigPlatSize,smallPlatSize,smallPlatSize,smallPlatSize,bigPlatSize,bigPlatSize, 
									smallPlatSize,smallPlatSize,bigPlatSize,smallPlatSize,smallPlatSize,
									smallPlatSize,bigPlatSize,bigPlatSize,bigPlatSize,smallPlatSize,
									bigPlatSize,bigPlatSize,smallPlatSize,smallPlatSize,bigPlatSize,
									smallPlatSize,smallPlatSize,smallPlatSize,bigPlatSize,smallPlatSize,
									bigPlatSize,bigPlatSize,smallPlatSize,smallPlatSize,bigPlatSize,
									smallPlatSize,smallPlatSize,
									bigPlatSize,bigPlatSize,bigPlatSize
									};
	
	float platPosX[numPlats]={200,350,450,600,750,
                              650,500,350,500,650,
                              400,750,250,150,300,
                              150,500,250,700,350,
                              150,300,650,450,220,    
                              450,200,550,750,530,     
                              350,700,750,550,400,300,     
                              750,150,400,380,150,        
                              550,700,500,350,750,
                              600,400,630,250,520,    
                              150,650,750,500,250,
                              500,250,750,530,270,    
                              680,150,
                              300,500,700
                            };


	float platPosY[numPlats]={850,755,660,565,470,
                              375,280,185,90,-5,
						     -100,-100,-195,-290,-385,
                             -480,-480,-575,-575,-670,
                             -765,-860,-860,-975,-1050,
                            -1145,-1240,-1335,-1430,-1525,
                            -1620,-1620,-1715,-1810,-1905,-2000,    
                            -2000,-2095,-2190,-2285,-2380,
                            -2380,-2475,-2570,-2665,-2665,
                            -2760,-2855,-2855,-2950,-3045,
                            -3140,-3140,-3235,-3330,-3425,
                            -3520,-3615,-3615,-3710,-3805,
                            -3805,-3900,
                            -3995,-3995,-3995
                            };
	
	//Plat List - Teo Mou Yao & Kerk Chee Sheng
	for(int i=0;i<numPlats;i++){
		platList.push_back(MyObject());
		platList[i].size=platSize[i];
		platList[i].position.x=platPosX[i];
		platList[i].position.y=platPosY[i];
		platShape.push_back(make_shared<MyShape>(world, platList[i].size, platList[i].position, false, false));
		platShape[i]->setOutlineThickness(-1);
		platShape[i]->setOutlineColor(sf::Color::Black);
		platShape[i]->setUserData(&platID);
	} 

	
	//!Plats
	
	//Spikes - Kerk Chee Sheng & Teo Mou Yao
	int numSpikes=37;
	vector<MyObject> spikeList;
	vector<shared_ptr<Trap>> trapList;
	sf::Vector2f trapSize(50,32);
	sf::Texture spikesUpTexture= loadTexture("resources/spikesUp.png");
	sf::Texture spikesDownTexture= loadTexture("resources/spikesDown.png");
	

	//Spikes Direction and Position values - Teo Mou Yao
	int spikePlatList[numSpikes]={1,4,7,9,10,
                                17,19,22,22,23,
                                25,27,27,28,28,
                                31,31,36,36,39,
                                39,43,44,44,45,
                                47,48,48,51,51,
                                55,57,57,58,58,
                                61,61
                                };



	char spikePosList[numSpikes]={'M','R','M','R','M',
                                'M','R','R','M','L',
                                'L','M','M','L','M',
                                'L','M','R','L','R',
                                'R','R','L','L','L',
                                'M','M','L','R','R',
                                'M','L','M','M','L',
                                'M','L'
                                };

	char spikeDirection[numSpikes]={'U','D','D','U','D',
                                  'U','U','D','U','U',
                                  'D','U','D','D','U',
                                  'D','U','D','U','D',
                                  'U','U','D','U','U',
                                  'U','D','U','D','U',
                                 'D','D','U','D','U',
                                  'D','U'
                                  };

	//Spikes List -Kerk Chee Sheng
	for(int i=0;i<numSpikes;i++){
		spikeList.push_back(MyObject());
		spikeList[i].size=trapSize;
		int spikeOffset;
		if(spikeDirection[i]=='U'){
			spikeOffset = -26;
		}
		else{
			spikeOffset = 26;
		}
		
		if(spikePosList[i]=='M'){
			sf::Vector2f trapMidPos(platList[spikePlatList[i]-1].position.x,platList[spikePlatList[i]-1].position.y+spikeOffset); // smallPlat also works
			spikeList[i].position.x=trapMidPos.x;
			spikeList[i].position.y=trapMidPos.y;
		}else if (spikePosList[i]=='L'){
			sf::Vector2f trapLeftPos(platList[spikePlatList[i]-1].position.x-75,platList[spikePlatList[i]-1].position.y+spikeOffset);
			spikeList[i].position.x=trapLeftPos.x;
			spikeList[i].position.y=trapLeftPos.y;
		}else if (spikePosList[i]=='R'){
			sf::Vector2f trapRightPos(platList[spikePlatList[i]-1].position.x+75,platList[spikePlatList[i]-1].position.y+spikeOffset);
			spikeList[i].position.x=trapRightPos.x;
			spikeList[i].position.y=trapRightPos.y;
		}
		trapList.push_back(make_shared<Trap>(world, spikeList[i].size, spikeList[i].position, 0.0, false));
		trapList[i]->setUserData(&spikeTrapID);
		if(spikeOffset<0){
			trapList[i]->getShape()->setTexture(&spikesUpTexture);
		}else{
			trapList[i]->getShape()->setTexture(&spikesDownTexture);	
		}

	}
	//!Spikes
	
	
	//Stone - Teo Mou Yao & Kerk Chee Sheng
	int indexStone=-1;
	int numStones=100;
	int bigStoneRadius=25;
	sf::Texture bigStoneTexture= loadTexture("resources/bigStone.png");
	sf::Vector2f stoneSize(35,35);
	sf::RectangleShape stonePic(stoneSize);
	stonePic.setOrigin(17.5,17.5);
	stonePic.setPosition(817.5,windowSizeY/2);
	stonePic.setTexture(&bigStoneTexture);
	
	
	
	vector<MyObject> bigStoneObjList ;
	vector<shared_ptr<Stone>>  bigStoneList;
	int stonePosX[numStones]={200, 500, 700};
	//!Stone
	
	
	//Coins & Diamonds - Kerk Chee Sheng & Teo Mou Yao
	int numCoins=28;
	int numDiamonds=16;
	
	sf::Vector2f coinDiamondSize(26,30);
	sf::Vector2f coinDiamondPos(platList[spikePlatList[1]-1].position.x,platList[spikePlatList[1]-1].position.y-25); // smallPlat also works
	sf::Texture coinTexture= loadTexture("resources/coin.png");
	sf::Texture diamondTexture= loadTexture("resources/diamond.png");
	vector<MyObject> coinObjList;
	vector<MyObject> diamondObjList;
	
	vector<shared_ptr<ScoreItem>> coinList;
	vector<shared_ptr<ScoreItem>> diamondList;
	//Coins Position values -Teo Mou Yao
	int coinPlatList[numCoins]={4,4,7,9,10,
								11,17,19,22,23,
								25,27,28,31,35,
								36,39,43,44,45,
								47,48,51,55,57,
								58,61,66};



	char coinPosList[numCoins]={'R','L','R','L','R',
								'L','L','L','R','R',
								'L','R','R','R','R',
								'R','L','M','R','R',
								'L','M','M','R','R',
								'R','M','M'};


	//Diamonds Position values -Teo Mou Yao
	int diamondPlatList[numDiamonds]={7,9,10,17,19,
									 23,27,31,36,39,
									 44,45,47,55,57,
									 58};



	char diamondPosList[numDiamonds]={'L','M','L','R','M',
									  'M','L','L','M','M',
                                      'M','M','R','M','L',
                                      'M'};
	
	
	//Coins and Diamonds List -Kerk Chee Sheng
	for(int i=0;i<numCoins;i++){
		coinObjList.push_back(MyObject());
		coinObjList[i].size=coinDiamondSize;
		if(coinPosList[i]=='M'){
			sf::Vector2f coinMidPos(platList[coinPlatList[i]-1].position.x,platList[coinPlatList[i]-1].position.y-25); // smallPlat also works
			coinObjList[i].position.x=coinMidPos.x;
			coinObjList[i].position.y=coinMidPos.y;
		}else if (coinPosList[i]=='L'){
			sf::Vector2f coinLeftPos(platList[coinPlatList[i]-1].position.x-75,platList[coinPlatList[i]-1].position.y-25);
			coinObjList[i].position.x=coinLeftPos.x;
			coinObjList[i].position.y=coinLeftPos.y;
		}else if (coinPosList[i]=='R'){
			sf::Vector2f coinRightPos(platList[coinPlatList[i]-1].position.x+75,platList[coinPlatList[i]-1].position.y-25);
			coinObjList[i].position.x=coinRightPos.x;
			coinObjList[i].position.y=coinRightPos.y;
		}
		coinList.push_back(make_shared<ScoreItem>(world, coinObjList[i].size, coinObjList[i].position, true, false));
		coinList[i]->setUserData(&coinID);
		coinList[i]->getShape()->setTexture(&coinTexture);
		coinList[i]->setPoint(5);

	}
	
	for(int i=0;i<numDiamonds;i++){
		diamondObjList.push_back(MyObject());
		diamondObjList[i].size=coinDiamondSize;
		if(diamondPosList[i]=='M'){
			sf::Vector2f diamondMidPos(platList[diamondPlatList[i]-1].position.x,platList[diamondPlatList[i]-1].position.y-25); // smallPlat also works
			diamondObjList[i].position.x=diamondMidPos.x;
			diamondObjList[i].position.y=diamondMidPos.y;
		}else if (diamondPosList[i]=='L'){
			sf::Vector2f diamondLeftPos(platList[diamondPlatList[i]-1].position.x-75,platList[diamondPlatList[i]-1].position.y-25);
			diamondObjList[i].position.x=diamondLeftPos.x;
			diamondObjList[i].position.y=diamondLeftPos.y;
		}else if (diamondPosList[i]=='R'){
			sf::Vector2f diamondRightPos(platList[diamondPlatList[i]-1].position.x+75,platList[diamondPlatList[i]-1].position.y-25);
			diamondObjList[i].position.x=diamondRightPos.x;
			diamondObjList[i].position.y=diamondRightPos.y;
		}
		diamondList.push_back(make_shared<ScoreItem>(world, diamondObjList[i].size, diamondObjList[i].position, true, false));
		diamondList[i]->setUserData(&diamondID);
		diamondList[i]->getShape()->setTexture(&diamondTexture);
		diamondList[i]->setPoint(10);

	}
	
	//!Coins & Diamonds
	
	//ExitDoor -Teo Mou Yao
	sf::Vector2f doorSize(41,70);
	sf::Vector2f doorPos(700+75,-3995-45);
	sf::Texture doorTexture= loadTexture("resources/door.png");

	MyShape exitDoor(world,doorSize,doorPos,true,false);
	exitDoor.getShape()->setTexture(&doorTexture);
	exitDoor.setUserData(&doorID);
	//!ExitDoor
	
	
	//ScoreBoard - Teo Mou Yao
	sf::Texture scoreTexture= loadTexture("resources/scoreBoard.png");
	sf::Texture goldTexture= loadTexture("resources/gold.png");
	sf::Texture bronzeTexture= loadTexture("resources/bronze.png");
	sf::Texture silverTexture= loadTexture("resources/silver.png");
	sf::Vector2f scoreBoardSize(300,180);
	sf::Vector2f medalSize(50,65);
	
	sf::RectangleShape scoreBoard(scoreBoardSize);
	scoreBoard.setOrigin(150,90);
	scoreBoard.setPosition(windowSizeX/2, windowSizeY/2);
	scoreBoard.setTexture(&scoreTexture);
	
	sf::RectangleShape medal(medalSize);
	medal.setOrigin(25,32.5);
	medal.setPosition(windowSizeX/2, windowSizeY/2+20);

	
	//!ScoreBoard
	
	
	//Background Image - Teo Mou Yao
	sf::Texture bgTexture= loadTexture("resources/background.png");
	sf::Sprite sprite;
	sprite.setTexture(bgTexture);
    sprite.setOrigin(windowSizeX / 2, windowSizeY / 2);
    sprite.setPosition(windowSizeX / 2, windowSizeY / 2);
	//!Background
	
	
	//Character creation - Kerk Chee Sheng
	
	bool isLeftWalk= true;
	bool isRightWalk= false;
	bool isLeftWalking =false;
	bool isRightWalking =false;
	sf::Texture lWalkTexture1= loadTexture("resources/leftWalk1.png");
	sf::Texture lWalkTexture2= loadTexture("resources/leftWalk2.png");
	sf::Texture rWalkTexture1= loadTexture("resources/rightWalk1.png");
	sf::Texture rWalkTexture2= loadTexture("resources/rightWalk2.png");
	sf::Texture lJumpTexture= loadTexture("resources/leftJump.png");
	sf::Texture rJumpTexture= loadTexture("resources/rightJump.png");

	sf::Vector2f boySize(35,60);
	sf::Vector2f boyPos(windowSizeX / 2, windowSizeY / 2);
	
	Character boy(world,boySize,boyPos);
	boy.setUserData(&boyID);
	boy.getShape()->setTextureRect(sf::IntRect(0, 0, 41,70));
	boy.getShape()->setTexture(&rWalkTexture1);
	boy.setFixedRotation(true);

	//!Character
	
	
	//Health - Kerk Chee Sheng
	sf::Texture health1Texture= loadTexture("resources/1f.png");
	sf::Texture health2Texture= loadTexture("resources/2f.png");
	sf::Texture health3Texture= loadTexture("resources/3f.png");
	sf::Texture health0Texture= loadTexture("resources/0f.png");
	sf::Vector2f healthBoxSize(100,35);
	sf::RectangleShape healthBox(healthBoxSize);
	healthBox.setOrigin(healthBoxSize.x/2,healthBoxSize.y/2);
	healthBox.setPosition(windowSizeX-healthBoxSize.x/2, healthBoxSize.y);
	healthBox.setTexture(&health1Texture);
	
	
	bool endFlag=false;

	ostringstream ss;
	int jumpStepDuration=0;
	int lavaFrameStep=0;
	
	sf::Clock clock;
	sf::Time timer;
	int seconds=0;
	
	//MyContactListener - Kerk Chee Sheng
	MyContactListener myContactListener(scoringSystem,coinList,diamondList,&boy,trapList,bigStoneList);
	world.SetContactListener(&myContactListener);
	bool gameStarted =false;

	//Update window - Kerk Chee Sheng
    while (window.isOpen()){	
		sf::Event event;

        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed){
				bgmSound.setLoop(false);
				lavaSound.setLoop(false);
				bgmSound.stop();
				lavaSound.stop();
				
				window.close();
				
			}
			
        }
		//The Game will start after the user Pressed "Enter" Key
		if(!gameStarted){
				if(sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)){
					gameStarted=true;
					clock.restart();
				}
		}
		if(!gameStarted){
			viewInstruction();
		}
		else{
		
		timer = clock.getElapsedTime();
		seconds = timer.asSeconds();
		timerNumText.setString(to_string(seconds));
		
		
		
		
		
		//score Text
		ostringstream ss2;
		if(boy.getHealth()>0){
			
			ss2 << scoringSystem->getTotalPoints();
			scoreNumText.setString(ss2.str());	
		}
		
		//A few Events will be executed every 10 Seconds
		if(seconds ==10){
				++speed;  //Lava speed will be increased by 1
				
				scoringSystem->getPoints(-1);            //The Points will be deducted by 1
				scoreNumText.setString(ss2.str()+"-1");	

				for(int i =0;i<=indexStone;i++){ //To ensure the stones will move around the map
					bigStoneList[i]->move();}
				
				
				//ONE big Stone will be dropped from the top of the Character
				earthquakeSound.play();	
				if(indexStone<numStones){
					indexStone++;
					bigStoneObjList.push_back(MyObject());
					bigStoneObjList[indexStone].position.x=stonePosX[indexStone%3];
					bigStoneObjList[indexStone].position.y=boy.getPosition().y-500;
					bigStoneList.push_back(make_shared<Stone>(world,bigStoneRadius,bigStoneObjList[indexStone].position,true));
					bigStoneList[indexStone]->getShape()->setTexture(&bigStoneTexture);
					bigStoneList[indexStone]->setUserData(&stoneID);
					bigStoneList[indexStone]->move();
							
				}
				
				clock.restart();
		}
		
		//User Input for moving the Character
		if(scoringSystem->checkGameEnd(boy.getHealth()) == 'N'){
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			{
				boy.move('L');
				if(!isLeftWalk){
					boy.getShape()->setTexture(&lWalkTexture1);}
				isLeftWalk=true;
				isRightWalk=false;		
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			{
				boy.move('R');
				if(!isRightWalk){
					boy.getShape()->setTexture(&rWalkTexture1);}
				isLeftWalk=false;
				isRightWalk=true;
			}
			if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Up))||(sf::Keyboard::isKeyPressed(sf::Keyboard::Space)))
			{
				
				if(jumpStepDuration==0){
					if(boy.getAllowJump()){   //Only one Jump allowed
						boy.move('U');
						numTimeStep-=7;
						jumpStepDuration=7;
						jumpSound.play();
					}
				}
				if(isLeftWalk){
					boy.getShape()->setTexture(&lJumpTexture);}
				else{
					boy.getShape()->setTexture(&rJumpTexture);}
				
			}
		}
		
		//Update Physic for all the Objects and Animation
		timeElapsedSinceLastFrame += fixedUpdateClock.restart().asSeconds();
		if(timeElapsedSinceLastFrame >= fixedTimeStep)
		{
			
			
			world.Step(fixedTimeStep,8,3);
			numTimeStep++;
			
			if(jumpStepDuration>0)
				jumpStepDuration--;
			
			//Lava Animation
			if (numTimeStep%10 ==0){
				sf::Texture lavaNextFrame;
				bottomMyShape.getShape()->setTexture(&lavaFrame[lavaFrameStep]);
				lavaFrameStep++;
				if(lavaFrameStep==6){
					lavaFrameStep=0;}		
			}	
			if((numTimeStep%5 == 0)&&(bottomMyShape.getPosition().y > -3795)){
				bottomMyShape.updatePosition(speed);	
			}
			
			
			//Check if any coins or diamonds have been taken and destroy their bodies in the b2World
			if(numTimeStep%2==0){
				for(int i=0;i<numCoins;i++){
					if((coinList[i]->getDestroy())&&(!coinList[i]->getBodyDestroyed()))
						coinList[i]->destroyBody(world);}
				for(int i=0;i<numDiamonds;i++){
					if((diamondList[i]->getDestroy())&&(!diamondList[i]->getBodyDestroyed()))
						diamondList[i]->destroyBody(world);}			
			}
			
			
			
			//Following the Character and Update the Position
			float offsetY = boy.getOffsetY();
			bottomMyShape.update(offsetY);
			leftMyShape.update(offsetY);
			rightMyShape.update(offsetY);
			boy.update(offsetY);
			exitDoor.update(offsetY);
			
			for(int i =0;i<numPlats;i++){
			platShape[i]->update(offsetY);}
			for(int i =0;i<numSpikes;i++){
			trapList[i]->update(offsetY);}
			for(int i =0;i<numCoins;i++){
			coinList[i]->update(offsetY);}
			for(int i =0;i<numDiamonds;i++){
			diamondList[i]->update(offsetY);}
			for(int i =0;i<=indexStone;i++){
			bigStoneList[i]->update(offsetY);
			}

			
			//Character Animation
			if(numTimeStep%30 == 0 ){
				if(isLeftWalk){
					if(isLeftWalking){
						boy.getShape()->setTexture(&lWalkTexture2);
						isLeftWalking=false;}
					else{
						boy.getShape()->setTexture(&lWalkTexture1);
						isLeftWalking=true;}
				}
				if(isRightWalk){
					if(isRightWalking){
						boy.getShape()->setTexture(&rWalkTexture2);
						isRightWalking=false;}
					else{
						boy.getShape()->setTexture(&rWalkTexture1);
						isRightWalking=true;}
				}
				if(numTimeStep==1000)
					numTimeStep=0;
			}
			
			timeElapsedSinceLastFrame -= fixedTimeStep;
		}
		
		   
		
		
		
		window.clear(sf::Color::White);

		// Render all objects
		window.draw(sprite);
		window.draw(*(boy.getShape()));
		window.draw(*(exitDoor.getShape()));
		for(int i =0;i<numPlats;i++){
			window.draw(*(platShape[i]->getShape()));	
		}
		for(int i =0;i<numSpikes;i++){
			window.draw(*(trapList[i]->getShape()));	
		}
		for(int i =0;i<numCoins;i++){
			if(!coinList[i]->getBodyDestroyed())
				window.draw(*(coinList[i]->getShape()));	
		}for(int i =0;i<numDiamonds;i++){
			if(!diamondList[i]->getBodyDestroyed())
				window.draw(*(diamondList[i]->getShape()));	
		}for(int i =0;i<=indexStone;i++){
			if(!bigStoneList[i]->getBodyDestroyed())
				window.draw(*(bigStoneList[i]->getShape()));	
		}
		window.draw(*(bottomMyShape.getShape()));
		
		
		//To show the ScoreBoard after the game ended
		if(scoringSystem->checkGameEnd(boy.getHealth()) == 'W'){
			window.draw(scoreBoard);
			if(!endFlag){
				ss<< scoringSystem->getTotalPoints();
				scoreBoardText.setString("Your Score : "+ss.str());
				if(scoringSystem->getMedal()=='G'){
					medal.setTexture(&goldTexture);
				}if(scoringSystem->getMedal()=='S'){
					medal.setTexture(&silverTexture);
				}if(scoringSystem->getMedal()=='B'){
					medal.setTexture(&bronzeTexture);
				}
				endFlag=true;
				winSound.play();}
			window.draw(medal);
			window.draw(scoreBoardText);	
		}else if(scoringSystem->checkGameEnd(boy.getHealth()) == 'L'){
			window.draw(scoreBoard);
			if(!endFlag){
				ss<< scoringSystem->getTotalPoints();
				scoreBoardText.setString("Your Score : "+ss.str()+"\n   You Lose");
				endFlag=true;
				loseSound.play();}
				
			window.draw(scoreBoardText);	
		}
		
		//Update Character's Health
		if(boy.getHealth()==3){
			healthBox.setTexture(&health3Texture);	
		}else if(boy.getHealth()==2){
			healthBox.setTexture(&health2Texture);	
		}else if(boy.getHealth()==1){
			healthBox.setTexture(&health1Texture);	
		}else if(boy.getHealth()==1){
			healthBox.setTexture(&health1Texture);	
		}else{healthBox.setTexture(&health0Texture);
		}
		
		//Show the Lava Speed
		lavaText.setString(" Lava\nSpeed\n  x "+ to_string((int)speed));
		
		//Show the number of stones have in the Map
		stoneNumText.setString("x " + to_string(indexStone+1));
		
		window.draw(lavaText);
		window.draw(stoneNumText);
		window.draw(timerText);
		window.draw(scoreText);
		window.draw(scoreNumText);
		window.draw(timerNumText);
		window.draw(healthBox);
		window.draw(stonePic);
		window.display();
		}
	}
}
	int main(){
		EscapeTheLava escapeTheLava;
		escapeTheLava.setup();
		
		
	}
