/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <Box2D/Box2D.h>
#include <iostream>
#include <memory>
#include <vector>
#include "MyShape.h"
#include "ScoreItem.h"
#include "Character.h"
#include "Trap.h"
#include "Stone.h"
#include "ScoringSystem.h"


using namespace std;

class MyContactListener : public b2ContactListener
{
    private:
		int boyID;
		int platID;
		int leftPanelID;
		int rightPanelID;
		int lavaID;
		int spikeTrapID;
		int huntTrapID;
		int coinID;
		int diamondID;
		int stoneID;
		int doorID;
		Character* boy_;
		vector<shared_ptr<Trap>> trap_;
		vector<shared_ptr<Stone>> bigStone_;
		vector<shared_ptr<ScoreItem>> coins;
		vector<shared_ptr<ScoreItem>> diamonds;
		shared_ptr<ScoringSystem> scoreSystem;
		sf::SoundBuffer stoneBuffer;
		sf::SoundBuffer ouchBuffer;
		sf::SoundBuffer itemBuffer;
		sf::Sound stoneSound;
		sf::Sound ouchSound;
		sf::Sound itemSound;
		
	public:
		MyContactListener(shared_ptr<ScoringSystem>& ss,vector<shared_ptr<ScoreItem>>& coin,vector<shared_ptr<ScoreItem>>& diamond,
						Character* boy,vector<shared_ptr<Trap>>& trap,vector<shared_ptr<Stone>>& bigStone );
		void BeginContact(b2Contact* contact);

};