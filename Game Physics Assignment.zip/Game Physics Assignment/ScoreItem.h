/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Teo Mou Yao
#ifndef ScoreItem_H
#define ScoreItem_H
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>
#include "MyShape.h"

class ScoreItem : public MyShape
{
 private:
	int points;
 public:
    ScoreItem(){};
	ScoreItem(b2World& world, sf::Vector2f size,sf::Vector2f position,
	bool isSensor,bool isDynamic = true):MyShape(world,size,position,isSensor,isDynamic){
	points=1;}
	void setPoint(int p){points=p;}
	int getPoint(){return points;}
};
#endif