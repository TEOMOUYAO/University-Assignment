/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Teo Mou Yao

#ifndef TRAP_H
#define TRAP_H
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>
#include "MyShape.h"

class Trap : public MyShape
{
 private:
	bool isActive;
	float damage;
 public:
    Trap(){};
	Trap(b2World& world, sf::Vector2f size,sf::Vector2f position,
	bool isSensor=false,bool isDynamic = true):MyShape(world,size,position,isSensor,isDynamic){	
	isActive=true;
	damage=1;}
	void setActive(bool b){isActive=b;}
	bool getActive(){return isActive;}
	float getDamage(){return damage;}
};
#endif