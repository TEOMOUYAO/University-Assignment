/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#include "Character.h"
#include <stdlib.h>
#include <iostream>

void Character::takeDamage(float damage){
	health-=damage;
}

float Character::getHealth(){
	
	return health;
}
void Character::setFixedRotation(bool b)
{
	
	body_->SetFixedRotation(b);
}
void Character::setAllowLeftMove(bool b)
{
	
	isAllowLeftMove=b;
}
void Character::setAllowRightMove(bool b)
{
	
	isAllowRightMove=b;
}
void Character::setAllowJump(bool b)
{
	
	isAllowJump=b;
}

bool Character::getAllowJump()
{
	
	return isAllowJump;
}

void Character::move(char direction)
{
	
	b2Vec2 vel = body_->GetLinearVelocity();
	switch(direction){
		case 'L':{
			if (isAllowLeftMove)
				vel.x = -4;
			break;}
		case 'R':{
			if (isAllowRightMove)
				vel.x = 4;
			break;}
		case 'U':{
			if(isAllowJump){
				b2Vec2 vel2 = body_->GetLinearVelocity();
				vel.y = -12.5;
				isAllowJump=false;
			}			
			break;}
		case 'J':{
			vel.y=-13.5;
			break;}
	}
	body_->SetLinearVelocity( vel );
	
}
