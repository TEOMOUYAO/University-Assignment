/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#include <iostream>
#include <vector>
#include <memory>
#include "MyContactListener.h"

using namespace std;

MyContactListener::MyContactListener(shared_ptr<ScoringSystem>& ss,vector<shared_ptr<ScoreItem>>& coin,vector<shared_ptr<ScoreItem>>& diamond,Character* boy,vector<shared_ptr<Trap>>& trap,vector<shared_ptr<Stone>>& bigStone ){
	boy_=boy;
	bigStone_=bigStone;
	trap_=trap;
	coins=coin;
	diamonds=diamond;
	scoreSystem=ss;
	boyID=1;
	platID=2;
	leftPanelID=3;
	rightPanelID=4;
	spikeTrapID=5;
	coinID=6;
	diamondID=7;
	stoneID=8;
	lavaID=0;
	doorID=10;
	stoneBuffer.loadFromFile("resources/music/blockStone.wav");
	ouchBuffer.loadFromFile("resources/music/ouch.wav");
	itemBuffer.loadFromFile("resources/music/collectScoreItem.wav");
	stoneSound.setBuffer(stoneBuffer);
	ouchSound.setBuffer(ouchBuffer);
	itemSound.setBuffer(itemBuffer);
	
}

void MyContactListener::BeginContact(b2Contact* contact) {
	int fixtureAData=*(static_cast<int*>(contact->GetFixtureA()->GetBody()->GetUserData()));
	int fixtureBData=*(static_cast<int*>(contact->GetFixtureB()->GetBody()->GetUserData()));
	b2Body* boyBody = (fixtureAData == 1) ? contact->GetFixtureA()->GetBody() : contact->GetFixtureB()->GetBody();
	b2Body* coinBody = (fixtureAData == 6) ? contact->GetFixtureA()->GetBody() : contact->GetFixtureB()->GetBody();
	b2Body* diamondBody = (fixtureAData == 7) ? contact->GetFixtureA()->GetBody() : contact->GetFixtureB()->GetBody();
	b2Body* stoneBody = (fixtureAData == 8) ? contact->GetFixtureA()->GetBody() : contact->GetFixtureB()->GetBody();
	b2Body* trapBody = (fixtureAData == 5) ? contact->GetFixtureA()->GetBody() : contact->GetFixtureB()->GetBody();
	b2Body* platBody = (fixtureAData == 2) ? contact->GetFixtureA()->GetBody() : contact->GetFixtureB()->GetBody();

	
	
	
	//When Character contacts / touches the plat Object
	if((fixtureAData== platID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == platID)){ 
	
			boy_->setAllowLeftMove(true);
			boy_->setAllowRightMove(true);
			boy_->setAllowJump(true);}
		
	//When Character contacts / touches the Left Panel		
	if((fixtureAData== leftPanelID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == leftPanelID)){
		
		boy_->setAllowLeftMove(false);	
	}
	//When Character contacts / touches the Right Panel
	if((fixtureAData== rightPanelID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == rightPanelID)){
		boy_->setAllowRightMove(false);	
	}
	
	//When Character contacts / touches the lava
	if((fixtureAData== lavaID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == lavaID)){
		boy_->setAllowLeftMove(true);
		boy_->setAllowRightMove(true);
		boy_->setAllowJump(true);
		boy_->move('J');
		boy_->takeDamage(1);
		ouchSound.play();
		ouchSound.setVolume(50);
		
	}
	
	//When Character contacts / touches the spike
	if((fixtureAData== spikeTrapID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == spikeTrapID)){
			boy_->takeDamage(trap_[0]->getDamage());
			int i=0;
			int j=0;
			while(true){
				if(trap_[i]->isThisMyBody(trapBody))
					break;
				i++;
				
			}
			if(platBody->GetPosition().y > trap_[i]->getPosition().y){
				boy_->move('J');		
				}
			ouchSound.play();
			ouchSound.setVolume(50);

			boy_->setAllowLeftMove(true);
			boy_->setAllowRightMove(true);
			boy_->setAllowJump(true);
	}
	
	//When Character collect the coin
	if((fixtureAData== coinID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == coinID)){
			int i=0;
			while(true){
				if(coins[i]->isThisMyBody(coinBody))
					break;
				i++;
				
			}
			coins[i]->setDestroy();
			scoreSystem->getPoints(coins[0]->getPoint());
			
			boy_->setAllowLeftMove(true);
			boy_->setAllowRightMove(true);
			boy_->setAllowJump(true);
			itemSound.play();
			itemSound.setVolume(75);
	}
	
	//When Character collect the diamond
	if((fixtureAData== diamondID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == diamondID)){
			int i=0;
			while(true){
				if(diamonds[i]->isThisMyBody(diamondBody))
					break;
				i++;
				
			}
			diamonds[i]->setDestroy();
			scoreSystem->getPoints(diamonds[0]->getPoint());

			boy_->setAllowLeftMove(true);
			boy_->setAllowRightMove(true);
			boy_->setAllowJump(true);
			itemSound.play();
			itemSound.setVolume(75);
	}
	
	//When Stones collides the Wall 

	if((fixtureAData== stoneID) && (fixtureBData  == leftPanelID)
	|| (fixtureAData== leftPanelID) && (fixtureBData  == stoneID)){
		b2Vec2 vel = stoneBody->GetLinearVelocity();
		vel.x+=7;
		stoneBody->SetLinearVelocity(vel);
	
	}
	if((fixtureAData== stoneID) && (fixtureBData  == rightPanelID)
	|| (fixtureAData== rightPanelID) && (fixtureBData  == stoneID)){
		b2Vec2 vel = stoneBody->GetLinearVelocity();
		vel.x-=7;
		stoneBody->SetLinearVelocity(vel);
	
	}
	
	//When Character collides with Stones 
	if((fixtureAData== stoneID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == stoneID)){
		
		stoneSound.play();
		stoneSound.setVolume(50);

	}
	//When Character goes into the Door
	if((fixtureAData== doorID) && (fixtureBData  == boyID)
	|| (fixtureAData== boyID) && (fixtureBData  == doorID)){
		scoreSystem->endGame();
	
	}
	
}
