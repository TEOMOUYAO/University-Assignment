/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#include "MyShape.h"
#include <iostream>
static const float PIXEL_PER_METER = 32.0f;
using namespace std;


MyShape::MyShape(){};

//Constructor for Rectangle Shape
MyShape::MyShape(b2World& world,sf::Vector2f size,sf::Vector2f position,
				 bool isSensor,bool isDynamic)
{
	isDestroyed=false;
	isBodyDestroyed=false;
	shape =new sf::RectangleShape(size);
	rect = static_cast<sf::RectangleShape*>(shape);
	rect->setOrigin(sf::Vector2f(size.x/2,size.y/2));
	

	bodyDef_.position = b2Vec2(position.x/PIXEL_PER_METER, position.y/PIXEL_PER_METER);
	if(isSensor){
		bodyFixtureDef_.isSensor=true;   //No physic will be applied to the Object
	}
	
	if (isDynamic)
   {
      bodyDef_.type = b2_dynamicBody;
   }
   else  
   {
      bodyDef_.type = b2_staticBody;
   }

	bodyRectshape.SetAsBox((size.x/2)/PIXEL_PER_METER, (size.y/2)/PIXEL_PER_METER);

	bodyFixtureDef_.shape = &bodyRectshape;
	bodyFixtureDef_.density = 0.3f;
	bodyFixtureDef_.friction = 0.5f;

	body_ = world.CreateBody(&bodyDef_);
	body_->CreateFixture(&bodyFixtureDef_);
}

//Constructor for Circle Shape
MyShape::MyShape(b2World& world,int radius,sf::Vector2f position,
			bool isDynamic)
{

	isDestroyed=false;
	isBodyDestroyed=false;
	
	shape= new sf::CircleShape(radius);
	circle =static_cast<sf::CircleShape*>(shape);
	circle->setOrigin(sf::Vector2f(radius,radius));
	circle->setFillColor(sf::Color(255, 255, 255, 255));
	

	bodyDef_.position = b2Vec2(position.x/PIXEL_PER_METER, position.y/PIXEL_PER_METER);
	
	if (isDynamic)
   {
      bodyDef_.type = b2_dynamicBody;
   }
   else  
   {
      bodyDef_.type = b2_staticBody;
   }

	 bodyCirshape.m_radius=radius/PIXEL_PER_METER;

	bodyFixtureDef_.shape = &bodyCirshape;
	bodyFixtureDef_.density = 10;
	bodyFixtureDef_.friction = 0.3f;
	bodyFixtureDef_.restitution = 0.9f;
	

	body_ = world.CreateBody(&bodyDef_);
	body_->CreateFixture(&bodyFixtureDef_);
}

void MyShape::setFillColor(sf::Color col)
{
	shape->setFillColor(col);
}
void MyShape::setDestroy(){
	isDestroyed=true;
	
}
bool MyShape::getDestroy(){
	return isDestroyed;
}
bool MyShape::getBodyDestroyed(){
	return isBodyDestroyed;
}

bool MyShape::isThisMyBody(b2Body* b){

	if((b->GetPosition()) == (body_->GetPosition())){
			return true;
		}
	return false;
	
}

void MyShape::destroyBody(b2World& world){
	world.DestroyBody(body_);
	isDestroyed=true;
	isBodyDestroyed=true;
	
}

void MyShape::setOutlineThickness(float thickness)
{
	shape->setOutlineThickness(thickness);
}

void MyShape::setOutlineColor(sf::Color col)
{
	shape->setOutlineColor(col);
}


void MyShape::setUserData(void* data)
{
	
	body_->SetUserData(data);
}
void MyShape::setPosition(sf::Vector2f position)
{
	b2Vec2 pos(position.x/PIXEL_PER_METER,position.y/PIXEL_PER_METER);
	body_->SetTransform(pos,0);
	shape->setPosition( body_->GetPosition().x*PIXEL_PER_METER, body_->GetPosition().y*PIXEL_PER_METER);
}
b2Vec2 MyShape::getPosition()
{
	b2Vec2 pos = body_->GetPosition();
	pos.x*=PIXEL_PER_METER;
	pos.y*=PIXEL_PER_METER;
	return pos;
}


float MyShape::getOffsetY(){  //get the Object Offset for following the Object
	
	
	float offsetY=0;
	
	if(((int)(body_->GetPosition().y*PIXEL_PER_METER))%500 != 0){
		if((body_->GetPosition().y*PIXEL_PER_METER)>500){   //down from the midscreen
			offsetY = -(body_->GetPosition().y*PIXEL_PER_METER-500);}
		else if(body_->GetPosition().y*PIXEL_PER_METER < 500){
		
			offsetY = (500- body_->GetPosition().y*PIXEL_PER_METER);
		
		}
	}
	return offsetY;
}

void MyShape::update(float offsetY) // Update the object Position and Rotation
{		
	if(!isDestroyed){
		shape->setRotation( body_->GetAngle() * 180/b2_pi);
		shape->setPosition( body_->GetPosition().x*PIXEL_PER_METER, body_->GetPosition().y*PIXEL_PER_METER+offsetY);
	}
}


void MyShape::updatePosition(float speed){  //Update the Position for Lava 
	b2Vec2 currentPos=body_->GetPosition();
	currentPos.y-=(speed/40);
	body_->SetTransform(currentPos,0);
	shape->setPosition( body_->GetPosition().x*PIXEL_PER_METER, body_->GetPosition().y*PIXEL_PER_METER);

	
}

sf::Shape* MyShape::getShape()
{
	return shape;
	
}