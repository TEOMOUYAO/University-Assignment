/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Teo Mou Yao
#ifndef	SCORINGSYSTEM_H
#define	SCORINGSYSTEM_H

class ScoringSystem
{
 private:
	int totalPoints;
	bool isGameEnd;
 public:
    ScoringSystem();
	void getPoints(int p);
	int getTotalPoints();
	char getMedal();
	void endGame();
	char checkGameEnd(int health);
};
#endif