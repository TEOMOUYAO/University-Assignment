/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Kerk Chee Sheng
#ifndef EscapeTheLava_H
#define EscapeTheLava_H
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <Box2D/Box2D.h>
#include "MyShape.h"
#include "MyContactListener.h"
#include "Character.h"
#include "Trap.h"
#include "Stone.h"
#include "ScoreItem.h"
#include "ScoringSystem.h"
#include <ctime>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <memory>

using namespace std;



struct MyObject{          //Kerk Chee Sheng
	sf::Vector2f size;
	sf::Vector2f position;
	
	
	
};
struct Point{			//Kerk Chee Sheng
	float x;
	float y;
};


class EscapeTheLava {
	private:
		int windowSizeX=900;
		int windowSizeY=950;
		int windowMyShapeSize = 100;
		
		int lavaID=0;
		int boyID=1;
		int platID=2;
		int leftPanelID=3;
		int rightPanelID=4;
		int spikeTrapID=5;
		int coinID=6;
		int diamondID=7;
		int stoneID=8;
		int doorID=10;
		
		float fixedTimeStep= 1/(float)60;
		int numTimeStep=0;
		float timeElapsedSinceLastFrame= 0;

		sf::Clock fixedUpdateClock;
		
		sf::Font font;
		sf::Text scoreText;
		sf::Text scoreNumText;
		sf::Text timerText;
		sf::Text timerNumText;
		sf::Text lavaText;
		sf::Text scoreBoardText;
		sf::Text stoneNumText;
		
		
		sf::SoundBuffer bgmBuffer;
		sf::Sound bgmSound;
		sf::SoundBuffer lavaBuffer;
		sf::Sound lavaSound;
		sf::SoundBuffer earthquakeBuffer;
		sf::Sound earthquakeSound;
		sf::SoundBuffer jumpBuffer;
		sf::Sound jumpSound;
		sf::SoundBuffer winBuffer;
		sf::Sound winSound;		
		sf::SoundBuffer loseBuffer;
		sf::Sound loseSound;
		
		shared_ptr<ScoringSystem> scoringSystem;

	public:
		EscapeTheLava();
		void iniText();
		void iniSound();
		void viewInstruction();
		void setup();
		void run();
		sf::Texture loadTexture(const string& imageFilename);
		sf::Font loadFont(const std::string& fontFilename = "resources/fonts/04b03.ttf");
		sf::SoundBuffer loadSoundBuffer(const string& waveFilename);
		sf::Sound createSound(const sf::SoundBuffer& mySoundBuffer);
		sf::RenderWindow window;

	
	
	
};

#endif









