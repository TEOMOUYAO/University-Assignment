/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Teo Mou Yao
#include "Stone.h"
#include <stdlib.h>
#include <iostream>

void Stone::move()
{

	b2Vec2 vel = body_->GetLinearVelocity();
	if(iniPosition.x <450){
		vel.x+=7;
	}else{
		vel.x-=7;
	}
	body_->SetLinearVelocity( vel );
	
}
