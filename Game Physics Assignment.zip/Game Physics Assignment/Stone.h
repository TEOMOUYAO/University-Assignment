/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Teo Mou Yao
#ifndef Stone_H
#define Stone_H
#include <SFML/Graphics.hpp>
#include <Box2D/Box2D.h>
#include "MyShape.h"

class Stone : public MyShape
{
 private:
	sf::Vector2f iniPosition;
	float pushBackForce;
 public:
	Stone(){}
	Stone(b2World& world,int radius,sf::Vector2f position,bool isDynamic = true)
	:MyShape(world,radius,position,isDynamic){iniPosition=position;}
	void move();
};
#endif