/********************************************
Course : TGD2251 Game Physics
Session: Trimester 2, 2019/20
ID and Name #1 : 1171100287 Kerk Chee Sheng
Contacts #1 : 012-3247708 1171100287@student.mmu.edu.my
ID and Name #2 : 1171101313 Teo Mou Yao
Contacts #2 : 018-9730678 1171101313@student.mmu.edu.my
********************************************/ 
//Teo Mou Yao
#include "ScoringSystem.h"
#include <iostream>

using namespace std;

ScoringSystem::ScoringSystem(){
	totalPoints=0;
	isGameEnd=false;
}

void ScoringSystem::getPoints(int p){
	totalPoints+=p;
}

int ScoringSystem::getTotalPoints(){
	return totalPoints;
}

void ScoringSystem::endGame(){
	isGameEnd=true;
}

char ScoringSystem::getMedal(){

	if(totalPoints<120){
		return 'B';
	}
	if(totalPoints<220){
		return 'S';
	}
	if(totalPoints>=220){
		return 'G';
	}
	return 'N';
}

char ScoringSystem::checkGameEnd(int health){
	
	if(isGameEnd){
		return 'W';
	}
	if(health<1){
		return 'L';
	}
	return 'N';
	
}