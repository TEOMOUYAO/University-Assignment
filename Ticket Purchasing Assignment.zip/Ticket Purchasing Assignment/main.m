while true
sprintf('Please Choose a Random Number Generator Below\n1 - Linear Congruential Generators\n2 - Random Uniform Number Generator')
r=input('Enter: ');
if (r== 1)
    randomizer='LCG'
    break
elseif (r==2)
    randomizer='RUN'
    break
else
    sprintf('Please choose either 1 or 2 for random number generator')
end
end

NumberCounter=2;
NumberVipCounter=1;
TotalTicket=[30,30,40,30,30;40,30,30,35,25;30,40,35,25,30;35,30,25,40,30;40,30,30,35,25];
ServiceTable=[0.2f,0.15f,0.3f,0.2f,0.1f;0.2f,0.35f,0.65f,0.85f,1f;0,21,36,66,86;20,35,65,85,100];
InterarrTable=[0.4f,0.2f,0.2f,0.1f,0.1f;0.3f,0.6f,0.8f,0.9f,1f;0,41,61,81,91;40,60,80,90,100];
DayTable=[0.2f,0.3f,0.15f,0.2f,0.15f;0.2f,0.5f,0.65f,0.85f,1f;0,21,51,66,86;20,50,65,85,100];
TicketTable=[0.2f,0.3f,0.25f,0.1f,0.15f;0.2f,0.5f,0.75f,0.85f,1f;0,21,51,76,86;20,50,75,85,100];
MovieName=[' Bumblebee';'    Frozen';'Take Point';'   Aquaman';'Robin Hood'];
MoviePrice=[15,15,10,15,10];

InputPrint(TotalTicket,ServiceTable,InterarrTable,DayTable,MovieName,TicketTable,MoviePrice);


NumberCustomer=round(rand*100)+150;
for(i=1:NumberCustomer)
CustTypeRand=rand*100;
if (CustTypeRand <90)
    CustType(i)=1; 
else
    CustType(i)=2; 
end
end


Customer=CustomerTable(randomizer,NumberCustomer,TotalTicket,MoviePrice);

Counter=CounterTable(Customer,NumberCustomer,NumberCounter,NumberVipCounter,TotalTicket,CustType);
printf('\nNumber of customer = %d',NumberCustomer);


print(Customer,NumberCustomer,Counter,NumberCounter,NumberVipCounter,TotalTicket);












