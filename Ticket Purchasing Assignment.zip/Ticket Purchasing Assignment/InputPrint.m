function InputPrint(&TotalTicket,&ServiceTable,&InterarrTable,&DayTable,&MovieName,&TicketTable,&MoviePrice)

    printf('--------------------------------------------------------------\n');
    printf('Day | Bumblebee | Frozen | Take Point | Aquaman | Robin Hood |\n');
    printf('--------------------------------------------------------------\n');
    for(i=1:5);
        printf('%4d|%11d|%8d|%12d|%9d|%12d|\n',i,TotalTicket(1,i),TotalTicket(2,i),TotalTicket(3,i),TotalTicket(4,i),TotalTicket(5,i));       
    end;
    printf('--------------------------------------------------------------\n\n');

    printf('--------------------------------------------\n');
    printf('Service Time | Probability | CDF |  Range  |\n');
    printf('--------------------------------------------\n');
    for(i=3:7);
        printf('%13d|%13.2f|%5.2f|%3d -%4d|\n',i,ServiceTable(1,i-2),ServiceTable(2,i-2),ServiceTable(3,i-2),ServiceTable(4,i-2));       
    end;
    printf('--------------------------------------------\n\n');
    
    printf('-------------------------------------------------\n');
    printf('Inter-arrival Time| Probability | CDF |  Range  |\n');
    printf('-------------------------------------------------\n');
    for(i=1:5);
    printf('%18d|%13.2f|%5.2f|%3d -%4d|\n',i,InterarrTable(1,i),InterarrTable(2,i),InterarrTable(3,i),InterarrTable(4,i));       
    end;
    printf('-------------------------------------------------\n\n');
    
    printf('-----------------------------------\n');
    printf('Day | Probability | CDF |  Range  |\n');
    printf('-----------------------------------\n');
    for(i=1:5);
        printf('%4d|%13.2f|%5.2f|%3d -%4d|\n',i,DayTable(1,i),DayTable(2,i),DayTable(3,i),DayTable(4,i));       
    end;
    printf('-----------------------------------\n\n');
    
    printf('---------------------------------------------------\n');
    printf('Ticket Type | Probability | CDF |  Range  | Price |\n');
    printf('---------------------------------------------------\n');
    for(i=1:5);
        printf('%12s|%13.2f|%5.2f|%3d -%4d|%7d\n',MovieName(i,1:10),TicketTable(1,i),TicketTable(2,i),TicketTable(3,i),TicketTable(4,i),MoviePrice(1));       
    end;
    printf('---------------------------------------------------\n\n');