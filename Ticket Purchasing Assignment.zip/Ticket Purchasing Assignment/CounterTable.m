function Counter = CounterTable(&Customer,NumberCustomer,NumberCounter,NumberVipCounter,&AfterTotalTicket,CustType)

Counter=struct('NoCustomer',cell(NumberCounter+NumberVipCounter,NumberCustomer),'Service',cell(NumberCounter+NumberVipCounter,NumberCustomer),'TimeServiceBegin',cell(NumberCounter+NumberVipCounter,NumberCustomer),'TimeServiceEnd',cell(NumberCounter+NumberVipCounter,NumberCustomer),'WaitingTime',cell(NumberCounter+NumberVipCounter,NumberCustomer),'TimeSpend',cell(NumberCounter+NumberVipCounter,NumberCustomer));
for(i=1:NumberCounter+NumberVipCounter)
    Counter(i,1).TimeServiceBegin=0;
end

BeforeTotalTicket=AfterTotalTicket;
a=ones(1,NumberCounter+NumberVipCounter);
lastservice=0;
for(i=1:NumberCustomer)
    
    if(CustType(i)==1)
        smallest=1;
        if(NumberCounter>1)
            for(j=1:(NumberCounter-1))
                if(Counter(j+1,a(j+1)).TimeServiceBegin < Counter(smallest,a(smallest)).TimeServiceBegin)
                    smallest=j+1;
                end;
            end;
        end;
    end;
    
    if(CustType(i)==2)
        smallest=NumberCounter+1;
        if(NumberVipCounter>1)
            for(j=NumberCounter+1:NumberCounter+NumberVipCounter-1)
                if(Counter(j+1,a(j+1)).TimeServiceBegin < Counter(smallest,a(smallest)).TimeServiceBegin)
                    smallest=j+1;
                end;
            end;
        end;
    end;
    
    Counter(smallest,a(smallest)).NoCustomer = i;
    Counter(smallest,a(smallest)).Service =  Customer(i).Service;
    if(Counter(smallest,a(smallest)).TimeServiceBegin < Customer(i).ArrivalTime)
        Counter(smallest,a(smallest)).WaitingTime=0;        
        Counter(smallest,a(smallest)).TimeServiceBegin=Customer(i).ArrivalTime;
    else
        Counter(smallest,a(smallest)).WaitingTime=Counter(smallest,a(smallest)).TimeServiceBegin-Customer(i).ArrivalTime;
    end;
    Counter(smallest,a(smallest)).TimeServiceEnd =  Counter(smallest,a(smallest)).TimeServiceBegin + Counter(smallest,a(smallest)).Service;
    Counter(smallest,a(smallest)).TimeSpend=Counter(smallest,a(smallest)).Service + Counter(smallest,a(smallest)).WaitingTime;
    a(smallest)=a(smallest)+1;
    Counter(smallest,a(smallest)).TimeServiceBegin = Counter(smallest,(a(smallest)-1)).TimeServiceEnd;
    if(Counter(smallest,(a(smallest)-1)).TimeServiceEnd>lastservice)
        lastservice=Counter(smallest,(a(smallest)-1)).TimeServiceEnd;
    end;
end;

for(i=NumberCounter+1:NumberCounter+NumberVipCounter)
    printf('Counter %1d, ',i);
    if(i==NumberCounter+NumberVipCounter)
        printf(' are only for VIP customer.\n')
    end;
end;
printf('Minute 0000: Counter 1 and %1d are in operation.\n',NumberCounter+1);
a=ones(1,NumberCounter+NumberVipCounter);
b=ones(1,NumberCounter+NumberVipCounter);
arrivalCustomer=1;
time=0;
for(i=0:lastservice)
    if(arrivalCustomer<=NumberCustomer)
        if(Customer(1,arrivalCustomer).ArrivalTime==i)
            printf('Minute %04d: Arrival   of  ',Customer(1,arrivalCustomer).ArrivalTime);
            if(arrivalCustomer==1)
                printf(' first ');
            elseif(arrivalCustomer==2)
                printf('second ');
            elseif(arrivalCustomer==3)
                printf(' third ');
            else
                printf('%4dth ',arrivalCustomer);
            end;
            if(CustType(arrivalCustomer)==1)
                printf('Guest ');
            else
                printf('VIP   ');
            end;
            printf('customer purchase %1d tickets of %1s.\n',Customer(1,arrivalCustomer).NumberTicket,Customer(1,arrivalCustomer).Type);
            arrivalCustomer=arrivalCustomer+1;
        end;
    end;
    for(j=1:NumberCounter+NumberVipCounter)
        if(Counter(j,b(j)).TimeServiceEnd==i)
                printf('Minute %04d: Departure of  ',Counter(j,b(j)).TimeServiceEnd );
                if(Counter(j,b(j)).NoCustomer==1)
                    printf(' first ');
                elseif(Counter(j,b(j)).NoCustomer==2)
                    printf('second ');
                elseif(Counter(j,b(j)).NoCustomer==3)
                    printf(' third ');
                else
                    printf('%4dth ',Counter(j,b(j)).NoCustomer);
                end;
                if(CustType(Counter(j,b(j)).NoCustomer)==1)
                    printf('Guest ');
                else
                    printf('VIP   ');
                end;
                printf('customer         where the Counter Number is %1d.\n',j);
                b(j)=b(j)+1;
            end;
        if(isempty(Counter(j,a(j)).NoCustomer))
            continue;
        end;
            if(Counter(j,a(j)).TimeServiceBegin==i)
                if(a(j)==1 & ~i==0 & ~j==NumberCounter+1)
                    printf('Minute %04d: Counter %1d start operation.\n',Counter(j,a(j)).TimeServiceBegin,j);
                end;
                printf('Minute %04d: Service   for ',Counter(j,a(j)).TimeServiceBegin);
                if(Counter(j,a(j)).NoCustomer==1)
                    printf(' first ');
                elseif(Counter(j,a(j)).NoCustomer==2)
                    printf('second ');
                elseif(Counter(j,a(j)).NoCustomer==3)
                    printf(' third ');
                else
                    printf('%4dth ',Counter(j,a(j)).NoCustomer);
                end;
                if(CustType(Counter(j,b(j)).NoCustomer)==1)
                    printf('Guest ');
                else
                    printf('VIP   ');
                end;
                printf('customer started where Counter Number is %1d.\n',j);
                if(a(j)>1)
                    if((Counter(j,a(j)).TimeServiceBegin-Counter(j,a(j)-1).TimeServiceEnd)>0)
                        printf('Counter %1d had take %1d minutes to rest.\n',j,(Counter(j,a(j)).TimeServiceBegin-Counter(j,a(j)-1).TimeServiceEnd));
                    end;
                end;
                if(strcmp(Customer(1,Counter(j,a(j)).NoCustomer).Type,'Bumblebee'))
                        type=1;
                end
                if(strcmp(Customer(1,Counter(j,a(j)).NoCustomer).Type,'Frozen'))
                        type=2;
                end
                if(strcmp(Customer(1,Counter(j,a(j)).NoCustomer).Type,'Take Point'))
                        type=3;
                end
                if(strcmp(Customer(1,Counter(j,a(j)).NoCustomer).Type,'Aquaman'))
                        type=4;
                end
                if(strcmp(Customer(1,Counter(j,a(j)).NoCustomer).Type,'Robin Hood'))
                        type=5;
                end
                AfterTotalTicket(type,Customer(1,Counter(j,a(j)).NoCustomer).Day)=AfterTotalTicket(type,Customer(1,Counter(j,a(j)).NoCustomer).Day)-Customer(1,Counter(j,a(j)).NoCustomer).NumberTicket;
                if((AfterTotalTicket(type,Customer(1,Counter(j,a(j)).NoCustomer).Day))==0)
                    printf('Ticket type %1s of the %1d days is sold out\n',Customer(1,Counter(j,a(j)).NoCustomer).Type,Customer(1,Counter(j,a(j)).NoCustomer).Day);
                end;
                a(j)=a(j)+1;
            end; 
    end;
    time=time+1;
    if(time==60 | i==(lastservice-1))
        fastest=1;
        for(i=1:4)
            totalbefore1=0;
            totalafter1=0;
            totalbefore2=0;
            totalafter2=0;
            for(j=1:5)
                totalbefore1=totalbefore1+BeforeTotalTicket(fastest,j);
                totalafter1=totalafter1+AfterTotalTicket(fastest,j);
                totalbefore2=totalbefore2+BeforeTotalTicket(i+1,j);
                totalafter2=totalafter2+AfterTotalTicket(i+1,j);
            end;
            percentage1=(totalbefore1-totalafter1)/double(totalbefore1)*100;
            percentage2=(totalbefore2-totalafter2)/double(totalbefore2)*100;
            if(percentage1<percentage2)
                fastest=i+1;
            end;
        end;
        if(fastest==1)
            typename='Bumblebee';
        end
        if(fastest==2)
            typename='Frozen';
        end
        if(fastest==3)
            typename='Take Point';
        end
        if(fastest==4)
            typename='Aquaman';
        end
        if(fastest==5)
            typename='Robin Hood';
        end
        printf('Ticket type %1s is selling fastest\n',typename);
        time=0;
        BeforeTotalTicket=AfterTotalTicket;
    end; 
    if(i==lastservice)
        for(j=1:NumberCounter+NumberVipCounter)
            printf('Minute %04d: Couter %1d closed.\n',i,j);
        end;
    end;
end;

