function Customer=CustomerTable(randomizer,&NumberCustomer,TotalTicket,MoviePrice)
arrival=0;

Customer = struct('RdService',cell(1,NumberCustomer),'Service',cell(1,NumberCustomer),'RdInterval',cell(1,NumberCustomer),'Interval',cell(1,NumberCustomer),'ArrivalTime',cell(1,NumberCustomer),'RdDay',cell(1,NumberCustomer),'Day',cell(1,NumberCustomer),'RdType',cell(1,NumberCustomer),'Type',cell(1,NumberCustomer),'NumberTicket',cell(1,NumberCustomer),'TotalAmountPaid',cell(1,NumberCustomer));

for(i=1:NumberCustomer);
TotalTicketDay=sum(TotalTicket);
if(sum(TotalTicketDay)==0)
    NumberCustomer=i-1;
    break;
end
Random=feval(randomizer,5,0,100);
Customer(1,i).RdService=Random(1);
Customer(1,i).Service=rdservice(Customer(1,i).RdService);
Customer(1,i).RdInterval=Random(2);
Customer(1,i).Interval=rdinterarr(Customer(1,i).RdInterval);
Customer(1,i).ArrivalTime=arrival;
arrival=arrival+Customer(1,i).Interval;;
while(true);
Random=feval(randomizer,5,0,100);
Customer(1,i).RdDay=Random(1);
Customer(1,i).Day=rdday(Customer(1,i).RdDay);

if(TotalTicketDay(Customer(1,i).Day)==0)
    continue;
end
Customer(1,i).RdType=Random(2);
Customer(1,i).Type=rdmovie(Customer(1,i).RdType);

if(strcmp(Customer(1,i).Type,'Bumblebee'))
    if(TotalTicket(1,Customer(1,i).Day)~=0)
        type=1;
    else
        continue;
    end
end
if(strcmp(Customer(1,i).Type,'Frozen'))
    if(TotalTicket(2,Customer(1,i).Day)~=0)
        type=2;
    else
        continue;
    end
end
if(strcmp(Customer(1,i).Type,'Take Point'))
    if(TotalTicket(3,Customer(1,i).Day)~=0)
        type=3;
    else
        continue;
    end
end
if(strcmp(Customer(1,i).Type,'Aquaman'))
    if(TotalTicket(4,Customer(1,i).Day)~=0)
        type=4;
    else
        continue;
    end
end
if(strcmp(Customer(1,i).Type,'Robin Hood'))
    if(TotalTicket(5,Customer(1,i).Day)~=0)
        type=5;
    else
        continue;
    end
    
end
max=10;
if (TotalTicket(type,Customer(1,i).Day) <max)
    max=TotalTicket(type,Customer(1,i).Day);
end
Customer(1,i).NumberTicket=feval(randomizer,5,1,max)(1);
if((TotalTicket(type,Customer(1,i).Day)-Customer(1,i).NumberTicket) >= 0)
    break;
end
end
       
Customer(1,i).TotalAmountPaid = Customer(1,i).NumberTicket*MoviePrice(type);
TotalTicket(type,Customer(1,i).Day)=TotalTicket(type,Customer(1,i).Day)-Customer(1,i).NumberTicket;
end;

