function print(&Customer,CustomerNumber,&Counter,NumberCounter,NumberVipCounter,&TotalTicket)
    TotalInterArr=0;
    TotalArr=0;
    TotalWaitTime=0;
    TotalWaitCust=0;
    TotalService=zeros(1,NumberCounter+NumberVipCounter);
    TotalSales=zeros(1,NumberCounter+NumberVipCounter);
    TotalTimeSpent=0;
    CustNumCounter=zeros(NumberCounter+NumberVipCounter);
    
    printf('\n---------------------------------------------------------------------------------------------------------------------------\n');
    printf('N  |       RN for      | Interarrival | Arrival | RN for the | Day | RN for the |  Movie   |     Num of      | Total Amount |\n');
    printf('   | Interarrival Time |     Time     |  Time   |    Day     |     |    Movie   |          | ticket purchase |  Paid ( RM ) |\n');
    printf('-----------------------------------------------------------------------------------------------------------------------------\n');
    for(i=1:CustomerNumber);
    printf('%3d|%19d|%14d|%9d|%12d|%5d|%12d|%10s|%17d|%14d|\n',i,Customer(1,i).RdInterval,Customer(1,i).Interval,Customer(1,i).ArrivalTime,Customer(1,i).RdDay,Customer(1,i).Day,Customer(1,i).RdType,Customer(1,i).Type,Customer(1,i).NumberTicket,Customer(1,i).TotalAmountPaid);       
    TotalInterArr=TotalInterArr+ Customer(1,i).Interval;
    TotalArr=TotalArr+Customer(1,i).ArrivalTime;
    end;
    printf('----------------------------------------------------------------------------------------------------------------------------\n\n\n');
    
    for(i=1:NumberCounter+NumberVipCounter)
    printf('\nCounter %2d ',i);
    if(i>NumberCounter)
        printf('for VIP only:\n');
    else
        printf(':\n');
    end;
    printf('----------------------------------------------------------------------------------------------\n');
    printf('N  |    RN for    |  Service  | Time Service | Time Service |   Waiting  |     Time Spend     |\n');
    printf('   | Service Time |    Time   |    Begin     |      End     |    Time    |   in the System    |\n');
    printf('----------------------------------------------------------------------------------------------\n');
    for(j=1:CustomerNumber);
        if(isempty(Counter(i,j).NoCustomer))
            break;
        end;  
        printf('%3d|%14d|%11d|%14d|%14d|%12d|%20d|\n',Counter(i,j).NoCustomer ,Customer(Counter(i,j).NoCustomer).RdService,Counter(i,j).Service, Counter(i,j).TimeServiceBegin, Counter(i,j).TimeServiceEnd,Counter(i,j).WaitingTime,Counter(i,j).TimeSpend);
        TotalWaitTime=TotalWaitTime+Counter(i,j).WaitingTime;
        if (Counter(i,j).WaitingTime > 0 )
            TotalWaitCust=TotalWaitCust+1;
        end
        TotalService(i)=TotalService(i)+Counter(i,j).Service;
        CustNumCounter(i)=CustNumCounter(i) +1;
        TotalTimeSpent=TotalTimeSpent +Counter(i,j).TimeSpend;
        TotalSales(i)=TotalSales(i) + Customer(1,Counter(i,j).NoCustomer).NumberTicket; 
    end;
    printf('----------------------------------------------------------------------------------------------\n\n');
    end;
    printf('\nRemaining Tickets\n');
    printf('-------------------------------------------------------------\n');
    printf('Day | Bumblebee | Frozen | Take Point | Aquaman | Robin Hood|\n');
    printf('-------------------------------------------------------------\n');
    for(i=1:5);
        printf('%4d|%11d|%8d|%12d|%9d|%11d|\n',i,TotalTicket(1,i),TotalTicket(2,i),TotalTicket(3,i),TotalTicket(4,i),TotalTicket(5,i));
    end;
    printf('-------------------------------------------------------------\n');

    
    printf('Average Waiting Time = %f\n',TotalWaitTime/CustomerNumber);
    printf('Average Inter-arrival Time = %f\n',TotalInterArr/(CustomerNumber-1));
    printf('Average Arrival Time = %f\n',TotalArr/(CustomerNumber-1));
    printf('Average Time Spent = %f\n',TotalTimeSpent/CustomerNumber);
    printf('Probability that a customer has to wait in the queue = %f\n', TotalWaitCust/CustomerNumber);
    for (i=1:NumberCounter+NumberVipCounter)
    printf('Average Service Time for Counter %d = %f\n' ,i,TotalService(i)/CustNumCounter(i));
    end
    for (i=1:NumberCounter+NumberVipCounter)
    printf('Average Sales for Counter %d = %f\n' ,i,TotalSales(i)/CustNumCounter(i));
    end
    