#include "bst.h"
#include "avl.h"
#include "hash.h"
#include "intRandomGenerator.h"
#include <fstream>
#include <vector>
#include <chrono>
#include <list>
#include<bits/stdc++.h>

using namespace std;

class Question1
{
private:
  AVL<int> avl;
  BST<int> bst;
  Hash hash;
  vector<int> array;
  vector<int> primeArray;
public:
  Question1()
  {
    SieveOfEratosthenes(10001000);
  }

  void openFile(string file="bst_avl_hash_10.txt")
  {
    int x;
    if(!array.empty())
      array.clear();
    ifstream inFile;
    inFile.open(file);
    if (!inFile)
    {
      cout << "Unable to open file "<< file<<endl;
      return;
    }
    while (inFile >> x)
    {
        array.push_back(x);
    }
    inFile.close();

    runAVL();
    runBST();
    runHash();
  }

  void runAVL()
  {
    avl.makeEmpty();
    for(int&x:array)
    {
     avl.insert(x);
   }
  }

  void runBST()
  {
    bst.makeEmpty();
    for(int&x:array)
    {
     bst.insert(x);
   }
  }

  void runHash()
  {
    int sizeHash;
    for(auto&x: primeArray)
    {
      if(x>=array.size() && !isPowerOfTwo(x))
      {
        sizeHash=x;
        break;
      }
    }
    hash.resize(sizeHash);
    for(int&x:array)
    {
     hash.insert(x);
   }
  }

  void printHash()
  {
    ofstream myfile;
    myfile.open ("Hash_Output.txt");
    hash.displayHash(myfile);
    myfile.close();
  }

  void printAVL()
  {
    ofstream myfile;
    myfile.open ("AVL_Output.txt");
    avl.printTree(myfile);
    myfile.close();
  }

  void printBST()
  {
    ofstream myfile;
    myfile.open ("BST_Output.txt");
    bst.printTree(myfile);
    myfile.close();
  }

  void search(int s)
  {
    for(int i=0; i<3; i++)
    {
    auto start = chrono::system_clock::now();
    switch(i)
    {
      case 0: if(bst.contains(s)){cout<<"found."<<endl<<"BST search used ";}
              else{cout<<"not found."<<endl<<"BST search used ";}break;
      case 1: if(avl.contains(s)){cout<<"found."<<endl<<"AVL search used ";}
              else{cout<<"not found."<<endl<<"AVL search used ";}break;
      case 2: if(bst.contains(s)){cout<<"found."<<endl<<"Hash search used ";}
              else{cout<<"not found."<<endl<<"Hash search used ";}break;

    }
    auto end = chrono::system_clock::now();
    chrono::duration<double> duration= end - start;
    cout<<duration.count()<<" seconds"<<endl;
    }
  }


  bool isPowerOfTwo(int n)
  {
     if(n==0)
     return false;
     return (ceil(log2(n)) == floor(log2(n)));
  }

  void SieveOfEratosthenes(int n)
  {
    // Create a boolean array "prime[0..n]" and initialize
    // all entries it as true. A value in prime[i] will
    // finally be false if i is Not a prime, else true.
    vector<bool> prime(n+1);
    fill(prime.begin(), prime.end(), 1);
    //memset(&prime[0], true, sizeof(prime) * prime.size());

    for (int p=2; p*p<=n; p++)
    {
        // If prime[p] is not changed, then it is a prime
        if (prime[p] == true)
        {
            // Update all multiples of p greater than or
            // equal to the square of it
            // numbers which are multiple of p and are
            // less than p^2 are already been marked.
            for (int i=p*p; i<=n; i += p)
                prime[i] = false;
        }
    }

    for (int p=2; p<=n; p++)
       if (prime[p])
          this->primeArray.push_back(p);
  }
};





int main()
{
    Question1 a;
    a.openFile();
    for(;;)
    {
      int choose,choose2;
      cout<<"1. load File"<<endl;
      cout<<"2. print and save BST output"<<endl;
      cout<<"3. print and save AVL output"<<endl;
      cout<<"4. print and save Hash output"<<endl;
      cout<<"5. generate random integer"<<endl;
      cout<<"6. Search integer number"<<endl;
      cout<<"7. Exit"<<endl;
      cout<<"choose number: ";
      cin>>choose;

      switch(choose)
      {
        case 1:
        {
          cout<<"\nLoad which file: "<<endl;
          cout<<"1. bst_avl_hash_10.txt"<<endl;
          cout<<"2. bst_avl_hash_00500000.txt"<<endl;
          cout<<"3. bst_avl_hash_01000000.txt"<<endl;
          cout<<"4. bst_avl_hash_05000000.txt"<<endl;
          cout<<"5. bst_avl_hash_10000000.txt"<<endl;
          cout<<"choose number: ";
          cin>>choose2;
          switch(choose2)
          {
            case 1: a.openFile();break;
            case 2: a.openFile("bst_avl_hash_00500000.txt");break;
            case 3: a.openFile("bst_avl_hash_01000000.txt");break;
            case 4: a.openFile("bst_avl_hash_05000000.txt");break;
            case 5: a.openFile("bst_avl_hash_10000000.txt");break;
          }
          break;
        }
        case 2: a.printBST();break;
        case 3: a.printAVL();break;
        case 4: a.printHash();break;
        case 5:
        {
          cout<<"generate how many number: "<<endl;
          cout<<"1. 500k"<<endl;
          cout<<"2. 1M"<<endl;
          cout<<"3. 5M"<<endl;
          cout<<"4. 10M"<<endl;
          cout<<"5. 10"<<endl;
          cout<<"choose number: ";
          cin>>choose2;
          intRandomGenerator(choose2);
        }break;
        case 6:
        {
          cout<<"Search integer number : ";
          cin>>choose2;
          a.search(choose2);
        }
        default: break;
      }

      cout<<endl<<endl<<endl;
      if(choose>=7)
        {break;}
    }
    return 0;
}
