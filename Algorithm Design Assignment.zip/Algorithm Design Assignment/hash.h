#ifndef HASH_H
#define HASH_H
#include<iostream>
#include <list>
#include <fstream>
using namespace std;

class Hash
{
    int BUCKET;

    list<int> *table;
public:
    Hash(int V);
    Hash();
    ~Hash();
    void insert(int x);
    void makeEmpty();
    void resize(int size);
    int hashFunction(int x)
    {
        return (x % BUCKET);
    }

    void displayHash(ostream & out = cout);
    bool searchHash(int target);
};

Hash::Hash(int b)
{
    this->BUCKET = b;
    table = new list<int>[BUCKET];
}

Hash::Hash()
{
    this->BUCKET = 1;
    table = new list<int>[BUCKET];
}

Hash::~Hash()
{
    makeEmpty();
    delete table;
}

void Hash::makeEmpty()
{
  for (int i = 0; i < BUCKET; i++)
  {
    table[i].clear();
  }
}

void Hash::insert(int key)
{
    int index = hashFunction(key);
    table[index].push_front(key);
}

void Hash::displayHash(ostream & out)
{
  for (int i = 0; i < BUCKET; i++) {
    out << i;
    if(table[i].size()==0)
      out<<endl;
    else{
    for (auto x : table[i])
    {
        out << " --> " << x;
    }out<<endl;}
  }
}

bool Hash::searchHash(int target)
{
  for (int i = 0; i < BUCKET; i++)
    for (auto x : table[i])
      if(target==x)
        return true;
  return false;
}

void Hash::resize(int size)
{
  makeEmpty();
  delete table;
  BUCKET = size;
  table = new  list<int>[BUCKET];
}

#endif
