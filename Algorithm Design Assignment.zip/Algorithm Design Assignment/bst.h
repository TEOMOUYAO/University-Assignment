#ifndef BST_H
#define BST_H

#include <iostream>
#include <iomanip>
#include <algorithm>
using namespace std;

class UnderflowException { };

template <typename Comparable>
class BST
{
private:
  struct Node
  {
      Comparable data;
      Node *left;
      Node *right;

      Node( const Comparable & thedata, Node *lt, Node *rt )
        : data{ thedata }, left{ lt }, right{ rt } { }

      Node( Comparable && thedata, Node *lt, Node *rt )
        : data{ std::move( thedata ) }, left{ lt }, right{ rt } { }
  };

  Node *root;

  // Internal method to insert into a subtree.
  void insert( const Comparable & x, Node * & t )
  {
      if( t == nullptr )
          t = new Node{ x, nullptr, nullptr };
      else if( x < t->data )
          insert( x, t->left );
      else if( t->data < x )
          insert( x, t->right );
      else
          return;  // Duplicate; do nothing
  }

  // Internal method to insert into a subtree.
  void insert( Comparable && x, Node * & t )
  {
      if( t == nullptr )
          t = new Node{ std::move( x ), nullptr, nullptr };
      else if( x < t->data )
          insert( std::move( x ), t->left );
      else if( t->data < x )
          insert( std::move( x ), t->right );
      else
          return;  // Duplicate; do nothing
  }

  void remove( const Comparable & x, Node * & t )
  {
      if( t == nullptr )
          return;   // Item not found; do nothing
      if( x < t->data )
          remove( x, t->left );
      else if( t->data < x )
          remove( x, t->right );
      else if( t->left != nullptr && t->right != nullptr ) // Two children
      {
          t->data = findMin( t->right )->data;
          remove( t->data, t->right );
      }
      else
      {
          Node *oldNode = t;
          t = ( t->left != nullptr ) ? t->left : t->right;
          delete oldNode;
      }
  }





  Node * findMin( Node *t ) const
  {
      if( t == nullptr )
          return nullptr;
      if( t->left == nullptr )
          return t;
      return findMin( t->left );
  }

  Node * findMax( Node *t ) const
  {
      if( t != nullptr )
          while( t->right != nullptr )
              t = t->right;
      return t;
  }

  bool contains( const Comparable & x, Node *t ) const
  {
      if( t == nullptr )
          return false;
      else if( x < t->data )
          return contains( x, t->left );
      else if( t->data < x )
          return contains( x, t->right );
      else
          return true;    // Match
  }

  void makeEmpty( Node * & t )
  {
      if( t != nullptr )
      {
          makeEmpty( t->left );
          makeEmpty( t->right );
          delete t;
      }
      t = nullptr;
  }


  void printTree( Node *t, ostream & out, int indent = 3 ) const
  {
      if( t != nullptr )
      {


          if( t->right ) {
              printTree( t->right, out, indent + 3 );
          }

          if(indent) out << setw(indent) << ' ';
          if( t->right ) out<<" /\n" << setw(indent) << ' ';
          out << t->data << endl;

          if( t->left ) {
              if(indent) out << setw(indent) << ' ' <<" \\\n";
              printTree( t->left, out, indent + 3 );
          }

      }
  }



  Node * clone( Node *t ) const
  {
      if( t == nullptr )
          return nullptr;
      else
          return new Node{ t->data, clone( t->left ), clone( t->right ) };
  }

public:
    BST( ) : root{ nullptr }
    {
    }

    ~BST( )
    {
        makeEmpty( );
    }

    const Comparable & findMin( ) const
    {
        if( isEmpty( ) )
            throw UnderflowException{ };
        return findMin( root )->data;
    }

    const Comparable & findMax( ) const
    {
        if( isEmpty( ) )
            throw UnderflowException{ };
        return findMax( root )->data;
    }

    bool contains( const Comparable & x ) const
    {
        return contains( x, root ); // recursion
    }

    bool isEmpty( ) const
    {
        return root == nullptr;
    }

    void printTree( ostream & out = cout ) const
    {
        if( isEmpty( ) )
            out << "Empty tree" << endl;
        else
            printTree( root, out );
    }

    void makeEmpty( )
    {
        makeEmpty( root );
    }

    // Insert x into the tree; duplicates are ignored.
    void insert( const Comparable & x )
    {
        insert( x, root );
    }

    // Insert x into the tree; duplicates are ignored.
    void insert( Comparable && x )
    {
        insert( std::move( x ), root );
    }

    // Remove x from the tree. Nothing is done if x is not found.
    void remove( const Comparable & x )
    {
        remove( x, root );
    }



};


#endif
