#ifndef INTRANDOMGENERATOR_H
#define INTRANDOMGENERATOR_H
#include <algorithm>
#include <chrono>
#include <iostream>
#include <random>
#include <fstream>
#include <vector>
using namespace std;

const int N1 = 500000;
const int N2 = 1000000;
const int N3 = 5000000;
const int N4 = 10000000;
const int N5 = 10;

void intRandomGenerator(int size)// 1:500000 2:1000000 3: 5000000 4:10000000 5:10
{
  mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
  vector<int> permutation;
  ofstream myfile;
  switch(size)
  {
    case 1:
      permutation.resize(N1);
      for (int i = 1; i <= N1; i++)
          permutation[i-1] = i;
      shuffle(permutation.begin(), permutation.end(), rng);
        myfile.open("bst_avl_hash_00500000.txt");
      break;
    case 2:
      permutation.resize(N2);
      for (int i = 1; i <= N2; i++)
          permutation[i-1] = i;
      shuffle(permutation.begin(), permutation.end(), rng);
        myfile.open("bst_avl_hash_01000000.txt");
      break;
    case 3:
      permutation.resize(N3);
      for (int i = 1; i <= N3; i++)
          permutation[i-1] = i;
      shuffle(permutation.begin(), permutation.end(), rng);
        myfile.open("bst_avl_hash_05000000.txt");
      break;
    case 4:
      permutation.resize(N4);
      for (int i = 1; i <= N4; i++)
          permutation[i-1] = i;
      shuffle(permutation.begin(), permutation.end(), rng);
        myfile.open("bst_avl_hash_10000000.txt");
      break;
    case 5:
      permutation.resize(N5);
      for (int i = 1; i <= N5; i++)
          permutation[i-1] = i;
      shuffle(permutation.begin(), permutation.end(), rng);
        myfile.open("bst_avl_hash_10.txt");
      break;
  }
  for(int &x: permutation)
      myfile << x << endl;
  myfile.close();
}
#endif
