<?php 
include 'hoteldb.inc.php';

if(isset($_POST['email']) && isset($_POST['name']) && isset($_POST['password']) && isset($_POST['confirm_password']) && isset($_POST['contact']) && isset($_POST['age']) ){
	$email=$_POST['email'];
	$name=$_POST['name'];
	$password=$_POST['password'];
	$confirm_password=$_POST['confirm_password'];
	$contact=$_POST['contact'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$acc_type=$_POST['acc_type'];
	
	if(empty($email)){
		header("Location: signup.php?error=Email is required");
		exit();
	}
	else if(empty($name)){
		header("Location: signup.php?error=Name is required");
		exit();
	}
	else if(empty($password)){
		header("Location: signup.php?error=Password is required");
		exit();
	}
	else if(empty($confirm_password)){
		header("Location: signup.php?error=Password Confirmation is required");
		exit();
	}
	else if(empty($contact)){
		header("Location: signup.php?error=Contact is required");
		exit();
	}
	else if(empty($age)){
		header("Location: signup.php?error=Age is required");
		exit();
	}
	
	$sql="select * from customer where Customer_Email='$email'";
	$result=execSQL($sql);
	$num = mysqli_num_rows($result);
		
	$sql2="select * from hoteloperator where HotelOperator_Email='$email'";
	$result2=execSQL($sql2);
	$num2 = mysqli_num_rows($result2);
	
	if((strpos($email, "@") == false) or (strpos($email, ".com") == false)){
		header("Location: signup.php?error=Email does not contain @ or .com");
		exit();
	}
	else if (($num > 0) or ($num2 > 0)){
		header("Location: signup.php?error=Email already in use");
		exit();
	}
	else if((strlen($password)<8) or (!preg_match("#[0-9]+#", $password)) or (!preg_match("#[a-z]+#", $password)) or (!preg_match("#[A-Z]+#", $password)) or (!preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $password))){
		header("Location: signup.php?error=Password: at least 8 char(include 1 digit, LC and UC letter, special char)");
		exit();
	}
	else if($password!=$confirm_password){
		header("Location: signup.php?error=Password and Password Confirmation are not the same");
		exit();
	}
	else if(is_numeric($age) == false){
		header("Location: signup.php?error=Age must be numeric value");
		exit();
	}
	
	if ($acc_type=="Customer"){
		$insert="insert into customer(Customer_Name,Customer_Password,Customer_Email,Customer_Contact,Customer_Age,Customer_Gender) values ('$name','$password','$email','$contact','$age','$gender')";
		execSQL($insert);
		header("Location: signin.php?success=Account created successfully");
		exit();
	}
	else{
		$insert="insert into hoteloperator(HotelOperator_Name,HotelOperator_Password,HotelOperator_Email,HotelOperator_Contact,HotelOperator_Age,HotelOperator_Gender) values ('$name','$password','$email','$contact','$age','$gender')";
		$sql1 = "select Hoteloperator_ID from  hoteloperator where HotelOperator_Email= '$email';";
		
		execSQL($insert);
		$result = execSQL($sql1);
		if($result)
		{
			$row = $result->fetch_assoc();
			$hotel_id=$row["Hoteloperator_ID"];
			$insert2="insert into hotel(Hotel_ID,HotelOperator_ID) values ('$hotel_id','$hotel_id')";
			execSQL($insert2);
		}
		header("Location: signin.php?success=Account created successfully");
		exit();
	}

}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign Up</title>
	<link href="css/signup.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	<form action="" method="post">
	<?php if (isset($_GET['error'])) {?>
		<p class="error"><?php echo $_GET['error']; ?></p>
	<?php } ?>
	<div class="login_box">
		<h2>Sign Up</h2>
		<div class="textbox">
			<input type="text" placeholder="Email" name="email">
		</div>
		
		<div class="textbox">
			<input type="text" placeholder="Name" name="name">
		</div>
		
		<div class="textbox">
			<table>			
			<tr>
			<td>
			<input id="pass1" type="password" placeholder="Password" name="password">
			</td>
			<td>
			<i id="eye1" class="fa fa-eye" aria-hidden="true" onclick="toggle1()"></i>
			</td>
			</tr>
			</table>
			<script>
				document.getElementById("eye1").style.color = "silver";
				var click1 = true;
				function toggle1(){
					if (click1){
						document.getElementById("pass1").setAttribute("type", "text");
						document.getElementById("eye1").style.color = "#d6ed17";
						click1 = false;
					}
					else{
						document.getElementById("pass1").setAttribute("type", "password");
						document.getElementById("eye1").style.color = "silver";
						click1 = true;
					}
				}
			</script>
		</div>
		
		<div class="textbox">
			<table>			
			<tr>
			<td>
			<input id="pass2" type="password" placeholder="Password Confirmation" name="confirm_password">
			</td>
			<td>
			<i id="eye2" class="fa fa-eye" aria-hidden="true" onclick="toggle2()"></i>
			</td>
			</tr>
			</table>
			<script>
				document.getElementById("eye2").style.color = "silver";
				var click2 = true;
				function toggle2(){
					if (click2){
						document.getElementById("pass2").setAttribute("type", "text");
						document.getElementById("eye2").style.color = "#d6ed17";
						click2 = false;
					}
					else{
						document.getElementById("pass2").setAttribute("type", "password");
						document.getElementById("eye2").style.color = "silver";
						click2 = true;
					}
				}
			</script>
		</div>
		
		<div class="textbox">
			<input type="text" placeholder="Contact" name="contact">
		</div>
		
		<div class="textbox">
			<input type="text" placeholder="Age" name="age">
		</div>		
		
		<div class="box">
			<label>Gender: </label><br/>
			<input type="radio" name="gender" value="M" checked>Male
			<input type="radio" name="gender" value="F">Female <br/>
        </div> 
		
		<div class="box">
			<label>Account Type: </label><br/>
			<input type="radio" name="acc_type" value="Customer" checked>Personal <br/>
			<input type="radio" name="acc_type" value="HO">Business <br/>
        </div> 
	
		<input class="btn" type="submit" value="Sign Up" >
	</div>
	</form>
</body>
</html>