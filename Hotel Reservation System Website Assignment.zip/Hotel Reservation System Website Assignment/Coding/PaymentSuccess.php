<html>
<head>
<title>Payment Status</title>
<link rel="icon" href="img/hotel go logo.png">
<?php
include 'hoteldb.inc.php';
if (session_status() == PHP_SESSION_NONE)
{
	session_save_path('tmp');
    session_start();
}
//create Date_ID 

$paycart= $_SESSION['payCart'];
if ($_SESSION['user_type'] ="Customer"){
$customerID = $_SESSION['user_id']; 
	
$sql="INSERT INTO Reservation (Customer_ID, Room_ID, Date_ID,Num_Rooms) 
Values ";
foreach($paycart as $roomID=> $val){
	foreach($val as $dateID => $numRoom){
		$sql.="(".$customerID.",".$roomID.",".$dateID.",".$numRoom."),";		
	}
	
}
$sql=substr($sql,0 ,-1);
$sql.=";";
// echo $sql;



if($result = execSQL($sql)){
	$status="Successful";
	$filename = "img/paymentTick.png";
	$_SESSION['numCart']=[];
	$_SESSION['payCart']=[];
}else{
	$status="Failed";
	$filename = "img/paymentCross.png";

	
}
}

?>

<style>

body{
	text-align: center;
	font-size: 1.2em;
	margin-top: 20%;
	
	
}
#Successful{
	color: green;
	font-weight: bold;
	font-size: 1.2em;
	
	
}
#Failed{
	color: red;
	font-weight: bold;
	font-size: 1.2em;
	
	
}

.pagetimer{
	color: red;
	font-weight:bold;
	font-size: 1.2em;
	
}

img{
	height: 200px;
	
}



</style>

</head>



<body>
<img src=<?php echo $filename?> />
<h1>ACKNOWLEDGEMENT OF PAYMENT</h2>
<h2>Your Online Payment is <label id=<?php echo $status;?> > <?php echo $status;?></label></h2>
<h3>You are redirecting to the Home Page in <span class="pagetimer">6</span> seconds...</h3>

<script>
var i = 5;
setInterval(function(){
	var obj =document.getElementsByClassName('pagetimer');
	obj[0].innerText= i;
	i--;
	if(i == -1){
		window.location = "home.php";
	}
	}, 1000);
	





</script>


</body>


</html>