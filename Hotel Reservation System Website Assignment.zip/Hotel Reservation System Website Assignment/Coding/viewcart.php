<html>
<head>
<title>View Cart</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/clear.css" rel="stylesheet">
<link href="css/viewcart.css" rel="stylesheet">
</head>


<?php 
include 'home_header.php';
if($_SESSION['user_type'] == "HO")
{
	header("Location: home.php");
}
$numcart=$_SESSION['numCart'];

$Cart=[];

$disabled = empty($numcart) ? "disabled='disabled'" :"" ;
$isLogin = (isset($_SESSION['user_type']) && isset($_SESSION['user_id'])) ? " var isLogin =true;" :  " var isLogin =false;";
echo "<script>".$isLogin."</script>";

if(isset($_GET['removeID'])){
	$remove=explode(",",$_GET['removeID']);
	while(!(array_search($remove,$numcart) === FALSE)){
		unset($numcart[array_search($remove,$numcart)]);
		$_SESSION['numCart']=$numcart;
	}	
	include 'calNumCart.php';
	$_GET= array();
}

foreach($numcart as $value){
	//RoomID
	$RoomID=$value[0];
	$CheckIN = $value[1];
	$CheckOUT = $value[2];
	$sql = "INSERT IGNORE INTO date(Check_In_Date,Check_Out_Date) Values
	('".$CheckIN." 08:00:00','".$CheckOUT." 12:00:00');
	";	
	if($result =execSQL($sql)){
		$sql="SELECT Date_ID From date Where Check_In_Date='".$CheckIN." 08:00:00' 
				and Check_Out_Date='".$CheckOUT." 12:00:00';";
		if($result = execSQL($sql)){
			$result = mysqli_fetch_array($result);
			if(isset($Cart[$RoomID])){
				array_push($Cart[$RoomID],$result['Date_ID']);
			}
			else
				$Cart[$RoomID]=array($result['Date_ID']);
		}	
	}
	$sql="alter table date auto_increment=1;";
	execSQL($sql);
	
}

//Count Number of Rooms
foreach ($Cart as $key => $val){
	$Cart[$key]=array_count_values($val);
}

//Get all values from date 
$sql = "Select * from date where Date_ID in (";
foreach ($Cart as $key => $val){
	foreach( $val as $id => $num)
		$sql.= $id.',';
}
$sql=substr($sql,0 ,-1);
$sql.=");";
if($result = execSQL($sql)){
	while($row = mysqli_fetch_row($result)){
		$dateDB[$row[0]] = [$row[1],$row[2]];
	}
	
}

// print_r($Cart);
$_SESSION['payCart']=$Cart;
$RoomList=[];
$TotalPrice=0;
foreach($Cart as $key => $value){
	$result =execSQL("SELECT * FROM room WHERE Room_ID =".$key.";");
	if($result){
		$result = mysqli_fetch_array($result);
		foreach($value as $dateid => $num){
		$name = $result["Room_Name"];
		$numBed= $result["Num_Bed"];
		$price= $result["Price_Per_Day"];
		$filename = "img/Room/".$key.".jpg";
		$numRoom = $num;
		$checkInVal = $dateDB[$dateid][0];
		$checkOutVal = $dateDB[$dateid][1];
		$RoomValues= [ "name" => $name, "numBed" => $numBed,
		"price" => $price, "filename" => $filename, "numRoom" => $numRoom,
		"checkIn" => $checkInVal, "checkOut" => $checkOutVal];
		$RoomList[$key][]= $RoomValues;
		$TotalPrice+=$price*$numRoom;
		}
	}else{
	die("ERROR : ROOM_ID is undefined");
	}
	
}



// print_r($RoomList);






?>
<script type="text/javascript">
function redirect(){
	if(isLogin){
		location.href = "PaymentSuccess.php";
		
	}else{
		location.href = "signin.php";
	}
	

	
}


</script>



<body>
<div class="cartList">
<h2>Room Cart</h2>
<div class='list'>
<table class= "cartTable">
	<?php
		foreach($RoomList as $key => $v){
			foreach($v as $value){
			echo "<tr><td><img id='roomImg' src='".$value['filename']."' alt='Room".$key."'/></td>";
			echo "<td><table id='valueTable'>
			<tr><td colspan='2'><label>Room Name</label>
				<name>".$value['name']."</name>
			</td></tr>
			<tr><td colspan='2'><label>Number of Beds</label>
			<numBed>".$value['numBed']."</numBed>
			</td></tr>
			<tr><td colspan='2'><label>Price per Day</label>
			<price>RM ".$value['price']."</price>
			</td></tr>
			<tr><td colspan='2'><label>Number of Rooms Reserved</label>
			<numRoom>".$value['numRoom']."</numRoom>
			</td></tr>
			<tr><td colspan='2'><label>Check In Date & Time</label>
			<numRoom>".$value['checkIn']."</numRoom>
			</td></tr>
			<tr><td colspan='2'><label>Check Out Date & Time</label>
			<numRoom>".$value['checkOut']."</numRoom>
			</td></tr>
			<tr><td><form action='RoomDetails.php' method='get'>
			<button name='Room_ID' id='viewRoom' type='submit' value='".$key."' 
					/>View Room Details</button></form></td>
					<td><form action='viewcart.php' method='get'>
					<button name='removeID' id='remove' type='submit' value="
			.$key.",".explode(" ",$value['checkIn'])[0].",".explode(" ",$value['checkOut'])[0]."
					/>Remove</button></form>
			</td></form></tr>					
			</table></td></tr>";
		}}
	?>
</table>
<table id="checkoutRow">
<tr><td id="emptyTD"></td>
<?php
	echo "<td id='Price'> Total Price : RM ".$TotalPrice."
		<input id='checkoutBtn' type='submit' value='Check Out' onclick='redirect()' ".$disabled."/>
		</td>" 
?>
</table>
</div>




</div>




</body>
<?php include 'home_footer.php'?>
</html>