<?php
	if(isset($_SESSION["numCart"])){
		echo "<script type='text/JavaScript'>"; 
		echo "var numCart=".count($_SESSION["numCart"]).";";
		echo "var obj = document.getElementsByClassName('cartNum');";
		echo "obj[0].innerText = numCart;";
		echo "</script>";
	}
	else{
		$_SESSION["numCart"]=[];
		echo "<script type='text/JavaScript'>";
		echo "document.getElementsByClassName('cartNum')[0].innerText = 0;";
		echo "</script>";
	}
?>