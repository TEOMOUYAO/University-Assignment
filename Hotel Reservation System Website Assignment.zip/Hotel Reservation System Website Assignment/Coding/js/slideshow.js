var slideIndex = 1;
var timer = null;
showDivs(slideIndex);

function plusDivs(n) 
{
	clearTimeout(timer);
	showDivs(slideIndex += n);
}

function currentDiv(n) 
{
	clearTimeout(timer);
	showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var y = document.getElementsByClassName("exSlide");
if(n==undefined){n=++slideIndex}
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length} ;
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  for (i = 0; i < y.length; i++) {
    y[i].style.border = "none";
	y[i].style.opacity = 0.5;
  }
  x[slideIndex-1].style.display = "block";
  y[slideIndex-1].style.border="5px solid ";
  y[slideIndex-1].style.opacity=1.0;
	timer = setTimeout(showDivs, 4000);
}



