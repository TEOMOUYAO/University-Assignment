
function showSearchPage(n,l)
{
	var a = document.getElementsByClassName("numbutton");
	var b = document.getElementsByClassName("previousPage")[0];
	var c = document.getElementsByClassName("nextPage")[0];
	
	for (i = 0; i < a.length; i++)
	{
		a[i].disabled = false;
		if(n == a[i].value)
		{
			a[i].disabled=true;
			a[i].style.backgroundColor="grey";
		}
	}
	
	if(n>0)
	{
		b.disabled=false;
	}
	else
	{
		b.disabled=true;
	}
	
	if(n<l-1)
	{
		c.disabled=false;
	}
	else
	{
		c.disabled=true;
	}
}
