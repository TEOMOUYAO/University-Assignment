function PreviewImage() {
		
		var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("UploadFile").files[0]);
		oFReader.onload = function (oFREvent) {
            document.getElementById("UploadImg").src = oFREvent.target.result;
        };
        
}
