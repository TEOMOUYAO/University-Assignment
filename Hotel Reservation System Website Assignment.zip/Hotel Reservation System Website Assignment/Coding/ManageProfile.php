<html>

<head>
    <title>Manage Profile</title>
	<link href="css/ManageProfile.css" rel="stylesheet">

	<?php 
		include 'home_header.php';

	if (isset($_POST['name']) && isset($_POST['contact']) && isset($_POST['age']) && isset($_POST['gender'])) {
		if($_FILES['newImage']['size']){
			$errors= array();
			$file_size = $_FILES['newImage']['size'];
			$file_tmp = $_FILES['newImage']['tmp_name'];
			$file_type = $_FILES['newImage']['type'];
			$fileToken=explode('.',$_FILES['newImage']['name']);
			$file_ext=strtolower($fileToken[1]);
			$file_name = $_SESSION["user_id"].".".$file_ext;

			$extensions= array("jpeg","jpg","png");

			if(in_array($file_ext,$extensions)=== false){
				$errors[]="extension not allowed, please choose a JPEG or PNG file.";
			}

			// if($file_size > 2097152) {
			// $errors[]='File size must be excately 2 MB';
			// }

			if(empty($errors)==true) {
				if($_SESSION['user_type']=="Customer"){
					move_uploaded_file($file_tmp,"img/customer/".$file_name);
				}else{
					move_uploaded_file($file_tmp,"img/hotelOperator/".$file_name);
				}
			}else{
				header("Location: ManageProfile.php?error=$errors[0]");
				exit();
			}
		}
		
		
		$name = $_POST['name'];
		$contact = $_POST['contact'];
		$age = $_POST['age'];
		$gender = $_POST['gender'];
		$acc_type = $_SESSION['user_type'];
		$userid = $_SESSION['user_id'];
		
		if (empty($name)) {
			header("Location: ManageProfile.php?error=Name is required");
			exit();
		} else if (empty($contact)) { 
			header("Location: ManageProfile.php?error=Contact is required");
			exit();
		} else if (empty($age)) {
			header("Location: ManageProfile.php?error=Age is required");
			exit();
		}

		if ($acc_type == "Customer") {
			if (is_numeric($age) == false) {
				header("Location: ManageProfile.php?error=Age must be numeric value");
				exit();
			} else {
				$sql = "Update customer Set Customer_Name='$name', Customer_Contact='$contact', Customer_Age='$age', Customer_Gender='$gender'  where Customer_ID = '$userid'";
				execSQL($sql);
				header("Refresh:0; url=ManageProfile.php?log= Profile Updated Successfully");
			}
		} else {
			if (is_numeric($age) == false) {
				header("Location: ManageProfile.php?error=Age must be numeric value");
				exit();
			} else {
				$sql = "Update hoteloperator Set HotelOperator_Name='$name', HotelOperator_Contact='$contact', HotelOperator_Age='$age', HotelOperator_Gender='$gender'  where HotelOperator_ID = '$userid'";
				execSQL($sql);
				header("Refresh:0; url=ManageProfile.php?log= Profile Updated Successfully");
			}
		}
	}
		
		$userID = $_SESSION['user_id'];
		$userType = $_SESSION['user_type'];
		
		if($userType == "Customer"){
			$result =execSQL("SELECT * FROM customer WHERE Customer_ID =".$userID.";");
			if($result){
				$result = mysqli_fetch_array($result);
				$name = $result["Customer_Name"];
				$email = $result["Customer_Email"];
				$contact= $result["Customer_Contact"];
				$age= $result["Customer_Age"];
				$gender= $result["Customer_Gender"];
				$filename = "img/customer/".$userID.".jpg";
							}	
		}else{
			$result =execSQL("SELECT * FROM hoteloperator WHERE HotelOperator_ID =".$userID.";");
			if($result){
				$result = mysqli_fetch_array($result);
				$name = $result["HotelOperator_Name"];
				$email = $result["HotelOperator_Email"];
				$contact= $result["HotelOperator_Contact"];
				$age= $result["HotelOperator_Age"];
				$gender= $result["HotelOperator_Gender"];
				$filename = "img/hotelOperator/".$userID.".jpg";
			}
			
		}
		if(!file_exists($filename)){
			$filename = "img/user.jpg";	
		}
		




	?>
<script type="text/JavaScript" src="js/previewImg.js"></script>

</head>

<body>
<div class="profile">
	<h2>Edit Profile</h2>
	<?php 
		if (isset($_GET['error'])) {
			echo "<p class='error'>".$_GET['error']."</p>";
		}
		if (isset($_GET['log'])) {
			echo "<p class='log'>".$_GET['log']."</p>";
		}
	?>	
	<form action="ManageProfile.php" method="POST" enctype = "multipart/form-data">
			<table class= "profileTable">	
				<?php
					echo "<tr><td colspan='2'><img id='UploadImg' src='".$filename."' alt='".$name."' /></td></tr>";
					echo "<tr><td colspan='2'><input id='UploadFile' type='file' name ='newImage' accept='image/png, image/jpeg' onchange='PreviewImage();'/></td></tr>";
				?>

            <!--Email-->
            <tr><td>
                <label>Email: </label>
				</td><td>
			<?php
				echo "<input id='email' type='email' value='$email' name='email' disabled/>"
            ?>
			</td></tr>
			<tr><td>
                <label>Name: </label>
				</td><td>
				<?php			
					echo "<input id='name' type='text' value='$name' name='name'/>"
				?>
			</td></tr>


            <!--Contact-->
            <tr><td>
                <label>Contact: </label>
				</td><td>
				<?php
					echo "<input id='contact' type='text' value='$contact' name='contact' />"
				?>
            </td></tr>

            <!--Age-->
            <tr><td>
                <label>Age: </label>
				</td><td>
				<?php
					echo "<input id='age' type='text' name='age' value='$age' />"
				?>
			</td></tr>

            <!--Gender-->
			<tr><td>
                <label>Gender: </label>
				</td><td>
				<?php
					$genderlist=['M','F'];
					$genderName=['Male','Female'];
					for($i=0;$i<2; $i++){
						if($genderlist[$i] == $gender)
							echo "<input type='radio' name='gender' value='".$genderlist[$i]."' checked/>"; 
						else
							echo "<input type='radio' name='gender' value='".$genderlist[$i]."'/>";
							
						echo "<label id='gender'>".$genderName[$i]."</label>";
					}
					
				?>
            </td></tr>
            <!-- value is box's name -->
			<tr id="saveRow"><td colspan='2'>
				<input id='submitBtn' type="submit" value="Save Changes" />
			</td></tr>
	</table>
	</form>
</div>
</body>
<?php include 'home_footer.php' ?>

</html>