

<html>
<head>
<title>Room Details</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/clear.css" rel="stylesheet">
<link href="css/RoomDetails.css" rel="stylesheet">
<?php
include 'home_header.php';
if($_SESSION['user_type'] == "HO")
{
	header("Location: home.php");
}

if(isset($_GET["checkI"]) || isset($_GET["checkO"])) 
{
	if(is_null($_GET["checkI"]))
	{
		$_SESSION['checkin'] = $_GET["checkO"];
		$_SESSION['checkout'] = $_GET["checkO"];
	}
	else if(is_null($_GET["checkO"]))
	{
		$_SESSION['checkin'] = $_GET["checkI"];
		$_SESSION['checkout'] = $_GET["checkI"];
	}
	else
	{
		if($_GET["checkI"] > $_GET["checkO"])
		{
			$_SESSION['checkin'] = $_GET["checkO"];
			$_SESSION['checkout'] = $_GET["checkI"];
		}
		else
		{
			$_SESSION['checkin'] = $_GET["checkI"];
			$_SESSION['checkout'] = $_GET["checkO"];
		}
	}
	header("location:RoomDetails.php?Room_ID=".$_GET["Room_ID"]);
}


if(isset($_GET["Room_ID"])){
	$_SESSION["Room_ID"]=$_GET["Room_ID"];
}

if(isset($_SESSION['checkin']) && isset($_SESSION['checkout'])){
	
	$checkin=$_SESSION['checkin'];
	$checkout=$_SESSION['checkout'];
}else{
	
	$checkin="";
	$checkout="";
	
	
}
if(isset($_SESSION['checkin']) && isset($_SESSION['checkout'])){
	
	$checkin=$_SESSION['checkin'];
	$checkout=$_SESSION['checkout'];
}else{
	
	$checkin="";
	$checkout="";
	
	
}



//Execute SQL
$result =execSQL("SELECT * FROM room WHERE Room_ID =".$_SESSION["Room_ID"].";");
if($result){
	$result = mysqli_fetch_array($result);
	$name = $result["Room_Name"];
	$roomType= $result["Room_Type"];
	$numBed= $result["Num_Bed"];
	$bedSize= $result["Bed_Size"];
	$price= $result["Price_Per_Day"];
	$numRoom= $result["Num_Rooms"];
	$filename = "img/Room/".$_SESSION["Room_ID"].".jpg";
	// echo $filename;
	if((!(empty($checkin))) && (!(empty($checkout)))){
		$sql = "SELECT room.Room_ID,
				(room.Num_Rooms*Num_Bed) - IFNULL(SUM((Num_Bed*reservation.Num_Rooms)),0) as Num_Guest, 
				room.Num_Rooms as total_room,
				room.Num_Rooms - IFNULL(SUM(reservation.Num_Rooms),0) as num_room_available
				FROM (room
				LEFT OUTER JOIN (reservation
				INNER JOIN date on reservation.Date_ID = date.Date_ID
				AND ((cast(Check_In_Date as date) Between '".$_SESSION['checkin']."' and '".$_SESSION['checkout']."')
				or (cast(Check_Out_Date as date) Between '".$_SESSION['checkin']."' and '".$_SESSION['checkout']."')))  on room.Room_ID = reservation.Room_ID
				)
				Where room.Room_ID = '".$_SESSION["Room_ID"]."'
				GROUP BY room.Room_ID;";
		if($result = execSQL($sql)){
			$result = mysqli_fetch_array($result);
			$numRoom = $result['num_room_available'];
			
		}else{
			echo "Error";
		}
	}
	$disabled = ($numRoom > 0) ? "" :"disabled='disabled'" ;

	
}
else{
	die("ERROR : ROOM_ID is undefined");
}
$SizeName= array( "XL" => "Extra Large" , "L" => "Large", "S" => "Small");  

?>
<script src="js/jquery-3.5.1.js"></script>
<script type="text/JavaScript">
var isError=false;
function addCartItem(){
	var checkinVal=document.getElementsByName("newcheckin")[0].value;
	var checkoutVal=document.getElementsByName("newcheckout")[0].value;
	
	if ((checkinVal)&&(checkoutVal)){
	
		$.ajax({
			type: "GET",
			url: "CartSession.php",
			data: {checkin: checkinVal, 
				checkout: checkoutVal}
		});
		var obj = document.getElementsByClassName('cartNum');
		var numCart = obj[0].innerText;
		numCart ++;
		obj[0].innerText = numCart;
		var err = document.getElementsByClassName('error');
		err[0].innerHTML = "";
	}else{
		if(!(isError)){
			showError();
			isError= true;
		}
		
	}
	
}

function refreshNumRoom()
{
	var checkinVal=document.getElementsByName("newcheckin")[0].value;
	var checkoutVal=document.getElementsByName("newcheckout")[0].value;
	location.replace("RoomDetails.php?Room_ID=<?php echo $_GET["Room_ID"];?>&checkI="+checkinVal + "&checkO=" +checkoutVal);
}
</script>

</head>
<body>
<div class="Room">
	<div class="Name">
		<?php
			echo "<h2>".$name."</h2>" ;
			
		?>
	</div>
	<div class= "Image">
		<?php
			echo "<img id='roomImg' src='".$filename."' alt='".$name."' />";
			
		?>
	</div>
	<div class = "Details">
	<h3> Room Details </h3>
	<table>
		<?php
			echo "<tr><td id='colLabel'>Number of Beds :</td><td>".$numBed."</td></tr>";
			echo "<tr><td id='colLabel'>Room Type : </td><td>".$SizeName[$roomType]."</td></tr>";
			echo "<tr><td id='colLabel'>Bed Size : </td><td>".$SizeName[$bedSize]."</td></tr>";
			echo "<tr><td id='colLabel'>Price Per Day : </td><td>".$price."</td></tr>";
			echo "<tr><td id='colLabel'>Number of Available Room : </td><td>".$numRoom."</td></tr>";
		?>
	</table>
	</div>
	<div class ="DateSelector">
	<h3> Choose Your Date</h3>
	<label>Check In : </label>
	<input type="date" name="newcheckin" min="<?php echo date("Y-m-d");?>" value="<?php echo $checkin;?>"  onchange = "refreshNumRoom()">
	<label>Check Out : </label>
	<input type="date" name="newcheckout" min="<?php echo date("Y-m-d"); ?>" value="<?php echo $checkout;?>" onchange = "refreshNumRoom()">

	
	</div>
	<div class="error">
		<script>
			function showError(){
				var p = document.createElement("P");
				p.innerHTML = 'Date is required';
				document.getElementsByClassName("error")[0].appendChild(p);
			}
		
		</script>
	
	</div>
	
	
	<div class= "cart">
	
		<input id="addCart" type="button" value="Add To Cart Now" onclick="addCartItem();" <?php echo $disabled;?>/>
		<input id="cancelBtn" type="button" value="Back" onclick=""/>
	
	</div>

</div>




</body>

<?php include 'home_footer.php'?>
</html>