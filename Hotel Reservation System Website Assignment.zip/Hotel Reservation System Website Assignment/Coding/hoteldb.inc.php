<?php
	define("DB_HOST","localhost");
	define("DB_USER","root");
	define("DB_PASS","");
	define("DB_NAME","hotelgo_db");
	
	function connect_db(){
		global $connection;
		$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
		if(!$connection)
			die(mysqli_connect_error());
		//else
			//echo "Connected";
	}
	
	function execSQL($query){
		
		connect_db();
		global $connection;
		if($result = mysqli_query($connection, $query))
			return $result;
		else
			return FALSE;
		
	}
?>