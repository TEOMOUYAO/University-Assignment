<?php
	include 'home_header.php';
   require_once 'hoteldb.inc.php';
   $roomName = $_POST['roomName'];
   // echo $roomName;
   $numBed = $_POST['numBed'];
   $roomType = $_POST['roomType'];
   $bedSize = $_POST['bedSize'];
   $price = $_POST['price'];
   $numRoom = $_POST['numRoom'];
   if (empty($roomName)) 
   {
	   if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?error=Room Name is required&addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?error=Room Name is required&Room_ID=".$_POST["Room_ID"]);
		exit();
	} else if (empty($numBed)) 
	{ 
		if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?error=Number of Bed is required&addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?error=Number of Bed is required&Room_ID=".$_POST["Room_ID"]);
		exit();
	}else if (empty($roomType)) 
	{ 
		if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?error=Room Type is required&addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?error=Room Type is required&Room_ID=".$_POST["Room_ID"]);
		exit();
	} else if (empty($bedSize)) 
	{
		if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?error=Bed Size is required&addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?error=Bed Size is required&Room_ID=".$_POST["Room_ID"]);
		exit();
	} else if (empty($price)) 
	{
		if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?error=Price Per Day is required&addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?error=Price Per Day is required&Room_ID=".$_POST["Room_ID"]);
		exit();
	}else if (empty($numRoom)) 
	{
		if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?error=Number of Available Room is required&addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?error=Number of Available Room is required&Room_ID=".$_POST["Room_ID"]);
		exit();
	}
   if(isset($_POST['create']))
   {
	   $sql = "INSERT into room(Room_Name,Room_Type,Num_Bed,Bed_Size,Price_Per_Day,Num_Rooms,Hotel_ID)
	   VALUES ('$roomName','$roomType','$numBed','$bedSize','$price','$numRoom','".$_SESSION["user_id"]."' ) ;";
   }
   else
   {
	   $sql = "UPDATE room 
		SET Room_Name='".$roomName."', 
			Room_Type='".$roomType."',
			Num_Bed='".$numBed."', 
			Bed_Size='".$bedSize."', 
			Price_Per_Day='".$price."',
			Num_Rooms='".$numRoom."'
		WHERE Room_ID ='".$_POST["Room_ID"]."';";
   }
   
   
   if(execSQL($sql))
   {
	   if($_FILES['newImage']['size'])
	   {
		  $errors= array();
		  $file_size = $_FILES['newImage']['size'];
		  $file_tmp = $_FILES['newImage']['tmp_name'];
		  $file_type = $_FILES['newImage']['type'];
		  $fileToken=explode('.',$_FILES['newImage']['name']);
		  $file_ext=strtolower($fileToken[1]);
		  
		  if(isset($_POST['create']))
		  {
			  $sql = "SELECT Room_ID from room where Hotel_ID=".$_SESSION["user_id"]." ORDER BY Room_ID DESC LIMIT 1 ;";
			  $result = execSQL($sql);
			  $row = $result->fetch_assoc();
			  $file_name =  $row["Room_ID"].".".$file_ext;
		  }
		  else
		  {
			  $file_name = $_POST["Room_ID"].".".$file_ext;
		  }
		  
		  $extensions= array("jpeg","jpg","png");
		  
		  if(in_array($file_ext,$extensions)=== false){
			 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
		  }
		  
		  // if($file_size > 2097152) {
			 // $errors[]='File size must be excately 2 MB';
		  // }
		  
		  if(empty($errors)==true) {
			 move_uploaded_file($file_tmp,"img/Room/".$file_name);
			 echo "Success";
		  }else{
			 print_r($errors);
		  }
	   }
		echo "Redirect to ManageHotel page";
		header("Refresh:0; url=ManageHotel.php");
   }
   else{
		echo "Failed";
		$_SESSION["Errors"]="Failed to Update Database";
		echo "<br>".$sql;
		if(isset($_POST['create']))
			header("Refresh:0; url=ManageRoom.php?addroom=1");
		else
			header("Refresh:0; url=ManageRoom.php?Room_ID=".$_POST["Room_ID"]);
   }
   
   
   
   
   
?>