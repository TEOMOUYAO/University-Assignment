<html>

<head>
	<link href="css/HotelDetails.css" rel="stylesheet">
<title>Hotel Detail</title>
<link rel="icon" href="img/hotel go logo.png">


<?php
include 'home_header.php';
if($_SESSION['user_type'] == "HO")
{
	header("Location: home.php");
}

if(isset($_GET['hotelid'])){
	$hotelid = $_GET['hotelid'];

	// Get Hotel name 
	$sql = "SELECT * from hotel where hotel_id = '$hotelid'";
	$result =execSQL($sql);
	if($result){
		$result = mysqli_fetch_array($result);
		$hotel_name = $result["Hotel_Name"];
		$hotel_location = $result["Hotel_Location"];
		$hotel_address = $result["Hotel_Address"];
		$hotel_contact =  $result["Hotel_Contact"];
		$hotel_description = nl2br($result["Hotel_Description"]);
		$hotel_pic = "img/hotel/".$hotelid.".jpg";
	}

	// Get room
	$roomList = [];

	$i=0;
	$sql = "SELECT * from room where hotel_id ='$hotelid'";
	$result = execSQL($sql);
	if($result){
		while($row = mysqli_fetch_row($result)){
			$roomID = $row[0];
			$roomName = $row[1];
			$numBed = $row[3];
			$price = $row[5];
			$room_pic= "img/Room/".$roomID.".jpg";	
			$RoomValues= [ "name" => $roomName,
			"numBed" => $numBed,"price" => $price, "filename" => $room_pic];
			$roomList[$roomID]=$RoomValues; 
		}
	}
	
	$feedbackList=[];
	$sql = "SELECT * from feedback where Hotel_ID ='$hotelid'";
	$result = execSQL($sql);
	if($result){
		while($row = mysqli_fetch_row($result)){
			$feedbackID =$row[0];
			$description = $row[1];
			$rating = $row[2];
			$customerID = $row[3];
			$sql="Select Customer_Name from customer where Customer_ID ='$customerID';";
			if($result2 = execSQL($sql)){
				$result2 = mysqli_fetch_array($result2);
				$customerName= $result2['Customer_Name'];
			}else{
				$customerName= "Unknown";
			}
			$profPic= "img/customer/".$customerID.".jpg";
			if(!file_exists($profPic)){
				$profPic = "img/user.jpg";	
			}			
			$feedbackValues= [ "description" => $description,
			"rating" => $rating,"name" => $customerName, "filename" => $profPic];
			$feedbackList[$feedbackID]=$feedbackValues; 
		}
	}


}
?>

</head>
<body>
<div class="hotel">
	<div class="Name">
		<?php
			echo "<h2>".$hotel_name."</h2>" ;
			
		?>
	</div>
	<div class= "Image">
		<?php
			echo "<img id='hotelImg' src='".$hotel_pic."' alt='".$hotel_name."' />";
			
		?>
	</div>
	<div class = "Details">
	<h3> Hotel Details </h3>
	
		<?php
			echo "<h4>Description</h4><div id='description'><label id='description'>".$hotel_description."</label></div>";
			echo "<h4>Location</h4><value>".$hotel_location."</value>";
			echo "<h4>Address</h4><value>".$hotel_address."</value>";
			echo "<h4>Contact Number</h4><value>".$hotel_contact."</value>"
		?>
	<h3> Available Rooms </h3>
	</div>

<table class= "roomTable">
	<?php
		foreach($roomList as $key => $value){
			echo "<tr><td><img id='roomImg' src='".$value['filename']."' alt='Room".$key."'/></td>";
			echo "<td><table id='valueTable'>
			<tr><td><label>Room Name</label>
				<name>".$value['name']."</name>
			</td></tr>
			<tr><td><label>Number of Beds</label>
			<numBed>".$value['numBed']."</numBed>
			</td></tr>
			<tr><td><label>Price per Day</label>
			<price>RM ".$value['price']."</price>
			</td></tr>
			<tr><td><form action='RoomDetails.php' method='get'>
			<button name='Room_ID' id='viewRoom' type='submit' value='".$key."' 
					/>View Room Details</button></form></td>
			</td></form></tr>					
			</table></td></tr>";
		}
	?>
</table>
<br/>
<br/>
<div class="feedbacks">
	<h3> Feedbacks </h3>
	<table>
		<?php
			foreach($feedbackList as $key => $value){
				
				echo "<tr><td id='col1'>
					<img id ='profImg' src='".$value['filename']."' alt='".$value['filename']."'/>
					</td><td id='col2'>
					<name>".$value['name']."</name><rlabel>Rating :</rlabel>";
				for($i =0; $i< 5; $i++){
					if( $i < $value['rating']){
						echo "<img id='star' src='img/star.png' alt=star/>";
					}else{
						echo "<img id='star' src='img/greystar.png' alt=star/>";
					}
				}	
				echo "<rating>(".$value['rating'].")</rating></td><td><des>".$value['description']."</des></td></tr>";
			}
		
		
		?>
	</table>
	
</div>

<br/>
<br/>


</div>

</body>




<?php include 'home_footer.php' ?>

</html>