<html>
<head>
<title>Booked Rooms</title>
<link href="css/clear.css" rel="stylesheet">
<link href="css/bookedRoom.css" rel="stylesheet">

</head>


<?php
 
include 'home_header.php';

if(isset($_POST['rating']) && isset($_POST['description']) && isset($_GET['hotelID'])){
	$sql= "INSERT INTO feedback(Feedback_Description,Rating_Points,Customer_ID,Hotel_ID)
			VALUES ('".$_POST['description']."',".$_POST['rating'].",".$_SESSION['user_id'].","
			.$_GET['hotelID'].") ON DUPLICATE KEY UPDATE    
			Feedback_Description='".$_POST['description']."', Rating_Points=".$_POST['rating'].";";
	if($result=execSQL($sql)){
		$log= "Feedback added Successfully";
	}else{
		$error="Failed to add feedback";
	}
}
$sql="alter table feedback auto_increment=0;";
execSQL($sql);

$reservation=[];
$userID=$_SESSION['user_id'];
$sql = "Select * from reservation where Customer_ID='".$userID."';";
if($result = execSQL($sql)){
	while($row = mysqli_fetch_row($result)){
		array_push($reservation,[$row[1],$row[2],$row[3]]);
		// Room_ID, Date_ID, Num_Rooms
	}	
}

if(isset($_GET['removeID'])){
	$remove=explode(",",$_GET['removeID']);
	if(!(array_search($remove,$reservation) === FALSE)){
		$removeRow = $reservation[array_search($remove,$reservation)];
		$roomID = $removeRow[0];
		$dateID = $removeRow[1];
		unset($reservation[array_search($removeRow,$reservation)]);
		$sql = "Delete From reservation where Customer_ID='$userID' AND Room_ID='$roomID' AND Date_ID='$dateID';";
		execSQL($sql);
		$log = "Selected Booked Room is cancelled Successfully";
	
	}	
	$_GET= array();
}
$bookList=[];
if(!(empty($reservation))){
	foreach($reservation as $value){
		$roomID=$value[0];
		$dateID=$value[1];
		$numRooms=$value[2];
		//Get Date from DB
		$sql="SELECT Check_In_Date, Check_Out_Date From date Where Date_ID ='$dateID'";
		if($result = execSQL($sql)){
			$result = mysqli_fetch_array($result);
			$checkInVal = $result['Check_In_Date'];
			$checkOutVal = $result['Check_Out_Date'];
		}
		//Get Room from DB
		$sql="SELECT Room_Name, Num_Bed, Hotel_ID From room Where Room_ID ='$roomID'";
		if($result = execSQL($sql)){
			$result = mysqli_fetch_array($result);
			$roomName = $result['Room_Name'];
			$numBed = $result['Num_Bed'];
			$hotelID = $result['Hotel_ID'];
		}
		$sql="SELECT Hotel_Name, Hotel_Address, Hotel_Contact From hotel Where Hotel_ID ='$hotelID'";
		if($result = execSQL($sql)){
			$result = mysqli_fetch_array($result);
			$hotelName = $result['Hotel_Name'];
			$address = $result['Hotel_Address'];
			$contact = $result['Hotel_Contact'];
		}
		$imgfile = "img/room/".$roomID.".jpg";
		$sql="SELECT Feedback_Description, Rating_Points from feedback where Customer_ID='$userID' and Hotel_ID='$hotelID';";
		if($result = execSQL($sql)){
			$result = mysqli_fetch_array($result);
			if(isset($result['Feedback_Description']) && isset($result['Rating_Points'])){
				$description = $result['Feedback_Description'];
				$rating = $result['Rating_Points'];
		}	else{
				$description=null;
				$rating = null;
			}
			
		}
		
		array_push($bookList,[ "hotelID" => $hotelID,
								"roomID" => $roomID,
								"dateID" => $dateID,
								"hotelName" => $hotelName,
								"address" => $address, 
								"roomName" => $roomName,
								"numBed" => $numBed,
								"numRoom" => $numRooms, 
								"checkIn" => $checkInVal,
								"checkOut" => $checkOutVal, 
								"contact" => $contact,
								"imgfile" => $imgfile,
								"fbDesc" => $description,
								"rating" => $rating]);	
		
	}
	
}else{
	$log="You Do Not Have Any Booked Room Yet";
}









?>

<script>
function updateStar(x){
	for( var i =1; i < 6; i++){
		var imgid = "star"+i;
		// alert(imgid);
		var imgStar= document.getElementById(imgid);
		if(i <= x){
			imgStar.src="img/star.png"; 
		}else{
			imgStar.src="img/greystar.png";
		}
	}
	
}


function showAddFB(){
	var textarea = document.getElementById("FeedbackRow");
	textarea.setAttribute("style","display: ;");
}

function adjustHeight(el){
    el.style.height = (el.scrollHeight > el.clientHeight) ? (el.scrollHeight)+"px" : "60px";
}
var a = document.getElementById("description");
adjustHeight(a);

</script>



<body>
<div class="bookedRoom">
<h2>Booked Room</h2>
<div class='list'>
<?php 

if (isset($log)) {
	echo "<p class='log'>".$log."</p>";
}
if (isset($error)) {
	echo "<p class='error'>".$error."</p>";
}
?>
<table class= "cartTable">
	<?php
		foreach($bookList as $value){
			echo "<tr><td><img id='roomImg' src='".$value['imgfile']."' alt='Room".$value['imgfile']."'/></td>";
			echo "<td><table id='valueTable'>
			<tr><td colspan='2'><label>Hotel Name</label>
				<name>".$value['hotelName']."</name>
			</td></tr>
			<tr><td colspan='2'><label>Address Name</label>
				<name>".$value['address']."</name>
			</td></tr>
			<tr><td colspan='2'><label>Room Name</label>
				<name>".$value['roomName']."</name>
			</td></tr>
			<tr><td colspan='2'><label>Number of Beds</label>
			<numBed>".$value['numBed']."</numBed>
			</td></tr>
			<tr><td colspan='2'><label>Number of Rooms Reserved</label>
			<numRoom>".$value['numRoom']."</numRoom>
			</td></tr>
			<tr><td colspan='2'><label>Check In Date & Time</label>
			<numRoom>".$value['checkIn']."</numRoom>
			</td></tr>
			<tr><td colspan='2'><label>Check Out Date & Time</label>
			<numRoom>".$value['checkOut']."</numRoom>
			</td></tr>
			<tr><td colspan='2'><label>Hotel Contact Number</label>
			<numRoom>".$value['contact']."</numRoom>
			</td></tr>";
			
			echo "<tr><td><form action='RoomDetails.php' method='get'>
			<button name='Room_ID' id='viewRoom' type='submit' value='".$value['roomID']."' 
			>View Room Details</button></form></td>";
			date_default_timezone_set("Asia/Kuala_Lumpur");
			$d1 = new DateTime();
			$d2 = new DateTime($value['checkOut']);
			
			if($d1 > $d2){
				
				echo"<td><form><button id='feedbackBtn' type='button' onclick='showAddFB()'
				>Give Feedback</button></form></td></tr></table></td></tr>";
				echo"<tr id='FeedbackRow' style='display: none;'><td colspan='2'>";
				
				if(isset($value['fbDesc'])){
					echo "<label>Edit Feedback</label>";
				}else{
					echo "<label>Add Feedback</label>";
				}
				echo "<form action='bookedRoom.php?hotelID=".$value['hotelID']."' method='POST'>";
				
				if(isset($value['fbDesc'])){
					echo "<textarea name='description' placeholder='Enter Your Feedback Here' 
					id='description' onchange='adjustHeight(this)'>".$value['fbDesc']."</textarea>";
				}else{
					echo "<textarea name='description' placeholder='Enter Your Feedback Here' 
					id='description' onchange='adjustHeight(this)'></textarea>";

				}
				for($i=1;$i<6;$i++){
					echo "<input id='star' type='radio' name='rating' value='$i' onclick='updateStar($i)'><img id='star$i' src='img/greystar.png'>";	
				}
				if(isset($value['rating'])){
					echo "<script>updateStar(".$value['rating'].");</script>";
				}
				echo"<input id='submitFB' type='submit' value='Send Feedback'/></form></td></tr>";
			}else{
				echo"<td><form action='bookedRoom.php' method='get'>
				<button name='removeID' id='remove' type='submit' value="
				.$value['roomID'].",".$value['dateID'].",".$value['numRoom']."
				/>Cancel Booking</button></form>
				</td></tr></table></td></tr>";
			}
			
			
		}
	?>
</table>


</div>



<br/><br/>
</div>




</body>
<?php include 'home_footer.php'?>
</html>