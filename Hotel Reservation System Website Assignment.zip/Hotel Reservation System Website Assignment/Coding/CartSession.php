<?php 
	if (session_status() == PHP_SESSION_NONE) {
	session_save_path('tmp');
    session_start();
}
	$_SESSION['checkin']=$_GET['checkin'];
	$_SESSION['checkout']=$_GET['checkout'];

	function appendItem(){
		array_push($_SESSION["numCart"],[$_SESSION["Room_ID"],$_GET['checkin'],$_GET['checkout']]);
		
	}
	appendItem();
?>