<link href="css/footer.css" rel="stylesheet">
<footer>
<ul class="nav-stacked">
              <li><a href="#">Privacy</a></li>
              <li><a href="#">Terms and Conditions</a></li>
			  <li><a href="#"><img src="img/mail.png" alt="Email this to someone" id="sociallogo"/></a></li>
				<li><a href="#"><img src="img/sharing.png" alt="Syndicated content" id="sociallogo"/></a></li>
				<li><a href="#"><img src="img/help.png" alt="Get help" id="sociallogo"/></a></li>
</ul> 
</footer>