<html>
<title>Setting</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/clear.css" rel="stylesheet">
<link href="css/setting.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<?php

include 'home_header.php';

if(isset($_POST['currPass']) && isset($_POST['newPass']) && isset($_POST['confirmPass'])){
	$userid = $_SESSION['user_id'];
	$acc_type = $_SESSION['user_type'];
	if(empty($_POST['currPass'])){
		header("Location: setting.php?error=Current Password is required");
		exit();
	}
	else if(empty($_POST['newPass'])){
		header("Location: setting.php?error=New Password is required");
		exit();
	}
	else if(empty($_POST['confirmPass'])){
		header("Location: setting.php?error=New Password Confirmation is required");
	}
	
	if ($acc_type=="Customer"){
		$sql="select Customer_Password from customer where Customer_ID='$userid'";
		$result=execSQL($sql);
		$result = mysqli_fetch_array($result);
		if($result["Customer_Password"] != $_POST['currPass']){
			header("Location: setting.php?error=Current Password is Invalid");
			exit();
		}		
	}else if ($acc_type=="HO"){
		$sql="select HotelOperator_Password from HotelOperator where HotelOperator_ID='$userid'";
		$result=execSQL($sql);
		$result = mysqli_fetch_array($result);
		if($result["HotelOperator_Password"] != $_POST['currPass']){
			header("Location: setting.php?error=Current Password is Invalid");
			exit();
		}	
	}
	if($_POST['newPass']!=$_POST['confirmPass']){
		header("Location: setting.php?error=Password and Password Confirmation are not the same");
		exit();
		
	}else if((strlen($_POST['newPass'])<8) or (!preg_match("#[0-9]+#", $_POST['newPass'])) or (!preg_match("#[a-z]+#", $_POST['newPass'])) or (!preg_match("#[A-Z]+#", $_POST['newPass'])) or (!preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $_POST['newPass']))){
		header("Location: setting.php?error=Password: at least 8 char(include 1 digit, LC and UC letter, special char)");
		exit();
		
	}else{
			$newPass=$_POST['newPass'];
			if ($acc_type=="Customer"){
			$sql="Update customer Set Customer_Password='$newPass' where Customer_ID = '$userid'";
			execSQL($sql);
			}else if ($acc_type=="HO"){
			$sql="Update hoteloperator Set HotelOperator_Password='$newPass' where HotelOperator_ID = '$userid'";
			execSQL($sql);
			}
			header("Location: setting.php?log=New Password Updated Successfully");

	}
	
}





?>
<body>

<div class="setting">
<?php 
if (isset($_GET['error'])) {
	echo "<p class='error'>".$_GET['error']."</p>";
}
if (isset($_GET['log'])) {
	echo "<p class='log'>".$_GET['log']."</p>";
}
?>
<h2>Setting</h2>

<h3>Change Account Password</h3>

<form action="setting.php" method="POST" >
 


<!--Current Password-->
<table class="passTable">
	<tr><td id="leftCol">
	<label>Current Password: </label>
	</td>
	<td>
	<input id="pass1" type="password" name="currPass" size="50"/>
	<span>
	<i id="eye1" class="fa fa-eye" aria-hidden="true" onclick="toggle1()"></i>
	</span>
	</td>
	<tr>
	<script>
		document.getElementById("eye1").style.color = "silver";
		var click1 = true;
		function toggle1(){
			if (click1){
				document.getElementById("pass1").setAttribute("type", "text");
				document.getElementById("eye1").style.color = "blue";
				click1 = false;
			}
			else{
				document.getElementById("pass1").setAttribute("type", "password");
				document.getElementById("eye1").style.color = "silver";
				click1 = true;
			}
		}
	</script>


	<!--New Password-->
	<tr><td id="leftCol">
		<label>New Password: </label>
		</td>
		<td>
		<input id="pass2" type="password" name="newPass" size="50" />
		<span>
			<i id="eye2" class="fa fa-eye" aria-hidden="true" onclick="toggle2()"></i>
		</span>
		</td>
	</tr>
	<script>
		document.getElementById("eye2").style.color = "silver";

		var click2 = true;
		function toggle2() {
			if (click2) {
				document.getElementById("pass2").setAttribute("type", "text");
				document.getElementById("eye2").style.color = "blue";
				click2 = false;
			}
			else {
				document.getElementById("pass2").setAttribute("type", "password");
				document.getElementById("eye2").style.color = "silver";
				click2 = true;
			}
		}
	</script>

	<!--Confirm Password-->
	<tr><td id="leftCol">
		<label>Confirm New Password: </label>
		</td>
		<td>
		<input id="pass3" type="password" name="confirmPass" size="50" />
		<span>
			<i id="eye3" class="fa fa-eye" aria-hidden="true" onclick="toggle3()"></i>
		</span>
		</td>
	</tr>
		<script>
			document.getElementById("eye3").style.color = "silver";

			var click3 = true;
			function toggle3() {
				if (click3) {
					document.getElementById("pass3").setAttribute("type", "text");
					document.getElementById("eye3").style.color = "blue";
					click3 = false;
				}
				else {
					document.getElementById("pass3").setAttribute("type", "password");
					document.getElementById("eye3").style.color = "silver";
					click3 = true;
				}
			}
		</script>        
		
		
	<tr>
	<td colspan="2">	
	<input id="submitBtn" type="submit" value="Save Changes"/>
	</td>
	</tr>
	</form>
</table>
<br/><br/><br/><br/><br/>
</div>
</body>
<?php include 'home_footer.php'?>



</html>