<html>

<head>
<title>Manage Hotel</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/ManageHotel.css" rel="stylesheet">
<script type="text/JavaScript" src="js/previewImg.js"></script>


<?php
include 'home_header.php';
	if(isset($_GET['deletenum']))
	{
		$sql = "
		DELETE room.* ,reservation.* ,date.*
		FROM(( room
		LEFT JOIN reservation ON room.Room_ID=reservation.Room_ID)
		LEFT JOIN date ON reservation.Date_ID = date.Date_ID)
		WHERE room.Room_ID=".$_GET['deletenum'].";
		";
		$result =execSQL($sql);
		header("location:ManageHotel.php");
	}

	// Get Hotel name 
	$sql = "SELECT Hotel_ID, Hotel_Name, Hotel_Location, Hotel_Address, Hotel_Contact,Hotel_Description
	from (hoteloperator 
	Left JOIN hotel ON hoteloperator.HotelOperator_ID = hotel.HotelOperator_ID)
	WHERE hoteloperator.HotelOperator_ID = ".$_SESSION['user_id'].";";
	$result =execSQL($sql);
	$row=null;
	if($result){
		$row = $result->fetch_assoc();
		$hotel_id=$row["Hotel_ID"];
		$hotel_name = $row["Hotel_Name"];
		$hotel_location = $row["Hotel_Location"];
		$hotel_address = $row["Hotel_Address"];
		$hotel_contact =  $row["Hotel_Contact"];
		$hotel_description = ($row["Hotel_Description"]);
		$hotel_pic = "img/hotel/".$row["Hotel_ID"].".jpg";
	}

	if(isset($_POST['submit']))
	{
		$temp_hotel_name = addslashes($_POST["hotel_name"]);
		$temp_description = addslashes($_POST["description"]);
		$temp_location = addslashes($_POST["location"]);
		$temp_address = addslashes($_POST["address"]);
		$temp_contact = addslashes($_POST["contact"]);
		
		$sql = "UPDATE hotel 
				SET Hotel_Name='$temp_hotel_name'	, 
					Hotel_Description='$temp_description'	, 
					Hotel_Location='$temp_location'	, 
					Hotel_Address='$temp_address'		, 
					Hotel_Contact='$temp_contact'
				WHERE Hotel_ID = $hotel_id ;
				";
		$test = execSQL($sql);	
		if(isset($_FILES['newImage']) && $_FILES['newImage']['error'] != UPLOAD_ERR_NO_FILE)
		{
			$temp = explode(".", $_FILES["newImage"]["name"]);
			$newfilename = "img/hotel/" .$hotel_id. "." . end($temp);
			if(file_exists($newfilename)) {
				chmod($newfilename,0755); //Change the file permissions if allowed
				unlink($newfilename); //remove the file
			}
			move_uploaded_file($_FILES["newImage"]["tmp_name"],  $newfilename);
		}
		
		header("location:ManageHotel.php");
	}
	
	
	
	// Get room
	$roomList = [];

	$i=0;
	$sql = "SELECT * from room where hotel_id =".$row["Hotel_ID"]." ";
	$result = execSQL($sql);
	if($result){
		while($row = mysqli_fetch_row($result)){
			$roomID = $row[0];
			$roomName = $row[1];
			$numBed = $row[3];
			$price = $row[5];
			$numRoom = $row[6];
			$room_pic= "img/Room/".$roomID.".jpg";	
			$RoomValues= [ "name" => $roomName,
			"numBed" => $numBed,"price" => $price, "filename" => $room_pic, "numRoom" => $numRoom];
			$roomList[$roomID]=$RoomValues; 
		}
	}
?>

</head>
<body>
<div class="hotel">
<form action='ManageHotel.php' method='post' enctype="multipart/form-data">
	<div class="Name">
		<?php
			echo "<label>Hotel name</label>";
			echo "<input type='text' name='hotel_name' value='".$hotel_name."'  class='hotelname' />" ;
			
		?>
	</div>
	<div class= "Image">
		<?php
			echo "<img id='UploadImg' src='".$hotel_pic."' alt='".$hotel_name."' /><br>";
			echo "<input id='UploadFile' type='file' name='newImage' accept='image/png, image/jpeg' onchange='PreviewImage();'></input>"
			
		?>
	</div>
	<div class = "Details">
	<h3> Hotel Details </h3>
	
		<?php
			echo "<h4>Description</h4>
			<textarea name='description' id='description' onchange='adjustHeight(this)'>"
			.$hotel_description.
			"</textarea>";
			echo "<h4>Location</h4>
			<input type='text' name='location' value='".$hotel_location."' />";
			echo "<h4>Address</h4>
			<input type='text' name='address' value='".$hotel_address."' />";
			echo "<h4>Contact Number</h4>
			<input type='text' name='contact' value='".$hotel_contact."' />";
		?>
	<button type='submit' name="submit" value="Submit">Save Changes of Hotel</button> <button type='reset'><a href="ManageHotel.php">Cancel</a></button>
</form>


	<h3> Available Rooms </h3>
	</div>
<table class= "roomTable">
	<tr><td colspan="2" class="twocolumn"> 
	<a href="ManageRoom.php?addroom=1"><button class="addRoom">Add Room</button> </a>
	</td></tr>
	<?php
		foreach($roomList as $key => $value){
			echo "<tr><td><img id='roomImg' src='".$value['filename']."' alt='Room".$key."'/></td>";
			echo "<td id='valueTable'>
			<label>Room Name</label><br>
			<name>".$value['name']."</name><br>
			<label>Number of Rooms</label><br>
			<numRoom>".$value['numRoom']."</numRoom><br>
			<label>Number of Beds</label><br>
			<numBed>".$value['numBed']."</numBed><br>
			<label>Price per Day</label><br>
			<price>RM ".$value['price']."</price><br>
			<a href='ManageRoom.php?Room_ID=".$key."'>
			<button name='Room_ID' id='viewRoom'/>Change Room Details</button></a>
			<a href='ManageHotel.php?deletenum=".$key."'
			 class='delete' data-confirm='Are you sure to delete this room?'><button name='delete' id='deletebutton'>&#10006</button></a>
			</td>
			</tr>";
		}
	?>
</table>

<br/>
<br/>


</div>

</body>

<script type="text/javascript">
function adjustHeight(el){
    el.style.height = (el.scrollHeight > el.clientHeight) ? (el.scrollHeight)+"px" : "60px";
}
var a = document.getElementById("description");
adjustHeight(a);
</script>
<script type="text/javascript">
var deleteLinks = document.querySelectorAll('.delete');

for (var i = 0; i < deleteLinks.length; i++) {
  deleteLinks[i].addEventListener('click', function(event) {
      event.preventDefault();

      var choice = confirm(this.getAttribute('data-confirm'));

      if (choice) {
        window.location.href = this.getAttribute('href');
      }
  });
}
</script>
<?php include 'home_footer.php' ?>

</html>