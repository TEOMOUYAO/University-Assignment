<?php 
include 'hoteldb.inc.php';
if (session_status() == PHP_SESSION_NONE) {
	session_save_path('tmp');
    session_start();
}

if(isset($_POST['email']) && isset($_POST['password'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	if(empty($email)){
		header("Location: signin.php?error=Email is required");
		exit();
	}
	else if(empty($password)){
		header("Location: signin.php?error=Password is required");
		exit();
	}
	else{
	$sql="select Customer_ID from customer where Customer_Email='".$email."'AND Customer_Password='".$password."' limit 1;";
	$sql2="select HotelOperator_ID from hoteloperator where HotelOperator_Email='".$email."'AND HotelOperator_Password='".$password."' limit 1;";
	$result=execSQL($sql);
	$result2=execSQL($sql2);
	if($result->num_rows > 0){
		$row = $result->fetch_object();
		$_SESSION['user_type']="Customer";
		$_SESSION['user_id']=$row->Customer_ID;
		//echo "<script type='text/javascript'>alert(".$_SESSION['Sign in success'].");</script>";
		header("Location: home.php");
		exit();
	}
	else if($result2->num_rows > 0)
	{
		$row = $result2->fetch_object();
		$_SESSION['user_type']="HO";
		$_SESSION['user_id']=$row->HotelOperator_ID;
		header("Location: home.php");
		exit();
		//echo "<script type='text/javascript'>alert('Sign in success');</script>";
	}
	else
	{
		#echo "Sign in fail";
		header("Location: signin.php?error=Incorrect Email or Password");
		exit();
	}}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign In</title>
	<link rel="icon" href="img/hotel go logo.png">
	<link href="css/signin.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
	<form action="" method="post">
	<?php if (isset($_GET['error'])) {?>
			<p class="error"><?php echo $_GET['error']; ?></p>
	<?php } ?>
	<?php if (isset($_GET['success'])) {?>
			<p class="success"><?php echo $_GET['success']; ?></p>
	<?php } ?>
	<div class="login_box">
		<h2>Sign In</h2>
		<div class="textbox">
			<input type="text" placeholder="Email" name="email">
		</div>
		
		
		<div class="textbox">
			<table>			
			<tr>
			<td>
			<input id="pass1" type="password" placeholder="Password" name="password">
			</td>
			<td>
			<i id="eye1" class="fa fa-eye" aria-hidden="true" onclick="toggle1()"></i>
			</td>
			</tr>
			</table>
			<script>
				document.getElementById("eye1").style.color = "silver";
				var click1 = true;
				function toggle1(){
					if (click1){
						document.getElementById("pass1").setAttribute("type", "text");
						document.getElementById("eye1").style.color = "#d6ed17";
						click1 = false;
					}
					else{
						document.getElementById("pass1").setAttribute("type", "password");
						document.getElementById("eye1").style.color = "silver";
						click1 = true;
					}
				}
			</script>
		</div>
		
		
		<input class="btn" type="submit" value="Sign In" >
		<h4>New User :</h4>
		<input class="btn" onclick="location.href='signup.php'" type="button" value="Sign Up" >
	</div>
	</form>

</body>
</html>