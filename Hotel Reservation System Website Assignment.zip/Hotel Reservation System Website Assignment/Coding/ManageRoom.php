<html>
<head>
<title>Manage Room</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/clear.css" rel="stylesheet">
<link href="css/ManageRoom.css" rel="stylesheet">
<?php
include 'home_header.php';

$name = null;
$roomType= null;
$numBed= null;
$bedSize= null;
$price= null;
$numRoom=null;
$filename = null;

if(isset($_GET["Room_ID"]))
{
	//Execute SQL
	$result =execSQL("SELECT * FROM room WHERE Room_ID =".$_GET["Room_ID"].";");
	if($result){
		$result = mysqli_fetch_array($result);
		$name = $result["Room_Name"];
		$roomType= $result["Room_Type"];
		$numBed= $result["Num_Bed"];
		$bedSize= $result["Bed_Size"];
		$price= $result["Price_Per_Day"];
		$numRoom= $result["Num_Rooms"];
		$filename = "img/Room/".$_GET["Room_ID"].".jpg";
		// echo $filename;
	}
	else{
		die("ERROR : ROOM_ID is undefined");
	}
}
$SizeRB=['XL','L','S'];
$SizeName= array( "XL" => "Extra Large" , "L" => "Large", "S" => "Small");  

?>
<script type="text/JavaScript" src="js/previewImg.js"></script>

</head>

<body>

<div class="Room">

	
	<h2> Manage Room Information </h2>
	<?php 
		if (isset($_GET['error'])) {
			echo "<p class='error'>".$_GET['error']."</p>";
		}
	?>
	<form action="saveRoom.php" name="save" method="post" enctype = "multipart/form-data">
		<?php 
		if(isset($_GET['addroom']))
		{
			echo "<input type='hidden' name='create' value='1' />"; 
		}
		else
		{
			echo "<input type='hidden' name='Room_ID' value='".$_GET['Room_ID']."' />";
		}
		?>
		
		<table class= "roomTable">
			<tr id="TitleName">
				<td colspan="2"><label>Room Name</label>
				<?php
					echo "<input type='text' name='roomName' value='".$name."'/>" ;
					
				?>
				</td>
			</tr>
			
			<tr id= "Image">
				<td colspan="2"><table>
				<tr><td><label> Room Photo </label></td></tr>
				
				<?php
					echo "<tr><td><img id='UploadImg' src='".$filename."' alt='".$name."' /></td></tr>";
					echo "<tr><td><input id='UploadFile' type='file' name ='newImage' accept='image/png, image/jpeg' onchange='PreviewImage();'/></td></tr>";
				?>
				</table>
				</td>
			</tr>
			
			<tr id = "Details">
			<td colspan="2"><label> Room Details </label></td>
			</tr>
			<tr id = "NumBed">
				<td colspan="2">
				<label> Number of Beds : </label>
				<?php
					echo "<input type='number' min='1' max='10' name='numBed' value='".$numBed."'/>";
				?>
				</td>
			</tr>
			<tr id= "RoomType">
				<td>
				<label> Room Type : </label>
				</td>
				<td>
				<table class="radio">
				<?php
					
					for($i=0;$i<3; $i++){
						if($SizeRB[$i] == $roomType)
							echo "<tr><td><input type='radio' name='roomType' value='".$SizeRB[$i]."' checked/>"; 
						else
							echo "<tr><td><input type='radio' name='roomType' value='".$SizeRB[$i]."'/>";
							
						echo "<label>".$SizeName[$SizeRB[$i]]."</label></td></tr>";
					}
					
				?>
				</table>
				</td>
			</tr>
			<tr id= "BedSize">
				<td>
				<label> Bed Size : </label>
				</td>
				<td>
				<table class="radio">
				<?php
					
					for($i=0;$i<3; $i++){
						if($SizeRB[$i] == $bedSize)
							echo "<tr><td><input type='radio' name='bedSize' value='".$SizeRB[$i]."' checked/>"; 
						else
							echo "<tr><td><input type='radio' name='bedSize' value='".$SizeRB[$i]."'/>";
							
						echo "<label>".$SizeName[$SizeRB[$i]]."</label></td></tr>";
					}
					
				?>
				</table>
				</td>
			</tr>
			<tr id = "Price">
				<td colspan="2">
				<label> Price Per Day : </label>
				<?php
					echo "<input type='number' name='price' value='".$price."' step='.01'/>" ;
					
				?>
				</td>
			
			</tr>
			<tr id = "NumRoom">
				<td colspan= '2'>
				<label> Number of Available Rooms : </label>
				
				<?php
					echo "<input type='number' name='numRoom' value='".$numRoom."'/>" ;
					
				?>
				</td>
			
			</tr>
			<tr id="formFooter">
				<td><button type="submit" class="btnSave">Save Changes</button></td>
				<td><a href="ManageHotel.php"><input type="button" value="Cancel" onclick="" /></a></td>
			
			</tr>

		</table>
	</form>
</div>

</body>
<?php include 'home_footer.php'?>

</html>