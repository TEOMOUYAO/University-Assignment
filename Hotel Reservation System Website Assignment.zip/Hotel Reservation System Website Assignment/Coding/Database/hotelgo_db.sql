-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2020 at 05:45 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotelgo_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(3) NOT NULL,
  `Customer_Name` varchar(100) NOT NULL,
  `Customer_Password` varchar(50) NOT NULL,
  `Customer_Email` varchar(30) NOT NULL,
  `Customer_Contact` varchar(12) NOT NULL,
  `Customer_Age` int(3) NOT NULL,
  `Customer_Gender` enum('M','F') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Customer_Name`, `Customer_Password`, `Customer_Email`, `Customer_Contact`, `Customer_Age`, `Customer_Gender`) VALUES
(1, 'admin', 'Admin123@', 'admin@gmail.com', '+60123456789', 22, 'M'),
(2, 'Ahmad Zikri', 'Ahmad123!', 'ahmad@hotmail.com', '+60179428836', 31, 'M'),
(3, 'Sabrina', 'Sabrina123!', 'Sabrina@yahoo.com', '+60169426537', 26, 'F'),
(4, 'Timothy Wong', 'Timothy123!', 'timothy@gmail.com', '+60144322833', 22, 'M'),
(5, 'Catherine Lee', 'Clee123!', 'Catherine@gmail.com', '+60135628845', 19, 'F'),
(6, 'Jenny BP', 'Jenny123!', 'jenny@gmail.com', '+60128567749', 18, 'F'),
(7, 'Tester', 'Happy123@', 'test@gmail.com', '+60127777777', 99, 'F');

-- --------------------------------------------------------

--
-- Table structure for table `date`
--

CREATE TABLE `date` (
  `Date_ID` int(3) NOT NULL,
  `Check_In_Date` datetime NOT NULL,
  `Check_Out_Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `date`
--

INSERT INTO `date` (`Date_ID`, `Check_In_Date`, `Check_Out_Date`) VALUES
(1, '2020-09-24 08:00:00', '2020-09-25 12:00:00'),
(2, '2020-09-29 08:00:00', '2020-09-30 12:00:00'),
(3, '2020-09-29 08:00:00', '2020-10-01 12:00:00'),
(8, '2020-09-29 08:00:00', '2020-10-02 12:00:00'),
(9, '2020-09-30 08:00:00', '2020-10-02 12:00:00'),
(5, '2020-09-30 08:00:00', '2020-10-03 12:00:00'),
(13, '2020-10-01 08:00:00', '2020-10-02 12:00:00'),
(7, '2020-10-01 08:00:00', '2020-10-03 12:00:00'),
(12, '2020-10-02 08:00:00', '2020-10-02 12:00:00'),
(11, '2020-10-02 08:00:00', '2020-10-03 12:00:00'),
(14, '2020-10-02 08:00:00', '2020-10-24 12:00:00'),
(17, '2020-10-05 08:00:00', '2020-10-06 12:00:00'),
(16, '2020-10-05 08:00:00', '2020-10-09 12:00:00'),
(19, '2020-10-06 08:00:00', '2020-10-10 12:00:00'),
(15, '2020-10-06 08:00:00', '2020-10-23 12:00:00'),
(18, '2020-10-07 08:00:00', '2020-10-08 12:00:00'),
(10, '2020-10-08 08:00:00', '2020-10-11 12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Feedback_ID` int(3) NOT NULL,
  `Feedback_Description` varchar(500) NOT NULL,
  `Rating_Points` int(1) NOT NULL,
  `Customer_ID` int(3) NOT NULL,
  `Hotel_ID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Feedback_ID`, `Feedback_Description`, `Rating_Points`, `Customer_ID`, `Hotel_ID`) VALUES
(2, 'I love this hotel style. So high class!!!', 5, 5, 1),
(3, 'Room Service is OK. Quite hard to find a taxi here.', 3, 2, 6),
(4, 'Room service is the best. Their breakfast was also very nice.', 5, 5, 2),
(5, 'The swimming pool is quite smaller than I expected. But other services are fine.', 4, 6, 3),
(6, 'The Mandarin Room is so deluxe and beautiful. But the price is a bit too expensive.', 4, 4, 2),
(7, 'The price is very affordable for King Size Room!!', 4, 3, 5),
(8, 'Overall is good, clean & stylish, host is friendly and very fast response', 4, 5, 4),
(9, 'Great place to stay, the house is sparkling clean & comfortable. Prompt response from host. Will definitely recommend to my frens.', 5, 1, 5),
(10, 'What a pleasant stay! My family & I love the place so much, clean and good location. We will definitely come back again', 5, 2, 3),
(11, 'Centrally located to all things. The staff is absolutely friendly.', 5, 3, 4),
(12, 'The spa facility staff are very friendly and help coordinate. Conceige very nice and helpful.', 3, 6, 6),
(13, 'Best hotel ever in my life!!! ', 5, 1, 1),
(14, 'Nothing much to say. Worth every penny. Best place to stay while visit malacca. Easy access. Thumbs up', 4, 2, 12),
(15, '1. Dirty bathroom\r\n2. Shower head missing\r\n3. Request for room service by room service button but nothing happened\r\n4. Parking not secured due to entry gate always open.', 1, 6, 12),
(16, 'Sea view and own private pool, ample space in the room. Beds are tidy and clean.', 4, 3, 10),
(17, 'Unsatisfied with the staff services', 2, 5, 10),
(18, 'Room was clean, really like the security imposed as the pool is inside the building. So i really feel the children are safe', 5, 4, 11),
(19, 'Did not like the towels. They are worn out already and have an unpleasant smell. The shower booth was difficult to drain due to the amount hair caught in the drainage area. Managed to clean in with the toothbrush provided then water flows properly.', 3, 5, 11),
(20, 'I loved the pool area and also the play pool , my daughter enjoyed it very much, the hotel is old but overall it was worth the stay', 4, 3, 9),
(21, 'I want to try any dishes from your restaurant but the menu you didnt display in our room.', 3, 2, 9),
(22, 'Cosy and serene environment.We even get an upgraded room for free since we booked during non peak season period.The room is unexpectedly bigger than we imagine.The cuisines at Rajawali Coffee House mix really well with our taste buds.The reception staff was also nice and the housekeeping staffs reflected instantly to our need.Tq Resorts World Awana for providing my family a pleasant holiday experience.', 5, 2, 8),
(23, 'Had to pay parking fee.The windows\'s holder are broken.', 2, 5, 8),
(24, 'Need to pay the parking ticket for 1 day cost tu myr 17 and above...', 3, 6, 8),
(25, 'The 1st room that i received was very dirty. Hair on the bed and toilet. Table also dirty with lizard dung. There is also a smell of rat.We request to change the room. They change it but not much different, still consider dirty.i hope they can improve on this so that can attract more crowd', 1, 3, 8),
(26, 'Aging facilities, leaking taps/shower, below par breakfast (limited served menu instead of buffet, not fresh)', 2, 4, 8),
(27, 'very OK and i enjoyed my holiday', 4, 2, 7),
(28, 'The room is too small', 3, 4, 7),
(29, 'Excellent location..great views..easy excesses to themes park..', 5, 3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `Hotel_ID` int(3) NOT NULL,
  `Hotel_Name` varchar(50) NOT NULL,
  `Hotel_Location` varchar(20) NOT NULL,
  `Hotel_Address` varchar(100) NOT NULL,
  `Hotel_Contact` varchar(12) NOT NULL,
  `Hotel_Description` text NOT NULL,
  `HotelOperator_ID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`Hotel_ID`, `Hotel_Name`, `Hotel_Location`, `Hotel_Address`, `Hotel_Contact`, `Hotel_Description`, `HotelOperator_ID`) VALUES
(1, 'Grand Hyatt Kuala Lumpur ', 'Kuala Lumpur', '12, Jalan Pinang, 50450 Kuala Lumpur, Malaysia', '+60321821234', 'The luxurious 5-star Grand Hyatt Kuala Lumpur is located just next to the Kuala Lumpur Convention Centre (KLCC). The hotel features an outdoor swimming pool and guests can enjoy meals at 3 in-house restaurants available or have a drink at the bar overlooking the Petronas Twin Towers. Free WiFi is available throughout the property.\r\n\r\nThrough floor-to-ceiling windows, views of the park and city can be enjoyed from the room. A coffee machine and 42-inch flat-screen TV are included. En suite bathrooms have a bathtub and 24-hour hot-water showers.\r\n\r\nIt is 400 m to Pavilion Shopping Mall and 500 m to Petronas Twin Towers. It is a 10-minute drive from the Malaysian Philharmonic Orchestra. Kuala Lumpur International Airport is 68.6 km away. Airport transfers can be arranged at an extra charge.\r\n\r\nDine at the hotel\'s signature restaurant, THIRTY8, which offers a selection of Chinese, Japanese and Western cuisines. JP teres features a cosy indoor dining area and a large outdoor terrace with an island bar surrounded by lush green landscape. A glasshouse by the swimming pool and features al fresco setting, Poolhouse offers all-day dining with serves local and international favourites.\r\n\r\nGuests can approach the 24-hour front desk for currency exchange, concierge services and luggage storage. To meet guests\' professional needs, the hotel has a business centre and fully equipped meeting rooms. A 24-hour fitness centre is available. Alternatively, guests can indulge in a variety of spa treatments at Essa Spa.\r\n\r\nMost popular facilities\r\n2 swimming pools, superb fitness centre, Non-smoking rooms, Spa and wellness centre, Room service, Bar Fabulous breakfast', 1),
(2, 'Mandarin Oriental', 'Kuala Lumpur', 'Kuala Lumpur City Centre, 50088 Kuala Lumpur, Malaysia', '+60323808888', 'Mandarin Oriental, Kuala Lumpur, features stylish suites and serviced apartments overlooking the city skyline and KLCC Park. The hotel offers an infinity outdoor pool with poolside cabanas and daybeds.\r\n\r\nMandarin Oriental is located between the iconic Petronas Twin Towers and the lush gardens of Kuala Lumpur City Park. The hotel is approximately 45 km from Kuala Lumpur International Airport.\r\n\r\nAll rooms are air-conditioned and equipped with luxurious marble bathrooms with toiletries and separate showers and bathtubs. The room is fitted with a Smart TV and a Bluetooth radio. Free WiFi is available in all rooms.\r\n\r\nOther facilities in the property include an indoor golf area, tennis courts and a fitness centre for guests to work out. Alternatively, guests can indulge in spa treatments at The Spa.\r\n\r\nGuests can enjoy a range of cuisines from 10 award-winning restaurants. Local and international fare are served at Mosaic Restaurant, while authentic Cantonese food is offered at Lai Po Heen Chinese Restaurant. Classic international dishes, fine selection of meats and premium wines are available at Mandarin Grill.\r\n\r\nThis is our guests\' favourite part of Kuala Lumpur, according to independent reviews.\r\n\r\nMost Popular Facilities\r\n2 swimming pools, superb fitness centre, Non-smoking rooms, Spa and wellness centre, Room service, Bar Fabulous breakfast', 2),
(3, 'The Ritz-Carlton', 'Kuala Lumpur', '168 Jalan Imbi, Bukit Bintang, 55100 Kuala Lumpur, Malaysia', '+60321428000', 'The Ritz-Carlton offers luxurious, elegant rooms and residences in Kuala Lumpur’s Golden Triangle District, a 5-minute walk from Pavilion Mall. It features an outdoor swimming pool and guests can enjoy meals at the in-house restaurant or have a drink at the bar. Free WiFi is available in all rooms.\r\n\r\nIt is 290 m to Pavilion Shopping Mall, while Lot 10 Shopping Centre and Fahrenheit88 are 550 m away. Aquaria KLCC is 1.1 km from the property. Kuala Lumpur International Airport is 64.1 km away.\r\n\r\nSpacious and elegant, rooms at Kuala Lumpur Ritz-Carlton feature large floor-to-ceiling windows with panoramic views of the city. Each room is equipped with a flat-screen TV. The marble bathrooms come with a separate shower area and bathtub facilities. Toothpaste, toothbrush and toiletries are provided.\r\n\r\nOther facilities at the property include a fitness centre and a sauna room. Alternatively, guests can indulge in a variety of treatments at the in-house spa. Guests can approach the 24-hour front desk for concierge services and luggage storage. This property also offers meeting rooms for hire. Friendly staff are fluent in English, Chinese and Malay. Union Pay is accepted.\r\n\r\nShock! Restaurant serves Chinese, Japanese and Western dishes. A Chinese restaurant and daily buffet breakfasts are available. Drinks and live music can be enjoyed at the Lobby Lounge.\r\n\r\n\r\nGet the celebrity treatment with world-class service at The Ritz-Carlton, Kuala Lumpur\r\nOne of our top picks in Kuala Lumpur.\r\nThe Ritz-Carlton offers luxurious, elegant rooms and residences in Kuala Lumpur’s Golden Triangle District, a 5-minute walk from Pavilion Mall. It features an outdoor swimming pool and guests can enjoy meals at the in-house restaurant or have a drink at the bar. Free WiFi is available in all rooms.\r\n\r\nIt is 290 m to Pavilion Shopping Mall, while Lot 10 Shopping Centre and Fahrenheit88 are 550 m away. Aquaria KLCC is 1.1 km from the property. Kuala Lumpur International Airport is 64.1 km away.\r\n\r\nSpacious and elegant, rooms at Kuala Lumpur Ritz-Carlton feature large floor-to-ceiling windows with panoramic views of the city. Each room is equipped with a flat-screen TV. The marble bathrooms come with a separate shower area and bathtub facilities. Toothpaste, toothbrush and toiletries are provided.\r\n\r\nOther facilities at the property include a fitness centre and a sauna room. Alternatively, guests can indulge in a variety of treatments at the in-house spa. Guests can approach the 24-hour front desk for concierge services and luggage storage. This property also offers meeting rooms for hire. Friendly staff are fluent in English, Chinese and Malay. Union Pay is accepted.\r\n\r\nShock! Restaurant serves Chinese, Japanese and Western dishes. A Chinese restaurant and daily buffet breakfasts are available. Drinks and live music can be enjoyed at the Lobby Lounge.\r\n\r\nMost popular facilities\r\n1 swimming pool, good fitness centre, Non-smoking rooms, Spa and wellness centre, Room service, Bar, Very good breakfast', 3),
(4, 'Pullman Kuala Lumpur City Centre Hotel & Residence', 'Kuala Lumpur', '4 Jalan Conlay, Bukit Bintang, 50450 Kuala Lumpur, Malaysia', '+60321708888', 'Located just opposite Pavilion Kuala Lumpur shopping mall, Pullman Kuala Lumpur City Centre Hotel & Residences offers modern accommodation with free WiFi throughout. It boasts 2 bars, 4 restaurants and an outdoor swimming pool.\r\n\r\nFeaturing modern fittings, each room is air-conditioned and comes with a flat-screen satellite TV. A minibar and coffee/tea making facilities are available. Select units have a seating area. The en suite bathroom includes separate bath and shower.\r\n\r\nThe all-day dining Sedap Restaurant serves a mix of local and international dishes. You can sample Chinese specialties at the Red Restaurant, while Japanese favourites are served at Enju. Drinks and snacks are available at the Blu Bar & Cigars and Terrace Pool.\r\n\r\nYou can exercise at the gym or relax in the poolside. The little ones can play in the kids\' club and babysitting service is available at a surcharge. The property also has well-equipped meeting facilities as well as a chargeable airport transfer.\r\n\r\nPullman Kuala Lumpur City Centre Hotel & Residences is 3 km to Petronas Twin Tower and 550 m from Raja Chulan MRT station. Bukit Bintang district is within walking distance and Kuala Lumpur International Airport is a 66 km drive.\r\n\r\nMost popular facilities\r\n1 swimming pool, very good fitness centre, Non-smoking rooms, Room service, Free parking, Bar, Good breakfast', 4),
(5, 'Traders Hotel Kuala Lumpur', 'Kuala Lumpur', 'Kuala Lumpur City Centre, 50088 Kuala Lumpur, Malaysia', '+60323329888', 'Enjoying direct access to Suria KLCC and Petronas Twin Towers, the luxurious Traders Hotel offers an indoor swimming pool and guests can enjoy meals from 2 in-house dining options. Free WiFi is available throughout the property.\r\n\r\nTraders Hotel Kuala Lumpur offers free shuttle buggies to Suria KLCC Shopping Mall. It is about 46 km from Kuala Lumpur International Airport. Royal Selangor Golf Club and Pavilion Mall are within 1.5 km of the hotel.\r\n\r\nThe spacious rooms feature floor-to-ceiling windows with views of the cityscape. Each room is equipped with a flat-screen cable TV and tea/coffee making facilities.\r\n\r\nGuests can relax at the SPA’s steam bath and hot tub. There is a 1.3 km jogging trail around KLCC Park and a 24-hour fitness centre. The hotel also provides a business centre and free parking.\r\n\r\nGobo Chit Chat Restaurant serves both Western and Asian specialities. Gobo Upstairs Lounge & Grill specialises in steaks from the grill. The open-air Sky Bar offers cocktails.\r\n\r\nMost popular facilities\r\n1 swimming pool, fabulous fitness centre, Non-smoking rooms, Spa and wellness centre, Room service, Free parking, Tea/coffee maker in all rooms, Bar, Very good breakfast', 5),
(6, 'DoubleTree By Hilton Kuala Lumpur', 'Kuala Lumpur', '348 Jalan Tun Razak, 50400 Kuala Lumpur, Malaysia', '+60321727272', 'A part of Kuala Lumpur\'s Golden Triangle, Doubletree by Hilton Kuala Lumpur offers accommodations just 5 minutes\' walk from Ampang Park LRT Station. It features an outdoor saltwater swimming pool and guests can enjoy meals at the in-house restaurant or have a drink at the bar. Free WiFi is available in all rooms.\r\n\r\nDoubletree by Hilton, Kuala Lumpur is a 15-minute walk from Suria KLCC and the Petronas Twin Towers. it is 2.9 km to Aquaria KLCC. Kuala Lumpur International Airport is 67.7 km from the property.\r\n\r\nThe air-conditioned rooms are fitted with 32-inch flat-screen TVs, jumbo pillows and posture-friendly chairs. The en suite bathroom features a rain shower and a hairdryer.\r\n\r\nGuests can approach the 24-hour front desk currency exchange, tour arrangements and concierge services. A business centre is available. Doubletree by Hilton also provides daily newspapers and laundry services.\r\n\r\nLocal Malaysian dishes can be enjoyed at Makan Kitchen, while homely Italian cuisine is served at Tosca. Other dining options include The Food Store Cafe and Cellar Door Wine Cellar.\r\n\r\nMost popular facilities\r\n1 swimming pool, very good fitness centre, Non-smoking rooms, Room service, Facilities for disabled guests, Bar', 6),
(7, 'Resorts World Genting - First World Hotel ', 'Genting Highlands', 'Resort World Genting, Genting Highland Resort, 69000 Genting Highlands, Malaysia', '+60327181118', 'Resorts World Genting - First World Hotel is situated 51 km from Kuala Lumpur and is directly connected to Sky Avenue Lifestyle mall with a variety of outlets and Genting Casino.\r\n\r\nRooms are well equipped with satellite TVs, international direct dial telephones and a fan to complement the cool mountain air. Tea and coffee making facilities and a safety deposit box are provided.\r\n\r\nFor business and conference options, a grand banquet hall with a 2,500 seat capacity and conference rooms are available. Self check-in kiosks and WiFi access are available at the lobby area.\r\n\r\nLobby Café serves local Malaysian favourites all throughout the day. For a drink or two and live music, guests can head to The Patio Bar and Lounge.\r\n\r\nFirst World Hotel is 1.5 hours by bus from Kuala Lumpur. A cable car ride from Genting Skyway Station takes 11 minutes and a further 10 minutes on foot.\r\n\r\nMost popular facilities\r\nParking, WiFi, Fitness centre, Spa and wellness centre, Non-smoking rooms, Restaurant', 8),
(8, 'Resorts World Awana', 'Genting Highlands', 'KM13, Genting Highlands, 69000 Genting Highlands, Malaysia', '+60327181118', 'Enjoying cool weather 915 m above sea level, Awana Hotel offers a relaxing stay with an outdoor pool and fitness facilities.\r\n\r\nThe property is a 1-hour 30-minute drive from Kuala Lumpur International Airport. It is easily accessible from attractions like Goh Tong Jaya.\r\n\r\nFeaturing classic furnishings in pleasant neutral shades, air-conditioned rooms come with cable TV. Tea/coffee making amenities and a safe are provided.\r\n\r\nThe property provides a first-rate 18-hole golf course, as well as archery facilities. Alternatively, get a good workout at the tennis courts. Staff can assist with business and laundry needs. Parking is available at an additional charge.\r\n\r\nDining options include Korean barbecue at Rajawali Restaurant. Flavours Cafe offers a casual environment for light meals and refreshments.\r\n\r\nMost popular facilities\r\n1 swimming pool, Parking, WiFi, Fitness centre, Non-smoking rooms', 9),
(9, 'Bayview Hotel Georgetown Penang', 'Pulau Penang', '25A Farquhar Street, 10200 George Town, Malaysia', '+6042633161', 'Featuring a revolving restaurant with 360-degree views of Penang Island, Bayview Hotel Georgetown Penang offers accommodations in the UNESCO World Heritage Site of George Town. It features an outdoor swimming pool and guests can enjoy meals from the in-house restaurant or have a drink at the bar. Free WiFi is available throughout the property.\r\n\r\nIt is 450 m to Penang State Museum and Art Gallery, while Pinang Peranakan Mansion, the culturally-vibrant Little India and Wonderfood Museum are within 1 km away. Clan Jetties of Penang is 2.9 km from Bayview Hotel Georgetown Penang. Penang International Airport is 19.6 km away.\r\n\r\nBoasting city or sea views from over-sized windows, 4-star rooms at Bayview Georgetown come in calming neutral shades. The en suite bathroom includes shower facilities and free toiletries.\r\n\r\nOther facilities at the property include a fitness centre, free private parking, a ballroom and 8 function rooms. Guests can approach the 24-hour front desk for currency exchange, concierge services and luggage storage.\r\n\r\nGuests choosing to dine in can do so at Kopi Tiam, which offers local specialties. After meals, head to the Lobby Lounge, which features live performances.\r\n\r\nMost popular facilities\r\n2 swimming pools, Free WiFi, Free parking, Family rooms, Non-smoking rooms, Bar', 10),
(10, 'Lexis Hibiscus Port Dickson', 'Port Dickson', '12th Miles Jalan Pantai 71250 Pasir Panjang Negeri Sembilan Malaysia, 71250 Port Dickson, Malaysia', '+6066602626', 'Experience world-class service at Lexis Hibiscus Port Dickson\r\nOffering an outdoor pool and an indoor pool, Lexis Hibiscus Port Dickson is located in Port Dickson. Free WiFi access is available in this chalet.\r\n\r\nThe accommodation will provide you with air conditioning and a minibar. Featuring a hairdryer, private bathroom also comes with a bidet and bathrobes. Extras include a private pool, a desk and ironing facilities.\r\n\r\nAt Lexis Hibiscus Port Dickson you will find a restaurant Other facilities offered at the property include a shared lounge and luggage storage. The property offers free parking.', 11),
(11, 'Swiss-Garden Hotel Melaka', 'Melaka', 'T2-4, The Shore @ Melaka River, Jalan Persisiran Bunga Raya, 75300 Melaka, Malaysia', '+6062883131', 'Overlooking the historical Melaka River, Swiss-Garden Hotel Melaka welcomes guests with 2 Olympic-size infinity pools, a tennis court and free WiFi access. It offers direct access to the The Shore Shopping Mall and Shore Oceanarium Complex.\r\n\r\nThis modern building stands tall at 32-storeys. Guests can enjoy a drink and the view of Melaka from the in-house Sky Garden rooftop bar. The property is only a 10-minute walk from the famous Jonker Street and 900 m from Christ Church and Sam Po Kong Temple. Kuala Lumpur International Airport is 86 km away.\r\n\r\nEnjoying panoramic views of the ocean and Melaka River, rooms at Swiss-Garden Hotel Melaka are elegantly furnished and fully air-conditioned. Amenities include a balcony, an en suite bathroom, a DVD player and a comfortable seating area.\r\n\r\nStaff at the 24-hour front desk can assist you with a meeting/banquet facilities and free private parking facilities. Children will enjoy the large wading pool available on-site.\r\n\r\nBoth Asian and international meals can be enjoyed at Coffee Terrence Cafe. For alternative dining options, room service is available.\r\n\r\nMost popular facilities\r\n2 swimming pools, Free parking, Family rooms, Free WiFi, Tea/coffee maker in all rooms, Bar', 12),
(12, 'Imperial Heritage Hotel Melaka ', 'Melaka', '1 Jalan Merdeka 1, Melaka, 75000 Melaka, Malaysia', '+6062899000', 'Strategically located in Melaka, The Imperial Heritage Melaka offers modern and homely accommodation with free WiFi access throughout the property. It features a fitness centre, a 24-hour front desk and free parking space on site.\r\n\r\nJust 400 m from Porta de Santiago, the hotel is within 700 m from Christ Church and Sam Po Kong Temple. Kuala Lumpur International Airport is approximately 87 km away.\r\n\r\nOffering views of the city, air-conditioned rooms and suites come with a wardrobe, a flat-screen TV, a laptop-compatible safe and ironing facilities. Minibar and electric kettle are also included. The en suite bathroom has hairdryer and shower facility.\r\n\r\nAt The Imperial Heritage Melaka, guests can approach the friendly staff for assistance with luggage storage, laundry/dry cleaning services and meeting/banquet arrangements. Airport transfers and shuttle services can be provided at a surcharge. Guests have access to tablet computer facilities at the Pomelo Networking Lounge on the first floor.\r\n\r\nThis non-smoking property houses a restaurant serving an appetising selection of local and Asian cuisine. Meals can also be enjoyed in the privacy of guests\' rooms.\r\n\r\nMost popular facilities\r\nFree parking, Family rooms, Free WiFi, Non-smoking rooms, Restaurant, good fitness centre, Tea/coffee maker in all rooms', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hoteloperator`
--

CREATE TABLE `hoteloperator` (
  `HotelOperator_ID` int(3) NOT NULL,
  `HotelOperator_Name` varchar(100) NOT NULL,
  `HotelOperator_Password` varchar(100) NOT NULL,
  `HotelOperator_Email` varchar(30) NOT NULL,
  `HotelOperator_Contact` varchar(12) NOT NULL,
  `HotelOperator_Age` int(3) NOT NULL,
  `HotelOperator_Gender` enum('M','F') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hoteloperator`
--

INSERT INTO `hoteloperator` (`HotelOperator_ID`, `HotelOperator_Name`, `HotelOperator_Password`, `HotelOperator_Email`, `HotelOperator_Contact`, `HotelOperator_Age`, `HotelOperator_Gender`) VALUES
(1, 'HOadmin', 'hoadmin123', 'hoadmin@gmail.com', '+60123456789', 30, 'F'),
(2, 'Mandarin Oriental Admin', 'MOadmin123@', 'MOadmin@gmail.com', '+60170287765', 38, 'M'),
(3, 'Ritz-Carlton Admin', 'RCadmin123@', 'RCadmin@gmail.com', '+60167302287', 28, 'F'),
(4, 'PullmanKL Admin', 'Pullman123@', 'pullmankl@gmail.com', '+60129375503', 44, 'M'),
(5, 'Traders Admin', 'Traders123@', 'trader@gmail.com', '+60148366628', 27, 'F'),
(6, 'DoubleTree Admin', 'DTadmin123@', 'dtadmin@gmail.com', '+60193782732', 35, 'M'),
(7, 'Imperial Melaka', 'Imperial123@', 'Imperial@gmail.com', '+0179384756', 39, 'F'),
(8, 'Genting FWH', 'Genting123@', 'gentingFWH@gmail.com', '+60170287765', 33, 'M'),
(9, 'Genting Awana', 'Awana123@', 'Awana@gmail.com', '+60147384432', 44, 'M'),
(10, 'Bayview Penang', 'Bayview123@', 'bayview@gmail.com', '+60194384756', 47, 'F'),
(11, 'Lexis PD', 'Lexis123@', 'Lexis@gmail.com', '+60173892234', 30, 'M'),
(12, 'Swiss-Garden', 'Swiss123@', 'Swiss@gmail.com', '+0129485768', 28, 'F');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `Customer_ID` int(3) NOT NULL,
  `Room_ID` int(3) NOT NULL,
  `Date_ID` int(3) NOT NULL,
  `Num_Rooms` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`Customer_ID`, `Room_ID`, `Date_ID`, `Num_Rooms`) VALUES
(1, 1, 2, 2),
(1, 9, 18, 1),
(3, 14, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_ID` int(3) NOT NULL,
  `Room_Name` varchar(60) NOT NULL,
  `Room_Type` enum('XL','L','S') NOT NULL,
  `Num_Bed` int(3) NOT NULL,
  `Bed_Size` enum('XL','L','S') NOT NULL,
  `Price_Per_Day` decimal(8,2) NOT NULL,
  `Num_Rooms` int(2) NOT NULL,
  `Hotel_ID` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_ID`, `Room_Name`, `Room_Type`, `Num_Bed`, `Bed_Size`, `Price_Per_Day`, `Num_Rooms`, `Hotel_ID`) VALUES
(1, 'Grand Twin Room with Tower View', 'L', 3, 'S', '202.75', 9, 1),
(2, ' Grand King Room with Garden View', 'L', 2, 'S', '180.99', 5, 1),
(3, 'Deluxe Double Room', 'L', 1, 'XL', '350.00', 8, 6),
(4, 'Twin Room', 'L', 2, 'L', '300.00', 6, 6),
(5, 'Staycation Offer - Deluxe Room', 'XL', 1, 'XL', '450.00', 10, 5),
(6, 'Staycation Offer - Deluxe Garden View Room', 'XL', 2, 'L', '550.00', 10, 5),
(7, 'Deluxe King Room', 'L', 2, 'L', '299.99', 13, 4),
(8, 'Grand Deluxe King Room', 'XL', 2, 'L', '419.99', 8, 4),
(9, 'Deluxe King Room with City View', 'L', 1, 'L', '359.75', 20, 2),
(10, 'Deluxe Twin Room with City View', 'XL', 2, 'XL', '545.88', 10, 2),
(11, 'Mandarin King Room', 'XL', 1, 'XL', '788.88', 5, 2),
(12, 'Deluxe Room', 'L', 1, 'XL', '343.88', 8, 3),
(13, 'Three-Bedroom Suite', 'XL', 3, 'L', '757.66', 6, 3),
(14, 'World Club Double or Twin Room', 'L', 2, 'L', '388.20', 20, 7),
(15, 'Superior Deluxe Double or Twin Room with Spa Package', 'XL', 2, 'XL', '799.50', 6, 7),
(16, 'Standard Double or Twin Room', 'S', 1, 'S', '245.33', 30, 7),
(17, 'One-Bedroom Apartment', 'L', 1, 'XL', '450.99', 10, 8),
(18, ' Premier Deluxe Room', 'L', 2, 'XL', '550.77', 8, 8),
(19, ' Superior Twin Room', 'S', 2, 'S', '250.88', 15, 9),
(20, 'Family Room', 'XL', 3, 'L', '488.77', 10, 9),
(21, 'Executive Pool Villa', 'XL', 2, 'XL', '699.35', 10, 10),
(22, 'Presidential Suite', 'XL', 5, 'XL', '1100.88', 6, 10),
(23, 'Deluxe Twin Room', 'L', 2, 'XL', '488.45', 8, 11),
(24, 'Executive Suite', 'XL', 3, 'L', '597.66', 12, 11),
(25, 'Imperial Deluxe', 'L', 2, 'S', '388.67', 14, 12),
(26, 'Executive Room', 'L', 1, 'L', '242.88', 20, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`Date_ID`),
  ADD UNIQUE KEY `Check_InOut_Date` (`Check_In_Date`,`Check_Out_Date`) USING BTREE;

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Feedback_ID`),
  ADD UNIQUE KEY `Customer_ID` (`Customer_ID`,`Hotel_ID`),
  ADD KEY `Hotel_ID` (`Hotel_ID`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`Hotel_ID`),
  ADD KEY `HotelOperator_ID` (`HotelOperator_ID`);

--
-- Indexes for table `hoteloperator`
--
ALTER TABLE `hoteloperator`
  ADD PRIMARY KEY (`HotelOperator_ID`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`Customer_ID`,`Room_ID`,`Date_ID`),
  ADD KEY `Room_ID` (`Room_ID`),
  ADD KEY `Date_ID` (`Date_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_ID`),
  ADD KEY `Hotel_ID` (`Hotel_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `date`
--
ALTER TABLE `date`
  MODIFY `Date_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `Feedback_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
  MODIFY `Hotel_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `hoteloperator`
--
ALTER TABLE `hoteloperator`
  MODIFY `HotelOperator_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `Room_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`Hotel_ID`) REFERENCES `hotel` (`Hotel_ID`);

--
-- Constraints for table `hotel`
--
ALTER TABLE `hotel`
  ADD CONSTRAINT `hotel_ibfk_1` FOREIGN KEY (`HotelOperator_ID`) REFERENCES `hoteloperator` (`HotelOperator_ID`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`Room_ID`) REFERENCES `room` (`Room_ID`),
  ADD CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`Date_ID`) REFERENCES `date` (`Date_ID`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`Hotel_ID`) REFERENCES `hotel` (`Hotel_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
