<html>
<head>
<title>Search Results</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/clear.css" rel="stylesheet">
<link href="css/search.css" rel="stylesheet">
</head>
<script  src="js/searchlist.js"></script>
<?php 
include 'home_header.php';

$searchname = $_GET['search'];
$checkin = $_GET['checkin'];
$checkout = $_GET['checkout'];
$numRoom = $_GET['numRoom'];
$numGuest = $_GET['numGuest'];
$start = $_GET['start'];


if(!(empty($checkin) AND empty($checkout)))
{
	if(empty($checkin) AND !empty($checkout)){
		$checkin = $checkout;}
	if(!empty($checkin) AND empty($checkout)){
		$checkout = $checkin;}
	if($checkin > $checkout)
	{
		$temp = $checkin;
		$checkin = $checkout;
		$checkout=$temp;
	}
}

$sql = "SELECT Hotel_ID, cast(AVG(Price_Per_Day) as decimal(8,2)) as avgPrice,
SUM(NOT_Total_Num_Bed) as Total_Num_Bed,
(SUM(NOT_Total_Num_Bed) - IFNULL(SUM(NOT_Num_Guest),0) ) as Num_Guest,
SUM(not_total_room) as total_room,
(SUM(not_total_room) - IFNULL(SUM(not_num_room_available),0) ) as num_room_available,
Hotel_Name, Hotel_Location, Hotel_Address
FROM
(
SELECT hotel.Hotel_ID,room.Room_ID, room.Num_Rooms*Num_Bed as NOT_Total_Num_Bed,
IFNULL(SUM((Num_Bed*reservation.Num_Rooms)),0)  as NOT_Num_Guest, 
room.Num_Rooms as not_total_room,
IFNULL(SUM(reservation.Num_Rooms),0) as not_num_room_available,
Price_Per_Day, 
Hotel_Name, Hotel_Location, Hotel_Address
FROM ((hotel
LEFT OUTER JOIN room on room.Hotel_ID = hotel.Hotel_ID)
LEFT OUTER JOIN (reservation
INNER JOIN date on reservation.Date_ID = date.Date_ID
AND ((cast(Check_In_Date as date) Between '$checkin' and '$checkout')
or (cast(Check_Out_Date as date) Between '$checkin' and '$checkout')))  on room.Room_ID = reservation.Room_ID
)
GROUP BY room.Room_ID
) sq 
";

if(!empty($numGuest) or !empty($searchname)  or !empty($numRoom))
{
	$sql.="WHERE( TRUE ";
	if(!empty($searchname)){$sql.=" AND (Hotel_Name LIKE '%$searchname%' OR Hotel_Location LIKE '%$searchname%' OR Hotel_Address LIKE '%$searchname%')";}
	$sql .= ")";
	$sql.=" GROUP BY Hotel_ID ";
	if(!empty($numRoom))
	{
		$sql.=" HAVING ((num_room_available>=$numRoom)";
		if(!empty($numGuest)){
			$sql.=" AND (Num_Guest>=$numGuest))";
		}
		else{
			$sql.=") ";
			}
	}
	else if(!empty($numGuest)){$sql.=" HAVING (Num_Guest>=$numGuest)";}
}
else
{
	$sql.=" GROUP BY Hotel_ID ";
}
$temp = $sql;
$temp .=";";
$result=execSQL($temp);
$totalrow = mysqli_num_rows($result);
if(!is_null($result))
{
	$remain = $totalrow % 5 ;
	$totalrow = ($totalrow - $remain) / 5;
	$totalrow = ($remain > 0)?$totalrow+1: $totalrow;
}
else
{
	$remain = null;
	$totalrow = null;
}

$sql .= "LIMIT 5 OFFSET ".($start*5).";";
$result=execSQL($sql);

//record in session value
$_SESSION['searchname'] = $searchname;
$_SESSION['checkin'] = $checkin;
$_SESSION['checkout'] = $checkout;
$_SESSION['numRoom'] = $numRoom;
$_SESSION['numGuest'] = $numGuest;

?>

<body>
<div class="all">
<div class="searchBox">
<h1>Search Result: </h1>
<?php
if($_SESSION['user_type'] == "HO")
{
	header("Location: home.php");
}

if($result)
{
	if($result->num_rows > 0)
	{
		while($row = $result->fetch_assoc()) 
		{	
			echo "<table class='searchResult'><tr>";
			echo "<td><img src='img/hotel/".$row["Hotel_ID"].".jpg' alt='".$row["Hotel_Name"]."' class='hotelimg'/>
				</td>";
			echo "<td class='descRoom'>
			<h1>".$row["Hotel_Name"]."</h1>
			<p>
			Num of Room: ".$row["num_room_available"]."
			<br>Location: ".$row["Hotel_Location"]."
			<br>Address: ".$row["Hotel_Address"]."
			<br>Price Per Day Overall: RM ".$row["avgPrice"]."
			<br>Num of Available Guest: ".$row["Num_Guest"]."
			</p>
			<a href='HotelDetails.php?hotelid=".$row["Hotel_ID"]."'><button class='view'> View This Hotel's Room  </button></a>
			</td></tr>";
		}
		echo "</table>";
	}
	else
	{
		echo "no result was found";
	}
}
?>

</div>
<form class="buttonGroup" action="search.php" method="get">

<?php
	echo "<button class='previousPage' name='start' value='".($start-1)."'>&#10094;</button>";
	echo "<div class='Listbutton'>";

	$initial = 0;
	if($start>9)
	{
		$initial = $start - 9;
	}
	for($i=$initial; $i<$totalrow && $i<($initial+10) ; $i++)
	{
		echo "<button class='numbutton'  name='start' value='".$i."'>$i</button>";
	}
	echo "</div>";
	echo "<button class='nextPage'  name='start' value='".($start+1)."'>&#10095;</button>";

	echo "<input type='hidden' name='search' value='".$searchname."'>";
	echo "<input type='hidden' name='checkin' value='".$checkin."'>";
	echo "<input type='hidden' name='checkout' value='".$checkout."'>";
	echo "<input type='hidden' name='numRoom' value='".$numRoom."'>";
	echo "<input type='hidden' name='numGuest' value='".$numGuest."'>";
?>
</form>


<script type="text/javascript">
	showSearchPage(<?php echo $start." , ".$totalrow?>);
</script>

</div></body>

<?php include 'home_footer.php'?>
</html>