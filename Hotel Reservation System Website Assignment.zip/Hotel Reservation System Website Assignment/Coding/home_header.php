<link href="css/header.css" rel="stylesheet">
<link rel="stylesheet" href="css/clear.css" />
<?php
include 'hoteldb.inc.php';
if (session_status() == PHP_SESSION_NONE)
{
	session_save_path('tmp');
    session_start();
}

if(isset($_GET['logout']))
{
	$username=null;
	$_SESSION['user_type']=null;
	$_SESSION['user_id']=null;
	header("Location: home.php");
}

if(isset($_SESSION['user_type']) && isset($_SESSION['user_id']))
{
	if($_SESSION['user_type'] == "Customer")
	{
		$sql = "SELECT Customer_Name FROM customer WHERE Customer_ID=".$_SESSION['user_id'].";";
		$result=execSQL($sql);
		if ($result->num_rows > 0) 
		{
			  $row = $result->fetch_object();
			  $username=$row->Customer_Name;
			  $filename = "img/customer/".$_SESSION['user_id'].".jpg";
		}
		
	}
	else if($_SESSION['user_type'] == "HO")
	{
		$sql = "SELECT HotelOperator_Name FROM hoteloperator WHERE HotelOperator_ID=".$_SESSION['user_id'].";";
		$result=execSQL($sql);
		if ($result->num_rows > 0) 
		{
			$row = $result->fetch_object();
			$username=$row->HotelOperator_Name;
			$filename = "img/hotelOperator/".$_SESSION['user_id'].".jpg";
  
		}
	}
	if(!file_exists($filename)){
			$filename = "img/user.jpg";	
	}
}
else
{
	$username=null;
	$_SESSION['user_type']=null;
	$_SESSION['user_id']=null;
}

//for test the sign in button
//$_SESSION['user_type']=null;
//$_SESSION['user_id']=null;
//$username=null;

?>

<header>

<div class="headall">
<div class="Container">
<div class="Left">
<a href="home.php"><img src="img/hotel go logo.png" alt="logo" id="logo"/></a>
</div>

<?php 
if(isset($_GET['search']))
	$tempc = $_GET['search'];
else
	$tempc = null;

if($_SESSION['user_type']==null || $_SESSION['user_type']=="Customer" ){ 
	echo "<div class='center'>
	<form action='search.php' method='get' class='SearchForm'>
		<input type='hidden' name='start' value=0>
	<input type='search' id='search' name='search' value = \"".$tempc."\">
				<span><button type='submit' id='searchbtn'></button></span>
</div>";
}?>


<div class="Right">
<table>
<tr>
<td><?php
if($_SESSION['user_type']==null || $_SESSION['user_type']=="Customer" ){
echo "<a href='viewcart.php'><button id='cartbtn' type='button'></button><span class='cartNum'>-1</span></a></td>";}?>
<td id="account">
<?php

if (is_null($username))
{
	echo "<a href='signin.php'><button id='SignInbtn' type='button'>Sign in</button></a>";
}
else
{
	echo "<div id='acc' class='dropdown'> <button class='dropbtn' type='button'>
	<table><tr><td>
	<img src='$filename' alt='user' id='picuser'/></td><td>";
	echo " <div id='textname'>".$username."
	<br> (".$_SESSION['user_type'].")</div></td></tr></table> 
	</button>
	<div class='dropdown-content'>
		<a href='ManageProfile.php'> Manage Profile </a>
		<a href='bookedRoom.php'> Booked Room </a>";
	if($_SESSION['user_type']=="HO")
	{
		echo "<a href='ManageHotel.php'> Manage Hotel </a>";
		echo "<a href='Ho_bookingCustomer.php'> Customer Booking Detail </a>";
	}
	echo "
		<a href='Setting.php';> Setting </a>
		<a href='home.php?logout=yes';> Log out </a></div></div> ";
}
include 'calNumCart.php';
?>

</td>
<tr>
</table>
</div>
</div>


<div class='Container2'>

	<div class='center'>
<?php if($_SESSION['user_type']==null || $_SESSION['user_type']=="Customer" )
{ 

if(isset($_GET['checkin']))
	$tempcheck = $_GET['checkin'];
else
	$tempcheck = null;

if(isset($_GET['checkout']))
	$tempcheck1 = $_GET['checkout'];
else
	$tempcheck1 = null;
if(isset($_GET['numRoom']))
	$tempcheck2 = $_GET['numRoom'];
else
	$tempcheck2 = null;

if(isset($_GET['numGuest']))
	$tempcheck3 = $_GET['numGuest'];
else
	$tempcheck3 = null;


echo "
		<div>Filter By:</div>
			<div>
				<label>Check In: </label>
				<input type='date' name='checkin' min='".date("Y-m-d")."'  
				value = '".$tempcheck."'>
			</div>
			<div>
				<label>Check out:</label>
				<input type='date' name='checkout' min='".date("Y-m-d")."'
				value = '".$tempcheck1."'>
			</div>
			<div>
				<label>Number of Rooms:</label>
				<input type='number' name='numRoom' min='1' max='50' value = '".$tempcheck2."'>
			</div>
			<div>
				<label>Number of Guest:</label>
				<input type='number' name='numGuest' min='1' max='50' value = '".$tempcheck3."'>
			</div>
	</form>
";}?>
</div>

</div>

</div>
</header>
