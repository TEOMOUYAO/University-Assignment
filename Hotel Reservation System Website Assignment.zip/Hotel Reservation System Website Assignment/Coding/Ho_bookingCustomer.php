<html>
<head>
<title>Customer Booking Detail</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/Ho_bookingCustomer.css" rel="stylesheet">
</head>
<?php 
include 'home_header.php';

if(isset($_GET['CID']) && isset($_GET['DID']) && isset($_GET['RID']))
{
	
	$sql = "DELETE FROM reservation 
	WHERE(Customer_ID=".$_GET['CID']." AND Date_ID=".$_GET['DID']." AND Room_ID=".$_GET['RID']." );";
	$sql2 = "DELETE FROM date WHERE Date_ID=".$_GET['DID']."; ";
	execSQL($sql);
	execSQL($sql2);
	header("Location: Ho_bookingCustomer.php");

}

$sql = "SELECT Room_ID, Room_Name 
FROM ((hoteloperator 
INNER JOIN hotel ON hoteloperator.HotelOperator_ID = hotel.HotelOperator_ID)
INNER JOIN room ON hotel.Hotel_ID = room.Hotel_ID)
WHERE hoteloperator.HotelOperator_ID = ".$_SESSION['user_id'].";" ;
$resultRoom=execSQL($sql);

$sql = "SELECT room.Room_ID, customer.Customer_ID ,date.Date_ID, reservation.Num_Rooms,Customer_Name, Customer_Email, Customer_Contact, Customer_Age, Customer_Gender, Check_In_Date, Check_Out_Date
FROM (((((hoteloperator 
INNER JOIN hotel ON hoteloperator.HotelOperator_ID = hotel.HotelOperator_ID)
INNER JOIN room ON hotel.Hotel_ID = room.Hotel_ID)
INNER JOIN reservation ON room.Room_ID = reservation.Room_ID)
INNER JOIN customer ON reservation.Customer_ID = customer.Customer_ID)
INNER JOIN date ON reservation.Date_ID = date.Date_ID)
WHERE hoteloperator.HotelOperator_ID = ".$_SESSION['user_id']."
ORDER BY room.Room_ID, Check_In_Date;" ;
$roomreservation=execSQL($sql);
$roomreservation2=execSQL($sql);

?>

<body>

<h1>Customer Booking Detail: </h1><br>
<?php
$date_now = date("Y-m-d H:i:s");
if($resultRoom)
{
	if($resultRoom->num_rows > 0)
	{
		while($row = $resultRoom->fetch_assoc()) 
		{
			echo "<table class='customerRoomDetail'><tr>";
			echo "<td>
			<img src='img/room/".$row["Room_ID"].".jpg' alt='".$row["Room_Name"]."' class='roomBookimg'/>
			<div class='tag'>".$row["Room_Name"]." ".$row["Room_ID"]."</div>
				</td>";
			echo "<td class='buttonHis'>";
			echo "<div class='scroll'><table class>";
			echo "<tr><td>Past Reservation</td></tr>";
			while($row2 = $roomreservation->fetch_assoc()) 
			{
				if(($row2["Room_ID"]==$row["Room_ID"]) &&  ($row2["Check_Out_Date"]< $date_now))
				{
					echo "<tr><td>
					Name: ".$row2["Customer_Name"]." <br>
					Gender: ".$row2["Customer_Gender"]." <br>
					Age: ".$row2["Customer_Age"]." <br>
					Contact: ".$row2["Customer_Contact"]." <br>
					Email: ".$row2["Customer_Email"]." <br>
					Check In: ".$row2["Check_In_Date"]." <br>
					Check Out: ".$row2["Check_Out_Date"]." <br>
					Num of Room: ".$row2["Num_Rooms"]."<br>
					</td></tr>";
				}
				
			}
			echo "</table></div>";
			echo "<div class='scroll'><table>";
			echo "<tr><td>Reservation</td></tr>";
			while($row2 = $roomreservation2->fetch_assoc()) 
			{
				if(($row2["Room_ID"]==$row["Room_ID"]) &&  ($row2["Check_In_Date"] >= $date_now))
				{
					echo "<tr><td>
					Name: ".$row2["Customer_Name"]." <br>
					Gender: ".$row2["Customer_Gender"]." <br>
					Age: ".$row2["Customer_Age"]." <br>
					Contact: ".$row2["Customer_Contact"]." <br>
					Email: ".$row2["Customer_Email"]." <br>
					Check In: ".$row2["Check_In_Date"]." <br>
					Check Out: ".$row2["Check_Out_Date"]." <br>
					Num of Room: ".$row2["Num_Rooms"]." <br>
					<a href='Ho_bookingCustomer.php?RID=".$row2["Room_ID"]."&CID=".$row2["Customer_ID"]."&DID=".$row2["Date_ID"]."'  class='delete' data-confirm='Are you sure to delete this item?');'><button>Delete</button></a>
					</td>";
				}
			}
			echo "</table></div>";
			echo "</td></tr>";
		}
	}
	else
	{
		echo "no room was found";
	}
}



?>

</body>
<script type="text/javascript">
var deleteLinks = document.querySelectorAll('.delete');

for (var i = 0; i < deleteLinks.length; i++) {
  deleteLinks[i].addEventListener('click', function(event) {
      event.preventDefault();

      var choice = confirm(this.getAttribute('data-confirm'));

      if (choice) {
        window.location.href = this.getAttribute('href');
      }
  });
}
</script>


<?php include 'home_footer.php';?>
</html>