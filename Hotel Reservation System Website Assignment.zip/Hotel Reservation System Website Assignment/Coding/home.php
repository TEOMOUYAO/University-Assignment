<html>
<head>
<title>Home</title>
<link rel="icon" href="img/hotel go logo.png">
<link href="css/home.css" rel="stylesheet">

</head>
<?php include 'home_header.php'?>
<body>
<div class="slide">
	<?php
	for($i=1; $i<6; $i++)
	{
		echo "<img class='mySlides fade' src='img/hotel/".$i.".jpg'>";
	}
	echo"<div class='example'>";
	for($i=1;$i<6;$i++)
	{
		echo "<img class='exSlide' src='img/hotel/".$i.".jpg' onclick='currentDiv(".$i.")'>";
	}
	echo "</div>";
	?>
</div>
<script src="js/slideshow.js"></script>
<div class="all">



<div id="paragraph">
	<h1>About Us</h1>
	<p>Hotel Go is a reservation system that allow customers of hotels such as travelers, 
	foreigners, businessmen and tourists to create secure online reservations. Hotel Go allows 
	the customers to reserve hotel rooms in a way that is convenient, since they can reserve the 
	rooms anytime and anywhere! For hotel operators, Hotel Go allows them to store and distribute
	information of their hotels, rooms and lodging facilities. So that, Hotel Go helps the hotel 
	operators to manage all of their online marketing and sales! This website is builded on September 
	2020.</p>
</div>

<div class="stateRec">
	<h1>Explore Malaysia</h1>
	<p>These Popular Desticnation still recommended</p>
	<div class="containerState">
	<?php
		$state=["genting.jpg", "portdickson.jpg", "pulaupinang.jpg","melaka.jpg","kl.jpg"];
		$statename=["Genting Highland", "Port Dickson", "Pulau Pinang", "Melaka", "Kuala Lumpur"];
		
		for($i=0; $i<count($state); $i++)
		{
			echo "<a href='search.php?search=".$statename[$i]."&checkin=&checkout=&numRoom=&numGuest=&start=0'>
			<div class='containerState'>";
			echo "<img src='img/state/".$state[$i]."' alt='state' class='stateplace'/>";
			echo "<div class='overlay'>";
			echo "<div class='text'>".$statename[$i]."</div>";
			echo "</div></div></a>";
		}
	?>
	</div>
</div>
</div>
</body>

<?php include 'home_footer.php'?>
</html>
